import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Grid.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Grid.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Line, Group, Rect } from "/node_modules/.vite/deps/react-konva.js?v=4e926b2f";
const Grid = ({ width, height, gridSize }) => {
  const horizontalLines = [];
  const verticalLines = [];
  const startX = -gridSize;
  const startY = -gridSize;
  const paddedWidth = width + gridSize * 2;
  const paddedHeight = height + gridSize * 2;
  for (let i = startY; i <= paddedHeight; i += gridSize) {
    horizontalLines.push(
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          points: [startX, i, paddedWidth, i],
          stroke: "#ddd",
          strokeWidth: i % (gridSize * 5) === 0 ? 0.5 : 0.2
        },
        `h-${i}`,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Grid.jsx",
          lineNumber: 38,
          columnNumber: 7
        },
        this
      )
    );
  }
  for (let i = startX; i <= paddedWidth; i += gridSize) {
    verticalLines.push(
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          points: [i, startY, i, paddedHeight],
          stroke: "#ddd",
          strokeWidth: i % (gridSize * 5) === 0 ? 0.5 : 0.2
        },
        `v-${i}`,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Grid.jsx",
          lineNumber: 50,
          columnNumber: 7
        },
        this
      )
    );
  }
  return /* @__PURE__ */ jsxDEV(Group, { children: [
    /* @__PURE__ */ jsxDEV(
      Rect,
      {
        x: 0,
        y: 0,
        width,
        height,
        fill: "#f9f9f9"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Grid.jsx",
        lineNumber: 62,
        columnNumber: 7
      },
      this
    ),
    horizontalLines,
    verticalLines
  ] }, void 0, true, {
    fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Grid.jsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
};
_c = Grid;
export default Grid;
var _c;
$RefreshReg$(_c, "Grid");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Grid.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Grid.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEJOLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsTUFBTUMsT0FBT0MsWUFBWTtBQUVsQyxNQUFNQyxPQUFPQSxDQUFDLEVBQUVDLE9BQU9DLFFBQVFDLFNBQVMsTUFBTTtBQUM1QyxRQUFNQyxrQkFBa0I7QUFDeEIsUUFBTUMsZ0JBQWdCO0FBR3RCLFFBQU1DLFNBQVMsQ0FBQ0g7QUFDaEIsUUFBTUksU0FBUyxDQUFDSjtBQUdoQixRQUFNSyxjQUFjUCxRQUFRRSxXQUFXO0FBQ3ZDLFFBQU1NLGVBQWVQLFNBQVNDLFdBQVc7QUFHekMsV0FBU08sSUFBSUgsUUFBUUcsS0FBS0QsY0FBY0MsS0FBS1AsVUFBVTtBQUNyREMsb0JBQWdCTztBQUFBQSxNQUNkO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxRQUFRLENBQUNMLFFBQVFJLEdBQUdGLGFBQWFFLENBQUM7QUFBQSxVQUNsQyxRQUFPO0FBQUEsVUFDUCxhQUFhQSxLQUFLUCxXQUFXLE9BQU8sSUFBSSxNQUFNO0FBQUE7QUFBQSxRQUh6QyxLQUFLTyxDQUFDO0FBQUEsUUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSW9EO0FBQUEsSUFFdEQ7QUFBQSxFQUNGO0FBR0EsV0FBU0EsSUFBSUosUUFBUUksS0FBS0YsYUFBYUUsS0FBS1AsVUFBVTtBQUNwREUsa0JBQWNNO0FBQUFBLE1BQ1o7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFFBQVEsQ0FBQ0QsR0FBR0gsUUFBUUcsR0FBR0QsWUFBWTtBQUFBLFVBQ25DLFFBQU87QUFBQSxVQUNQLGFBQWFDLEtBQUtQLFdBQVcsT0FBTyxJQUFJLE1BQU07QUFBQTtBQUFBLFFBSHpDLEtBQUtPLENBQUM7QUFBQSxRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJb0Q7QUFBQSxJQUV0RDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBRUM7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsR0FBRztBQUFBLFFBQ0gsR0FBRztBQUFBLFFBQ0g7QUFBQSxRQUNBO0FBQUEsUUFDQSxNQUFLO0FBQUE7QUFBQSxNQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtnQjtBQUFBLElBRWZOO0FBQUFBLElBQ0FDO0FBQUFBLE9BVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBRU8sS0FsRElaO0FBb0ROLGVBQWVBO0FBQUssSUFBQVk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiTGluZSIsIkdyb3VwIiwiUmVjdCIsIkdyaWQiLCJ3aWR0aCIsImhlaWdodCIsImdyaWRTaXplIiwiaG9yaXpvbnRhbExpbmVzIiwidmVydGljYWxMaW5lcyIsInN0YXJ0WCIsInN0YXJ0WSIsInBhZGRlZFdpZHRoIiwicGFkZGVkSGVpZ2h0IiwiaSIsInB1c2giLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkdyaWQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5lLCBHcm91cCwgUmVjdCB9IGZyb20gJ3JlYWN0LWtvbnZhJztcblxuY29uc3QgR3JpZCA9ICh7IHdpZHRoLCBoZWlnaHQsIGdyaWRTaXplIH0pID0+IHtcbiAgY29uc3QgaG9yaXpvbnRhbExpbmVzID0gW107XG4gIGNvbnN0IHZlcnRpY2FsTGluZXMgPSBbXTtcblxuICAvLyBFbnN1cmUgd2Ugc3RhcnQgZHJhd2luZyBmcm9tIG5lZ2F0aXZlIGNvb3JkaW5hdGVzIHRvIGNvdmVyIGFueSBwb3RlbnRpYWwgZ2Fwc1xuICBjb25zdCBzdGFydFggPSAtZ3JpZFNpemU7XG4gIGNvbnN0IHN0YXJ0WSA9IC1ncmlkU2l6ZTtcbiAgXG4gIC8vIEFkZCBleHRyYSBwYWRkaW5nIHRvIGVuc3VyZSBncmlkIGNvdmVycyB0aGUgZW50aXJlIHZpc2libGUgYXJlYVxuICBjb25zdCBwYWRkZWRXaWR0aCA9IHdpZHRoICsgZ3JpZFNpemUgKiAyO1xuICBjb25zdCBwYWRkZWRIZWlnaHQgPSBoZWlnaHQgKyBncmlkU2l6ZSAqIDI7XG5cbiAgLy8gQ3JlYXRlIGhvcml6b250YWwgZ3JpZCBsaW5lc1xuICBmb3IgKGxldCBpID0gc3RhcnRZOyBpIDw9IHBhZGRlZEhlaWdodDsgaSArPSBncmlkU2l6ZSkge1xuICAgIGhvcml6b250YWxMaW5lcy5wdXNoKFxuICAgICAgPExpbmVcbiAgICAgICAga2V5PXtgaC0ke2l9YH1cbiAgICAgICAgcG9pbnRzPXtbc3RhcnRYLCBpLCBwYWRkZWRXaWR0aCwgaV19XG4gICAgICAgIHN0cm9rZT1cIiNkZGRcIlxuICAgICAgICBzdHJva2VXaWR0aD17aSAlIChncmlkU2l6ZSAqIDUpID09PSAwID8gMC41IDogMC4yfVxuICAgICAgLz5cbiAgICApO1xuICB9XG5cbiAgLy8gQ3JlYXRlIHZlcnRpY2FsIGdyaWQgbGluZXNcbiAgZm9yIChsZXQgaSA9IHN0YXJ0WDsgaSA8PSBwYWRkZWRXaWR0aDsgaSArPSBncmlkU2l6ZSkge1xuICAgIHZlcnRpY2FsTGluZXMucHVzaChcbiAgICAgIDxMaW5lXG4gICAgICAgIGtleT17YHYtJHtpfWB9XG4gICAgICAgIHBvaW50cz17W2ksIHN0YXJ0WSwgaSwgcGFkZGVkSGVpZ2h0XX1cbiAgICAgICAgc3Ryb2tlPVwiI2RkZFwiXG4gICAgICAgIHN0cm9rZVdpZHRoPXtpICUgKGdyaWRTaXplICogNSkgPT09IDAgPyAwLjUgOiAwLjJ9XG4gICAgICAvPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxHcm91cD5cbiAgICAgIHsvKiBCYWNrZ3JvdW5kIGZpbGwgZm9yIHRoZSBncmlkICovfVxuICAgICAgPFJlY3RcbiAgICAgICAgeD17MH1cbiAgICAgICAgeT17MH1cbiAgICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgICAgZmlsbD1cIiNmOWY5ZjlcIlxuICAgICAgLz5cbiAgICAgIHtob3Jpem9udGFsTGluZXN9XG4gICAgICB7dmVydGljYWxMaW5lc31cbiAgICA8L0dyb3VwPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgR3JpZDtcbiJdLCJmaWxlIjoiQzovVXNlcnMvTGV2aS9DYXNjYWRlUHJvamVjdHMvcGV0cmktbmV0LWVkaXRvci9wZXRyaS1uZXQtYXBwL3NyYy9jb21wb25lbnRzL0dyaWQuanN4In0=