import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Stage, Layer, Line, Circle, Rect } from "/node_modules/.vite/deps/react-konva.js?v=4e926b2f";
import Toolbar from "/src/components/Toolbar.jsx";
import PropertiesPanel from "/src/components/PropertiesPanel.jsx";
import ExecutionPanel from "/src/components/ExecutionPanel.jsx";
import Place from "/src/components/Place.jsx";
import Transition from "/src/components/Transition.jsx";
import Arc from "/src/components/Arc.jsx";
import Grid from "/src/components/Grid.jsx";
import { HistoryManager } from "/src/utils/historyManager.js";
function App() {
  _s();
  const [elements, setElements] = useState({
    places: [],
    transitions: [],
    arcs: []
  });
  const [selectedElement, setSelectedElement] = useState(null);
  const [mode, setMode] = useState("select");
  const [arcStart, setArcStart] = useState(null);
  const [tempArcEnd, setTempArcEnd] = useState(null);
  const stageRef = useRef(null);
  const appRef = useRef(null);
  const [stageDimensions, setStageDimensions] = useState({
    width: 800,
    height: 600
  });
  const gridSize = 20;
  const containerRef = useRef(null);
  const [draggedElement, setDraggedElement] = useState(null);
  const [gridSnappingEnabled, setGridSnappingEnabled] = useState(true);
  const [historyManager] = useState(() => {
    const manager = new HistoryManager(elements);
    return manager;
  });
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  useEffect(() => {
    const historyStatus = historyManager.addState(elements);
    setCanUndo(historyStatus.canUndo);
    setCanRedo(historyStatus.canRedo);
  }, [elements, historyManager]);
  const snapToGrid = (x, y) => {
    if (gridSnappingEnabled) {
      return {
        x: Math.round(x / gridSize) * gridSize,
        y: Math.round(y / gridSize) * gridSize
      };
    }
    return { x, y };
  };
  const toggleGridSnapping = () => {
    setGridSnappingEnabled((prev) => !prev);
  };
  const handleDragStart = (element, elementType) => {
    setDraggedElement({ element, elementType });
  };
  const updateHistory = (newState) => {
    const historyStatus = historyManager.addState(newState);
    setCanUndo(historyStatus.canUndo);
    setCanRedo(historyStatus.canRedo);
  };
  const handleDragEnd = (element, elementType, newPosition) => {
    const snappedPos = snapToGrid(newPosition.x, newPosition.y);
    if (elementType === "place") {
      setElements((prev) => {
        const newState = {
          ...prev,
          places: prev.places.map(
            (p) => p.id === element.id ? { ...p, x: snappedPos.x, y: snappedPos.y } : p
          )
        };
        updateHistory(newState);
        return newState;
      });
    } else if (elementType === "transition") {
      setElements((prev) => {
        const newState = {
          ...prev,
          transitions: prev.transitions.map(
            (t) => t.id === element.id ? { ...t, x: snappedPos.x, y: snappedPos.y } : t
          )
        };
        updateHistory(newState);
        return newState;
      });
    }
    setDraggedElement(null);
  };
  const addElement = (type, x, y) => {
    const snappedPos = snapToGrid(x, y);
    if (type === "place") {
      const newPlace = {
        id: `place-${Date.now()}`,
        x: snappedPos.x,
        y: snappedPos.y,
        name: `P${elements.places.length + 1}`,
        tokens: 0
      };
      setElements((prev) => {
        const newState = {
          ...prev,
          places: [...prev.places, newPlace]
        };
        updateHistory(newState);
        return newState;
      });
    } else if (type === "transition") {
      const newTransition = {
        id: `transition-${Date.now()}`,
        x: snappedPos.x,
        y: snappedPos.y,
        name: `T${elements.transitions.length + 1}`
      };
      setElements((prev) => {
        const newState = {
          ...prev,
          transitions: [...prev.transitions, newTransition]
        };
        updateHistory(newState);
        return newState;
      });
    }
  };
  const handleStageClick = (e) => {
    const stage = e.target.getStage();
    const pointerPosition = stage.getPointerPosition();
    const x = pointerPosition.x;
    const y = pointerPosition.y;
    const clickedOnEmptyCanvas = e.target === stage || e.target.name() === "background";
    if (mode === "place") {
      addElement("place", x, y);
    } else if (mode === "transition") {
      addElement("transition", x, y);
    } else if (mode === "arc" && arcStart && clickedOnEmptyCanvas) {
      console.log("Arc creation canceled");
      setArcStart(null);
      setTempArcEnd(null);
    }
  };
  const getCardinalPoints = (element, elementType) => {
    const points = {};
    if (elementType === "place") {
      const radius = 20;
      points.north = { x: element.x, y: element.y - radius };
      points.south = { x: element.x, y: element.y + radius };
      points.east = { x: element.x + radius, y: element.y };
      points.west = { x: element.x - radius, y: element.y };
    } else if (elementType === "transition") {
      const width = 30;
      const height = 40;
      points.north = { x: element.x, y: element.y - height / 2 };
      points.south = { x: element.x, y: element.y + height / 2 };
      points.east = { x: element.x + width / 2, y: element.y };
      points.west = { x: element.x - width / 2, y: element.y };
    }
    return points;
  };
  const findNearestCardinalPoint = (element, elementType, position) => {
    const points = getCardinalPoints(element, elementType);
    let nearest = "north";
    let minDistance = Infinity;
    Object.entries(points).forEach(([direction, point]) => {
      const dx = point.x - position.x;
      const dy = point.y - position.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      if (distance < minDistance) {
        minDistance = distance;
        nearest = direction;
      }
    });
    return { direction: nearest, point: points[nearest] };
  };
  const findPotentialTarget = (x, y) => {
    const sourceType = arcStart.elementType;
    const validTargetType = sourceType === "place" ? "transition" : "place";
    const targetElements = validTargetType === "place" ? elements.places : elements.transitions;
    const validTargets = targetElements.filter((el) => el.id !== arcStart.element.id);
    const snapRadius = 50;
    let closestElement = null;
    let minDistance = snapRadius;
    let closestPoint = null;
    validTargets.forEach((element) => {
      const points = getCardinalPoints(element, validTargetType);
      Object.entries(points).forEach(([direction, point]) => {
        const dx = point.x - x;
        const dy = point.y - y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < minDistance) {
          minDistance = distance;
          closestElement = element;
          closestPoint = { direction, point };
        }
      });
    });
    return closestElement ? { element: closestElement, type: validTargetType, point: closestPoint } : null;
  };
  const handleMouseMove = (e) => {
    if (mode === "arc" && arcStart) {
      const stage = e.target.getStage();
      const pointerPosition = stage.getPointerPosition();
      const sourcePoint = findNearestCardinalPoint(
        arcStart.element,
        arcStart.elementType,
        pointerPosition
      ).point;
      const potentialTarget = findPotentialTarget(pointerPosition.x, pointerPosition.y);
      setTempArcEnd({
        sourcePoint,
        x: potentialTarget ? potentialTarget.point.point.x : pointerPosition.x,
        y: potentialTarget ? potentialTarget.point.point.y : pointerPosition.y,
        potentialTarget
      });
    }
  };
  const handleElementClick = (element, elementType) => {
    if (mode === "arc") {
      if (!arcStart) {
        setArcStart({ element, elementType });
        console.log(`Arc creation started from ${elementType} ${element.id}`);
      } else {
        const startType = arcStart.elementType;
        const endType = elementType;
        if (startType === "place" && endType === "transition" || startType === "transition" && endType === "place") {
          let sourceDirection, targetDirection;
          if (tempArcEnd && tempArcEnd.potentialTarget && tempArcEnd.potentialTarget.element.id === element.id) {
            sourceDirection = findNearestCardinalPoint(
              arcStart.element,
              startType,
              tempArcEnd.potentialTarget.point.point
            ).direction;
            targetDirection = tempArcEnd.potentialTarget.point.direction;
          } else {
            const sourcePoint = findNearestCardinalPoint(
              arcStart.element,
              startType,
              { x: element.x, y: element.y }
            );
            const targetPoint = findNearestCardinalPoint(
              element,
              endType,
              { x: arcStart.element.x, y: arcStart.element.y }
            );
            sourceDirection = sourcePoint.direction;
            targetDirection = targetPoint.direction;
          }
          const newArc = {
            id: `arc-${Date.now()}`,
            sourceId: arcStart.element.id,
            sourceType: startType,
            targetId: element.id,
            targetType: endType,
            sourceDirection,
            targetDirection,
            weight: 1
          };
          setElements((prev) => {
            const newState = {
              ...prev,
              arcs: [...prev.arcs, newArc]
            };
            updateHistory(newState);
            return newState;
          });
          console.log(`Arc created from ${startType} to ${endType}`);
        } else {
          console.log(`Invalid arc connection: ${startType} to ${endType}`);
        }
        setArcStart(null);
        setTempArcEnd(null);
      }
    } else if (mode === "select") {
      setSelectedElement(element);
    }
  };
  const deleteSelectedElement = () => {
    if (!selectedElement)
      return;
    const elementType = selectedElement.id.split("-")[0];
    if (elementType === "arc") {
      setElements((prev) => {
        const newState = {
          ...prev,
          arcs: prev.arcs.filter((arc) => arc.id !== selectedElement.id)
        };
        updateHistory(newState);
        return newState;
      });
    } else if (elementType === "place" || elementType === "transition") {
      setElements((prev) => {
        const filteredArcs = prev.arcs.filter(
          (arc) => arc.sourceId !== selectedElement.id && arc.targetId !== selectedElement.id
        );
        let newState;
        if (elementType === "place") {
          newState = {
            ...prev,
            places: prev.places.filter((place) => place.id !== selectedElement.id),
            arcs: filteredArcs
          };
        } else {
          newState = {
            ...prev,
            transitions: prev.transitions.filter((transition) => transition.id !== selectedElement.id),
            arcs: filteredArcs
          };
        }
        updateHistory(newState);
        return newState;
      });
    }
    setSelectedElement(null);
  };
  const handleKeyDown = (e) => {
    if ((e.key === "Delete" || e.key === "Backspace") && selectedElement) {
      deleteSelectedElement();
    }
    if (e.ctrlKey && e.key === "z") {
      handleUndo();
    }
    if (e.ctrlKey && e.key === "y") {
      handleRedo();
    }
  };
  const handleUndo = () => {
    if (!canUndo)
      return;
    const result = historyManager.undo();
    if (result) {
      setElements(result.state);
      setCanUndo(result.canUndo);
      setCanRedo(result.canRedo);
    }
  };
  const handleRedo = () => {
    if (!canRedo)
      return;
    const result = historyManager.redo();
    if (result) {
      setElements(result.state);
      setCanUndo(result.canUndo);
      setCanRedo(result.canRedo);
    }
  };
  const cancelArcCreation = () => {
    setArcStart(null);
    setTempArcEnd(null);
  };
  const handleModeChange = (newMode) => {
    if (mode === "arc" && newMode !== "arc") {
      cancelArcCreation();
    }
    setMode(newMode);
  };
  React.useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [selectedElement, canUndo, canRedo]);
  React.useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const { clientWidth, clientHeight } = containerRef.current;
        setStageDimensions({
          width: clientWidth,
          height: clientHeight
        });
      }
    };
    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => {
      window.removeEventListener("resize", updateDimensions);
    };
  }, []);
  useEffect(() => {
    if ("development" === "development" || "development" === "test") {
      window.__PETRI_NET_STATE__ = elements;
    }
  }, [elements]);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col h-screen", ref: appRef, children: [
    /* @__PURE__ */ jsxDEV(
      Toolbar,
      {
        mode,
        setMode: handleModeChange,
        gridSnappingEnabled,
        toggleGridSnapping,
        canUndo,
        canRedo,
        onUndo: handleUndo,
        onRedo: handleRedo
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
        lineNumber: 549,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-hidden", ref: containerRef, children: /* @__PURE__ */ jsxDEV(
        Stage,
        {
          ref: stageRef,
          "data-testid": "canvas",
          width: stageDimensions.width,
          height: stageDimensions.height,
          onClick: handleStageClick,
          onMouseMove: handleMouseMove,
          className: "canvas-container",
          children: /* @__PURE__ */ jsxDEV(Layer, { children: [
            /* @__PURE__ */ jsxDEV(
              Rect,
              {
                x: 0,
                y: 0,
                width: stageDimensions.width,
                height: stageDimensions.height,
                fill: "transparent",
                name: "background"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
                lineNumber: 573,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Grid, { width: stageDimensions.width, height: stageDimensions.height, gridSize }, void 0, false, {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
              lineNumber: 583,
              columnNumber: 15
            }, this),
            elements.places.map(
              (place) => /* @__PURE__ */ jsxDEV(
                Place,
                {
                  place,
                  isSelected: selectedElement && selectedElement.id === place.id || arcStart && arcStart.element.id === place.id,
                  isDragging: draggedElement && draggedElement.element.id === place.id,
                  onClick: () => handleElementClick(place, "place"),
                  onDragStart: () => handleDragStart(place, "place"),
                  onDragMove: (e) => {
                    const rawPos = { x: e.target.x(), y: e.target.y() };
                    const snappedPos = snapToGrid(rawPos.x, rawPos.y);
                    e.target.position({
                      x: snappedPos.x,
                      y: snappedPos.y
                    });
                  },
                  onDragEnd: (e) => {
                    const newPos = { x: e.target.x(), y: e.target.y() };
                    handleDragEnd(place, "place", newPos);
                  }
                },
                place.id,
                false,
                {
                  fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
                  lineNumber: 587,
                  columnNumber: 15
                },
                this
              )
            ),
            elements.transitions.map(
              (transition) => /* @__PURE__ */ jsxDEV(
                Transition,
                {
                  transition,
                  isSelected: selectedElement && selectedElement.id === transition.id || arcStart && arcStart.element.id === transition.id,
                  isDragging: draggedElement && draggedElement.element.id === transition.id,
                  onClick: () => handleElementClick(transition, "transition"),
                  onDragStart: () => handleDragStart(transition, "transition"),
                  onDragMove: (e) => {
                    const rawPos = { x: e.target.x(), y: e.target.y() };
                    const snappedPos = snapToGrid(rawPos.x, rawPos.y);
                    e.target.position({
                      x: snappedPos.x,
                      y: snappedPos.y
                    });
                  },
                  onDragEnd: (e) => {
                    const newPos = { x: e.target.x(), y: e.target.y() };
                    handleDragEnd(transition, "transition", newPos);
                  }
                },
                transition.id,
                false,
                {
                  fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
                  lineNumber: 617,
                  columnNumber: 15
                },
                this
              )
            ),
            elements.arcs.map(
              (arc) => /* @__PURE__ */ jsxDEV(
                Arc,
                {
                  arc,
                  places: elements.places,
                  transitions: elements.transitions,
                  isSelected: selectedElement && selectedElement.id === arc.id,
                  onClick: () => setSelectedElement(arc)
                },
                arc.id,
                false,
                {
                  fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
                  lineNumber: 647,
                  columnNumber: 15
                },
                this
              )
            ),
            arcStart && tempArcEnd && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(
                Line,
                {
                  points: [
                    tempArcEnd.sourcePoint.x,
                    tempArcEnd.sourcePoint.y,
                    tempArcEnd.x,
                    tempArcEnd.y
                  ],
                  stroke: "#FF9800",
                  strokeWidth: 2,
                  dash: [5, 5]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
                  lineNumber: 660,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Circle,
                {
                  x: tempArcEnd.sourcePoint.x,
                  y: tempArcEnd.sourcePoint.y,
                  radius: 4,
                  fill: "#FF9800",
                  stroke: "white",
                  strokeWidth: 1
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
                  lineNumber: 672,
                  columnNumber: 19
                },
                this
              ),
              tempArcEnd.potentialTarget && /* @__PURE__ */ jsxDEV(
                Circle,
                {
                  x: tempArcEnd.potentialTarget.point.point.x,
                  y: tempArcEnd.potentialTarget.point.point.y,
                  radius: 4,
                  fill: "#FF9800",
                  stroke: "white",
                  strokeWidth: 1
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
                  lineNumber: 682,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
              lineNumber: 659,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
            lineNumber: 571,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
          lineNumber: 562,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
        lineNumber: 561,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        PropertiesPanel,
        {
          selectedElement,
          setElements
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
          lineNumber: 697,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
      lineNumber: 560,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ExecutionPanel, { elements }, void 0, false, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
      lineNumber: 703,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx",
    lineNumber: 548,
    columnNumber: 5
  }, this);
}
_s(App, "VvZdxuFjvioHQlqd/HU1scyz0IU=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaWhCTSxTQThHVSxVQTlHVjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqaEJOLE9BQU9BLFNBQVNDLFVBQVVDLFFBQVFDLGlCQUFpQjtBQUNuRCxTQUFTQyxPQUFPQyxPQUFPQyxNQUFNQyxRQUFRQyxZQUFZO0FBQ2pELE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFVBQVU7QUFDakIsU0FBU0Msc0JBQXNCO0FBRS9CLFNBQVNDLE1BQU07QUFBQUMsS0FBQTtBQUNiLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJbkIsU0FBUztBQUFBLElBQ3ZDb0IsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxJQUNiQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJeEIsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ3lCLE1BQU1DLE9BQU8sSUFBSTFCLFNBQVMsUUFBUTtBQUN6QyxRQUFNLENBQUMyQixVQUFVQyxXQUFXLElBQUk1QixTQUFTLElBQUk7QUFDN0MsUUFBTSxDQUFDNkIsWUFBWUMsYUFBYSxJQUFJOUIsU0FBUyxJQUFJO0FBQ2pELFFBQU0rQixXQUFXOUIsT0FBTyxJQUFJO0FBQzVCLFFBQU0rQixTQUFTL0IsT0FBTyxJQUFJO0FBRzFCLFFBQU0sQ0FBQ2dDLGlCQUFpQkMsa0JBQWtCLElBQUlsQyxTQUFTO0FBQUEsSUFDckRtQyxPQUFPO0FBQUEsSUFDUEMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELFFBQU1DLFdBQVc7QUFHakIsUUFBTUMsZUFBZXJDLE9BQU8sSUFBSTtBQUdoQyxRQUFNLENBQUNzQyxnQkFBZ0JDLGlCQUFpQixJQUFJeEMsU0FBUyxJQUFJO0FBR3pELFFBQU0sQ0FBQ3lDLHFCQUFxQkMsc0JBQXNCLElBQUkxQyxTQUFTLElBQUk7QUFHbkUsUUFBTSxDQUFDMkMsY0FBYyxJQUFJM0MsU0FBUyxNQUFNO0FBQ3RDLFVBQU00QyxVQUFVLElBQUk3QixlQUFlRyxRQUFRO0FBQzNDLFdBQU8wQjtBQUFBQSxFQUNULENBQUM7QUFDRCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSTlDLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUMrQyxTQUFTQyxVQUFVLElBQUloRCxTQUFTLEtBQUs7QUFFNUNFLFlBQVUsTUFBTTtBQUNkLFVBQU0rQyxnQkFBZ0JOLGVBQWVPLFNBQVNoQyxRQUFRO0FBQ3RENEIsZUFBV0csY0FBY0osT0FBTztBQUNoQ0csZUFBV0MsY0FBY0YsT0FBTztBQUFBLEVBQ2xDLEdBQUcsQ0FBQzdCLFVBQVV5QixjQUFjLENBQUM7QUFHN0IsUUFBTVEsYUFBYUEsQ0FBQ0MsR0FBR0MsTUFBTTtBQUUzQixRQUFJWixxQkFBcUI7QUFDdkIsYUFBTztBQUFBLFFBQ0xXLEdBQUdFLEtBQUtDLE1BQU1ILElBQUlmLFFBQVEsSUFBSUE7QUFBQUEsUUFDOUJnQixHQUFHQyxLQUFLQyxNQUFNRixJQUFJaEIsUUFBUSxJQUFJQTtBQUFBQSxNQUNoQztBQUFBLElBQ0Y7QUFFQSxXQUFPLEVBQUVlLEdBQUdDLEVBQUU7QUFBQSxFQUNoQjtBQUdBLFFBQU1HLHFCQUFxQkEsTUFBTTtBQUMvQmQsMkJBQXVCLENBQUFlLFNBQVEsQ0FBQ0EsSUFBSTtBQUFBLEVBQ3RDO0FBR0EsUUFBTUMsa0JBQWtCQSxDQUFDQyxTQUFTQyxnQkFBZ0I7QUFDaERwQixzQkFBa0IsRUFBRW1CLFNBQVNDLFlBQVksQ0FBQztBQUFBLEVBQzVDO0FBR0EsUUFBTUMsZ0JBQWdCQSxDQUFDQyxhQUFhO0FBQ2xDLFVBQU1iLGdCQUFnQk4sZUFBZU8sU0FBU1ksUUFBUTtBQUN0RGhCLGVBQVdHLGNBQWNKLE9BQU87QUFDaENHLGVBQVdDLGNBQWNGLE9BQU87QUFBQSxFQUNsQztBQUdBLFFBQU1nQixnQkFBZ0JBLENBQUNKLFNBQVNDLGFBQWFJLGdCQUFnQjtBQUUzRCxVQUFNQyxhQUFhZCxXQUFXYSxZQUFZWixHQUFHWSxZQUFZWCxDQUFDO0FBRzFELFFBQUlPLGdCQUFnQixTQUFTO0FBQzNCekMsa0JBQVksQ0FBQXNDLFNBQVE7QUFDbEIsY0FBTUssV0FBVztBQUFBLFVBQ2YsR0FBR0w7QUFBQUEsVUFDSHJDLFFBQVFxQyxLQUFLckMsT0FBTzhDO0FBQUFBLFlBQUksQ0FBQUMsTUFDdEJBLEVBQUVDLE9BQU9ULFFBQVFTLEtBQUssRUFBRSxHQUFHRCxHQUFHZixHQUFHYSxXQUFXYixHQUFHQyxHQUFHWSxXQUFXWixFQUFFLElBQUljO0FBQUFBLFVBQ3JFO0FBQUEsUUFDRjtBQUVBTixzQkFBY0MsUUFBUTtBQUN0QixlQUFPQTtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNILFdBQVdGLGdCQUFnQixjQUFjO0FBQ3ZDekMsa0JBQVksQ0FBQXNDLFNBQVE7QUFDbEIsY0FBTUssV0FBVztBQUFBLFVBQ2YsR0FBR0w7QUFBQUEsVUFDSHBDLGFBQWFvQyxLQUFLcEMsWUFBWTZDO0FBQUFBLFlBQUksQ0FBQUcsTUFDaENBLEVBQUVELE9BQU9ULFFBQVFTLEtBQUssRUFBRSxHQUFHQyxHQUFHakIsR0FBR2EsV0FBV2IsR0FBR0MsR0FBR1ksV0FBV1osRUFBRSxJQUFJZ0I7QUFBQUEsVUFDckU7QUFBQSxRQUNGO0FBRUFSLHNCQUFjQyxRQUFRO0FBQ3RCLGVBQU9BO0FBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0g7QUFHQXRCLHNCQUFrQixJQUFJO0FBQUEsRUFDeEI7QUFHQSxRQUFNOEIsYUFBYUEsQ0FBQ0MsTUFBTW5CLEdBQUdDLE1BQU07QUFDakMsVUFBTVksYUFBYWQsV0FBV0MsR0FBR0MsQ0FBQztBQUVsQyxRQUFJa0IsU0FBUyxTQUFTO0FBQ3BCLFlBQU1DLFdBQVc7QUFBQSxRQUNmSixJQUFJLFNBQVNLLEtBQUtDLElBQUksQ0FBQztBQUFBLFFBQ3ZCdEIsR0FBR2EsV0FBV2I7QUFBQUEsUUFDZEMsR0FBR1ksV0FBV1o7QUFBQUEsUUFDZHNCLE1BQU0sSUFBSXpELFNBQVNFLE9BQU93RCxTQUFTLENBQUM7QUFBQSxRQUNwQ0MsUUFBUTtBQUFBLE1BQ1Y7QUFDQTFELGtCQUFZLENBQUFzQyxTQUFRO0FBQ2xCLGNBQU1LLFdBQVc7QUFBQSxVQUNmLEdBQUdMO0FBQUFBLFVBQ0hyQyxRQUFRLENBQUMsR0FBR3FDLEtBQUtyQyxRQUFRb0QsUUFBUTtBQUFBLFFBQ25DO0FBRUFYLHNCQUFjQyxRQUFRO0FBQ3RCLGVBQU9BO0FBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0gsV0FBV1MsU0FBUyxjQUFjO0FBQ2hDLFlBQU1PLGdCQUFnQjtBQUFBLFFBQ3BCVixJQUFJLGNBQWNLLEtBQUtDLElBQUksQ0FBQztBQUFBLFFBQzVCdEIsR0FBR2EsV0FBV2I7QUFBQUEsUUFDZEMsR0FBR1ksV0FBV1o7QUFBQUEsUUFDZHNCLE1BQU0sSUFBSXpELFNBQVNHLFlBQVl1RCxTQUFTLENBQUM7QUFBQSxNQUMzQztBQUNBekQsa0JBQVksQ0FBQXNDLFNBQVE7QUFDbEIsY0FBTUssV0FBVztBQUFBLFVBQ2YsR0FBR0w7QUFBQUEsVUFDSHBDLGFBQWEsQ0FBQyxHQUFHb0MsS0FBS3BDLGFBQWF5RCxhQUFhO0FBQUEsUUFDbEQ7QUFFQWpCLHNCQUFjQyxRQUFRO0FBQ3RCLGVBQU9BO0FBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBR0EsUUFBTWlCLG1CQUFtQkEsQ0FBQ0MsTUFBTTtBQUU5QixVQUFNQyxRQUFRRCxFQUFFRSxPQUFPQyxTQUFTO0FBQ2hDLFVBQU1DLGtCQUFrQkgsTUFBTUksbUJBQW1CO0FBQ2pELFVBQU1qQyxJQUFJZ0MsZ0JBQWdCaEM7QUFDMUIsVUFBTUMsSUFBSStCLGdCQUFnQi9CO0FBSzFCLFVBQU1pQyx1QkFBdUJOLEVBQUVFLFdBQVdELFNBQVNELEVBQUVFLE9BQU9QLEtBQUssTUFBTTtBQUV2RSxRQUFJbEQsU0FBUyxTQUFTO0FBQ3BCNkMsaUJBQVcsU0FBU2xCLEdBQUdDLENBQUM7QUFBQSxJQUMxQixXQUFXNUIsU0FBUyxjQUFjO0FBQ2hDNkMsaUJBQVcsY0FBY2xCLEdBQUdDLENBQUM7QUFBQSxJQUMvQixXQUFXNUIsU0FBUyxTQUFTRSxZQUFZMkQsc0JBQXNCO0FBRzdEQyxjQUFRQyxJQUFJLHVCQUF1QjtBQUNuQzVELGtCQUFZLElBQUk7QUFDaEJFLG9CQUFjLElBQUk7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNMkQsb0JBQW9CQSxDQUFDOUIsU0FBU0MsZ0JBQWdCO0FBQ2xELFVBQU04QixTQUFTLENBQUM7QUFDaEIsUUFBSTlCLGdCQUFnQixTQUFTO0FBRTNCLFlBQU0rQixTQUFTO0FBQ2ZELGFBQU9FLFFBQVEsRUFBRXhDLEdBQUdPLFFBQVFQLEdBQUdDLEdBQUdNLFFBQVFOLElBQUlzQyxPQUFPO0FBQ3JERCxhQUFPRyxRQUFRLEVBQUV6QyxHQUFHTyxRQUFRUCxHQUFHQyxHQUFHTSxRQUFRTixJQUFJc0MsT0FBTztBQUNyREQsYUFBT0ksT0FBTyxFQUFFMUMsR0FBR08sUUFBUVAsSUFBSXVDLFFBQVF0QyxHQUFHTSxRQUFRTixFQUFFO0FBQ3BEcUMsYUFBT0ssT0FBTyxFQUFFM0MsR0FBR08sUUFBUVAsSUFBSXVDLFFBQVF0QyxHQUFHTSxRQUFRTixFQUFFO0FBQUEsSUFDdEQsV0FBV08sZ0JBQWdCLGNBQWM7QUFFdkMsWUFBTXpCLFFBQVE7QUFDZCxZQUFNQyxTQUFTO0FBQ2ZzRCxhQUFPRSxRQUFRLEVBQUV4QyxHQUFHTyxRQUFRUCxHQUFHQyxHQUFHTSxRQUFRTixJQUFJakIsU0FBTyxFQUFFO0FBQ3ZEc0QsYUFBT0csUUFBUSxFQUFFekMsR0FBR08sUUFBUVAsR0FBR0MsR0FBR00sUUFBUU4sSUFBSWpCLFNBQU8sRUFBRTtBQUN2RHNELGFBQU9JLE9BQU8sRUFBRTFDLEdBQUdPLFFBQVFQLElBQUlqQixRQUFNLEdBQUdrQixHQUFHTSxRQUFRTixFQUFFO0FBQ3JEcUMsYUFBT0ssT0FBTyxFQUFFM0MsR0FBR08sUUFBUVAsSUFBSWpCLFFBQU0sR0FBR2tCLEdBQUdNLFFBQVFOLEVBQUU7QUFBQSxJQUN2RDtBQUNBLFdBQU9xQztBQUFBQSxFQUNUO0FBR0EsUUFBTU0sMkJBQTJCQSxDQUFDckMsU0FBU0MsYUFBYXFDLGFBQWE7QUFDbkUsVUFBTVAsU0FBU0Qsa0JBQWtCOUIsU0FBU0MsV0FBVztBQUNyRCxRQUFJc0MsVUFBVTtBQUNkLFFBQUlDLGNBQWNDO0FBRWxCQyxXQUFPQyxRQUFRWixNQUFNLEVBQUVhLFFBQVEsQ0FBQyxDQUFDQyxXQUFXQyxLQUFLLE1BQU07QUFDckQsWUFBTUMsS0FBS0QsTUFBTXJELElBQUk2QyxTQUFTN0M7QUFDOUIsWUFBTXVELEtBQUtGLE1BQU1wRCxJQUFJNEMsU0FBUzVDO0FBQzlCLFlBQU11RCxXQUFXdEQsS0FBS3VELEtBQUtILEtBQUtBLEtBQUtDLEtBQUtBLEVBQUU7QUFFNUMsVUFBSUMsV0FBV1QsYUFBYTtBQUMxQkEsc0JBQWNTO0FBQ2RWLGtCQUFVTTtBQUFBQSxNQUNaO0FBQUEsSUFDRixDQUFDO0FBRUQsV0FBTyxFQUFFQSxXQUFXTixTQUFTTyxPQUFPZixPQUFPUSxPQUFPLEVBQUU7QUFBQSxFQUN0RDtBQUdBLFFBQU1ZLHNCQUFzQkEsQ0FBQzFELEdBQUdDLE1BQU07QUFFcEMsVUFBTTBELGFBQWFwRixTQUFTaUM7QUFDNUIsVUFBTW9ELGtCQUFrQkQsZUFBZSxVQUFVLGVBQWU7QUFHaEUsVUFBTUUsaUJBQWlCRCxvQkFBb0IsVUFBVTlGLFNBQVNFLFNBQVNGLFNBQVNHO0FBR2hGLFVBQU02RixlQUFlRCxlQUFlRSxPQUFPLENBQUFDLE9BQU1BLEdBQUdoRCxPQUFPekMsU0FBU2dDLFFBQVFTLEVBQUU7QUFHOUUsVUFBTWlELGFBQWE7QUFDbkIsUUFBSUMsaUJBQWlCO0FBQ3JCLFFBQUluQixjQUFja0I7QUFDbEIsUUFBSUUsZUFBZTtBQUVuQkwsaUJBQWFYLFFBQVEsQ0FBQTVDLFlBQVc7QUFDOUIsWUFBTStCLFNBQVNELGtCQUFrQjlCLFNBQVNxRCxlQUFlO0FBRXpEWCxhQUFPQyxRQUFRWixNQUFNLEVBQUVhLFFBQVEsQ0FBQyxDQUFDQyxXQUFXQyxLQUFLLE1BQU07QUFDckQsY0FBTUMsS0FBS0QsTUFBTXJELElBQUlBO0FBQ3JCLGNBQU11RCxLQUFLRixNQUFNcEQsSUFBSUE7QUFDckIsY0FBTXVELFdBQVd0RCxLQUFLdUQsS0FBS0gsS0FBS0EsS0FBS0MsS0FBS0EsRUFBRTtBQUU1QyxZQUFJQyxXQUFXVCxhQUFhO0FBQzFCQSx3QkFBY1M7QUFDZFUsMkJBQWlCM0Q7QUFDakI0RCx5QkFBZSxFQUFFZixXQUFXQyxNQUFNO0FBQUEsUUFDcEM7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFFRCxXQUFPYSxpQkFBaUIsRUFBRTNELFNBQVMyRCxnQkFBZ0IvQyxNQUFNeUMsaUJBQWlCUCxPQUFPYyxhQUFhLElBQUk7QUFBQSxFQUNwRztBQUdBLFFBQU1DLGtCQUFrQkEsQ0FBQ3hDLE1BQU07QUFDN0IsUUFBSXZELFNBQVMsU0FBU0UsVUFBVTtBQUM5QixZQUFNc0QsUUFBUUQsRUFBRUUsT0FBT0MsU0FBUztBQUNoQyxZQUFNQyxrQkFBa0JILE1BQU1JLG1CQUFtQjtBQUdqRCxZQUFNb0MsY0FBY3pCO0FBQUFBLFFBQ2xCckUsU0FBU2dDO0FBQUFBLFFBQ1RoQyxTQUFTaUM7QUFBQUEsUUFDVHdCO0FBQUFBLE1BQ0YsRUFBRXFCO0FBR0YsWUFBTWlCLGtCQUFrQlosb0JBQW9CMUIsZ0JBQWdCaEMsR0FBR2dDLGdCQUFnQi9CLENBQUM7QUFFaEZ2QixvQkFBYztBQUFBLFFBQ1oyRjtBQUFBQSxRQUNBckUsR0FBR3NFLGtCQUFrQkEsZ0JBQWdCakIsTUFBTUEsTUFBTXJELElBQUlnQyxnQkFBZ0JoQztBQUFBQSxRQUNyRUMsR0FBR3FFLGtCQUFrQkEsZ0JBQWdCakIsTUFBTUEsTUFBTXBELElBQUkrQixnQkFBZ0IvQjtBQUFBQSxRQUNyRXFFO0FBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBR0EsUUFBTUMscUJBQXFCQSxDQUFDaEUsU0FBU0MsZ0JBQWdCO0FBQ25ELFFBQUluQyxTQUFTLE9BQU87QUFDbEIsVUFBSSxDQUFDRSxVQUFVO0FBRWJDLG9CQUFZLEVBQUUrQixTQUFTQyxZQUFZLENBQUM7QUFDcEMyQixnQkFBUUMsSUFBSSw2QkFBNkI1QixXQUFXLElBQUlELFFBQVFTLEVBQUUsRUFBRTtBQUFBLE1BQ3RFLE9BQU87QUFFTCxjQUFNd0QsWUFBWWpHLFNBQVNpQztBQUMzQixjQUFNaUUsVUFBVWpFO0FBR2hCLFlBQUtnRSxjQUFjLFdBQVdDLFlBQVksZ0JBQ3JDRCxjQUFjLGdCQUFnQkMsWUFBWSxTQUFVO0FBSXZELGNBQUlDLGlCQUFpQkM7QUFFckIsY0FBSWxHLGNBQWNBLFdBQVc2RixtQkFDekI3RixXQUFXNkYsZ0JBQWdCL0QsUUFBUVMsT0FBT1QsUUFBUVMsSUFBSTtBQUV4RDBELDhCQUFrQjlCO0FBQUFBLGNBQ2hCckUsU0FBU2dDO0FBQUFBLGNBQ1RpRTtBQUFBQSxjQUNBL0YsV0FBVzZGLGdCQUFnQmpCLE1BQU1BO0FBQUFBLFlBQ25DLEVBQUVEO0FBRUZ1Qiw4QkFBa0JsRyxXQUFXNkYsZ0JBQWdCakIsTUFBTUQ7QUFBQUEsVUFDckQsT0FBTztBQUVMLGtCQUFNaUIsY0FBY3pCO0FBQUFBLGNBQ2xCckUsU0FBU2dDO0FBQUFBLGNBQ1RpRTtBQUFBQSxjQUNBLEVBQUV4RSxHQUFHTyxRQUFRUCxHQUFHQyxHQUFHTSxRQUFRTixFQUFFO0FBQUEsWUFDL0I7QUFFQSxrQkFBTTJFLGNBQWNoQztBQUFBQSxjQUNsQnJDO0FBQUFBLGNBQ0FrRTtBQUFBQSxjQUNBLEVBQUV6RSxHQUFHekIsU0FBU2dDLFFBQVFQLEdBQUdDLEdBQUcxQixTQUFTZ0MsUUFBUU4sRUFBRTtBQUFBLFlBQ2pEO0FBRUF5RSw4QkFBa0JMLFlBQVlqQjtBQUM5QnVCLDhCQUFrQkMsWUFBWXhCO0FBQUFBLFVBQ2hDO0FBRUEsZ0JBQU15QixTQUFTO0FBQUEsWUFDYjdELElBQUksT0FBT0ssS0FBS0MsSUFBSSxDQUFDO0FBQUEsWUFDckJ3RCxVQUFVdkcsU0FBU2dDLFFBQVFTO0FBQUFBLFlBQzNCMkMsWUFBWWE7QUFBQUEsWUFDWk8sVUFBVXhFLFFBQVFTO0FBQUFBLFlBQ2xCZ0UsWUFBWVA7QUFBQUEsWUFDWkM7QUFBQUEsWUFDQUM7QUFBQUEsWUFDQU0sUUFBUTtBQUFBLFVBQ1Y7QUFFQWxILHNCQUFZLENBQUFzQyxTQUFRO0FBQ2xCLGtCQUFNSyxXQUFXO0FBQUEsY0FDZixHQUFHTDtBQUFBQSxjQUNIbkMsTUFBTSxDQUFDLEdBQUdtQyxLQUFLbkMsTUFBTTJHLE1BQU07QUFBQSxZQUM3QjtBQUVBcEUsMEJBQWNDLFFBQVE7QUFDdEIsbUJBQU9BO0FBQUFBLFVBQ1QsQ0FBQztBQUNEeUIsa0JBQVFDLElBQUksb0JBQW9Cb0MsU0FBUyxPQUFPQyxPQUFPLEVBQUU7QUFBQSxRQUMzRCxPQUFPO0FBQ0x0QyxrQkFBUUMsSUFBSSwyQkFBMkJvQyxTQUFTLE9BQU9DLE9BQU8sRUFBRTtBQUFBLFFBQ2xFO0FBR0FqRyxvQkFBWSxJQUFJO0FBQ2hCRSxzQkFBYyxJQUFJO0FBQUEsTUFDcEI7QUFBQSxJQUNGLFdBQVdMLFNBQVMsVUFBVTtBQUU1QkQseUJBQW1CbUMsT0FBTztBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUdBLFFBQU0yRSx3QkFBd0JBLE1BQU07QUFDbEMsUUFBSSxDQUFDL0c7QUFBaUI7QUFHdEIsVUFBTXFDLGNBQWNyQyxnQkFBZ0I2QyxHQUFHbUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUVuRCxRQUFJM0UsZ0JBQWdCLE9BQU87QUFFekJ6QyxrQkFBWSxDQUFBc0MsU0FBUTtBQUNsQixjQUFNSyxXQUFXO0FBQUEsVUFDZixHQUFHTDtBQUFBQSxVQUNIbkMsTUFBTW1DLEtBQUtuQyxLQUFLNkYsT0FBTyxDQUFBcUIsUUFBT0EsSUFBSXBFLE9BQU83QyxnQkFBZ0I2QyxFQUFFO0FBQUEsUUFDN0Q7QUFFQVAsc0JBQWNDLFFBQVE7QUFDdEIsZUFBT0E7QUFBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSCxXQUFXRixnQkFBZ0IsV0FBV0EsZ0JBQWdCLGNBQWM7QUFFbEV6QyxrQkFBWSxDQUFBc0MsU0FBUTtBQUVsQixjQUFNZ0YsZUFBZWhGLEtBQUtuQyxLQUFLNkY7QUFBQUEsVUFBTyxDQUFBcUIsUUFDcENBLElBQUlOLGFBQWEzRyxnQkFBZ0I2QyxNQUFNb0UsSUFBSUwsYUFBYTVHLGdCQUFnQjZDO0FBQUFBLFFBQzFFO0FBR0EsWUFBSU47QUFDSixZQUFJRixnQkFBZ0IsU0FBUztBQUMzQkUscUJBQVc7QUFBQSxZQUNULEdBQUdMO0FBQUFBLFlBQ0hyQyxRQUFRcUMsS0FBS3JDLE9BQU8rRixPQUFPLENBQUF1QixVQUFTQSxNQUFNdEUsT0FBTzdDLGdCQUFnQjZDLEVBQUU7QUFBQSxZQUNuRTlDLE1BQU1tSDtBQUFBQSxVQUNSO0FBQUEsUUFDRixPQUFPO0FBQ0wzRSxxQkFBVztBQUFBLFlBQ1QsR0FBR0w7QUFBQUEsWUFDSHBDLGFBQWFvQyxLQUFLcEMsWUFBWThGLE9BQU8sQ0FBQXdCLGVBQWNBLFdBQVd2RSxPQUFPN0MsZ0JBQWdCNkMsRUFBRTtBQUFBLFlBQ3ZGOUMsTUFBTW1IO0FBQUFBLFVBQ1I7QUFBQSxRQUNGO0FBR0E1RSxzQkFBY0MsUUFBUTtBQUN0QixlQUFPQTtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBR0F0Qyx1QkFBbUIsSUFBSTtBQUFBLEVBQ3pCO0FBR0EsUUFBTW9ILGdCQUFnQkEsQ0FBQzVELE1BQU07QUFFM0IsU0FBS0EsRUFBRTZELFFBQVEsWUFBWTdELEVBQUU2RCxRQUFRLGdCQUFnQnRILGlCQUFpQjtBQUNwRStHLDRCQUFzQjtBQUFBLElBQ3hCO0FBR0EsUUFBSXRELEVBQUU4RCxXQUFXOUQsRUFBRTZELFFBQVEsS0FBSztBQUM5QkUsaUJBQVc7QUFBQSxJQUNiO0FBR0EsUUFBSS9ELEVBQUU4RCxXQUFXOUQsRUFBRTZELFFBQVEsS0FBSztBQUM5QkcsaUJBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUdBLFFBQU1ELGFBQWFBLE1BQU07QUFDdkIsUUFBSSxDQUFDbEc7QUFBUztBQUVkLFVBQU1vRyxTQUFTdEcsZUFBZXVHLEtBQUs7QUFDbkMsUUFBSUQsUUFBUTtBQUdWOUgsa0JBQVk4SCxPQUFPRSxLQUFLO0FBQ3hCckcsaUJBQVdtRyxPQUFPcEcsT0FBTztBQUN6QkcsaUJBQVdpRyxPQUFPbEcsT0FBTztBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUdBLFFBQU1pRyxhQUFhQSxNQUFNO0FBQ3ZCLFFBQUksQ0FBQ2pHO0FBQVM7QUFFZCxVQUFNa0csU0FBU3RHLGVBQWV5RyxLQUFLO0FBQ25DLFFBQUlILFFBQVE7QUFHVjlILGtCQUFZOEgsT0FBT0UsS0FBSztBQUN4QnJHLGlCQUFXbUcsT0FBT3BHLE9BQU87QUFDekJHLGlCQUFXaUcsT0FBT2xHLE9BQU87QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNc0csb0JBQW9CQSxNQUFNO0FBQzlCekgsZ0JBQVksSUFBSTtBQUNoQkUsa0JBQWMsSUFBSTtBQUFBLEVBQ3BCO0FBR0EsUUFBTXdILG1CQUFtQkEsQ0FBQ0MsWUFBWTtBQUNwQyxRQUFJOUgsU0FBUyxTQUFTOEgsWUFBWSxPQUFPO0FBQ3ZDRix3QkFBa0I7QUFBQSxJQUNwQjtBQUNBM0gsWUFBUTZILE9BQU87QUFBQSxFQUNqQjtBQUdBeEosUUFBTUcsVUFBVSxNQUFNO0FBRXBCc0osYUFBU0MsaUJBQWlCLFdBQVdiLGFBQWE7QUFHbEQsV0FBTyxNQUFNO0FBQ1hZLGVBQVNFLG9CQUFvQixXQUFXZCxhQUFhO0FBQUEsSUFDdkQ7QUFBQSxFQUNGLEdBQUcsQ0FBQ3JILGlCQUFpQnNCLFNBQVNFLE9BQU8sQ0FBQztBQUd0Q2hELFFBQU1HLFVBQVUsTUFBTTtBQUNwQixVQUFNeUosbUJBQW1CQSxNQUFNO0FBQzdCLFVBQUlySCxhQUFhc0gsU0FBUztBQUN4QixjQUFNLEVBQUVDLGFBQWFDLGFBQWEsSUFBSXhILGFBQWFzSDtBQUNuRDFILDJCQUFtQjtBQUFBLFVBQ2pCQyxPQUFPMEg7QUFBQUEsVUFDUHpILFFBQVEwSDtBQUFBQSxRQUNWLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUdBSCxxQkFBaUI7QUFHakJJLFdBQU9OLGlCQUFpQixVQUFVRSxnQkFBZ0I7QUFHbEQsV0FBTyxNQUFNO0FBQ1hJLGFBQU9MLG9CQUFvQixVQUFVQyxnQkFBZ0I7QUFBQSxJQUN2RDtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBR0x6SixZQUFVLE1BQU07QUFDZCxRQUFJOEosUUFBUUMsSUFBSUMsYUFBYSxpQkFBaUJGLFFBQVFDLElBQUlDLGFBQWEsUUFBUTtBQUM3RUgsYUFBT0ksc0JBQXNCako7QUFBQUEsSUFDL0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCLEtBQUtjLFFBQzNDO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxTQUFTc0g7QUFBQUEsUUFDVDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsUUFBUVA7QUFBQUEsUUFDUixRQUFRQztBQUFBQTtBQUFBQSxNQVJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFxQjtBQUFBLElBR3JCLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQkFBeUIsS0FBSzFHLGNBQzNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxLQUFLUDtBQUFBQSxVQUNMLGVBQVk7QUFBQSxVQUNaLE9BQU9FLGdCQUFnQkU7QUFBQUEsVUFDdkIsUUFBUUYsZ0JBQWdCRztBQUFBQSxVQUN4QixTQUFTMkM7QUFBQUEsVUFDVCxhQUFheUM7QUFBQUEsVUFDYixXQUFVO0FBQUEsVUFFVixpQ0FBQyxTQUVDO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxHQUFHO0FBQUEsZ0JBQ0gsR0FBRztBQUFBLGdCQUNILE9BQU92RixnQkFBZ0JFO0FBQUFBLGdCQUN2QixRQUFRRixnQkFBZ0JHO0FBQUFBLGdCQUN4QixNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBO0FBQUEsY0FOUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNbUI7QUFBQSxZQUluQix1QkFBQyxRQUFLLE9BQU9ILGdCQUFnQkUsT0FBTyxRQUFRRixnQkFBZ0JHLFFBQVEsWUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxZQUd0RmxCLFNBQVNFLE9BQU84QztBQUFBQSxjQUFJLENBQUF3RSxVQUNuQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQztBQUFBLGtCQUNBLFlBQVluSCxtQkFBbUJBLGdCQUFnQjZDLE9BQU9zRSxNQUFNdEUsTUFDekR6QyxZQUFZQSxTQUFTZ0MsUUFBUVMsT0FBT3NFLE1BQU10RTtBQUFBQSxrQkFDN0MsWUFBWTdCLGtCQUFrQkEsZUFBZW9CLFFBQVFTLE9BQU9zRSxNQUFNdEU7QUFBQUEsa0JBQ2xFLFNBQVMsTUFBTXVELG1CQUFtQmUsT0FBTyxPQUFPO0FBQUEsa0JBQ2hELGFBQWEsTUFBTWhGLGdCQUFnQmdGLE9BQU8sT0FBTztBQUFBLGtCQUNqRCxZQUFZLENBQUMxRCxNQUFNO0FBRWpCLDBCQUFNb0YsU0FBUyxFQUFFaEgsR0FBRzRCLEVBQUVFLE9BQU85QixFQUFFLEdBQUdDLEdBQUcyQixFQUFFRSxPQUFPN0IsRUFBRSxFQUFFO0FBR2xELDBCQUFNWSxhQUFhZCxXQUFXaUgsT0FBT2hILEdBQUdnSCxPQUFPL0csQ0FBQztBQUdoRDJCLHNCQUFFRSxPQUFPZSxTQUFTO0FBQUEsc0JBQ2hCN0MsR0FBR2EsV0FBV2I7QUFBQUEsc0JBQ2RDLEdBQUdZLFdBQVdaO0FBQUFBLG9CQUNoQixDQUFDO0FBQUEsa0JBQ0g7QUFBQSxrQkFDQSxXQUFXLENBQUMyQixNQUFNO0FBQ2hCLDBCQUFNcUYsU0FBUyxFQUFFakgsR0FBRzRCLEVBQUVFLE9BQU85QixFQUFFLEdBQUdDLEdBQUcyQixFQUFFRSxPQUFPN0IsRUFBRSxFQUFFO0FBQ2xEVSxrQ0FBYzJFLE9BQU8sU0FBUzJCLE1BQU07QUFBQSxrQkFDdEM7QUFBQTtBQUFBLGdCQXZCSzNCLE1BQU10RTtBQUFBQSxnQkFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBd0JJO0FBQUEsWUFFTDtBQUFBLFlBR0FsRCxTQUFTRyxZQUFZNkM7QUFBQUEsY0FBSSxDQUFBeUUsZUFDeEI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUM7QUFBQSxrQkFDQSxZQUFZcEgsbUJBQW1CQSxnQkFBZ0I2QyxPQUFPdUUsV0FBV3ZFLE1BQzlEekMsWUFBWUEsU0FBU2dDLFFBQVFTLE9BQU91RSxXQUFXdkU7QUFBQUEsa0JBQ2xELFlBQVk3QixrQkFBa0JBLGVBQWVvQixRQUFRUyxPQUFPdUUsV0FBV3ZFO0FBQUFBLGtCQUN2RSxTQUFTLE1BQU11RCxtQkFBbUJnQixZQUFZLFlBQVk7QUFBQSxrQkFDMUQsYUFBYSxNQUFNakYsZ0JBQWdCaUYsWUFBWSxZQUFZO0FBQUEsa0JBQzNELFlBQVksQ0FBQzNELE1BQU07QUFFakIsMEJBQU1vRixTQUFTLEVBQUVoSCxHQUFHNEIsRUFBRUUsT0FBTzlCLEVBQUUsR0FBR0MsR0FBRzJCLEVBQUVFLE9BQU83QixFQUFFLEVBQUU7QUFHbEQsMEJBQU1ZLGFBQWFkLFdBQVdpSCxPQUFPaEgsR0FBR2dILE9BQU8vRyxDQUFDO0FBR2hEMkIsc0JBQUVFLE9BQU9lLFNBQVM7QUFBQSxzQkFDaEI3QyxHQUFHYSxXQUFXYjtBQUFBQSxzQkFDZEMsR0FBR1ksV0FBV1o7QUFBQUEsb0JBQ2hCLENBQUM7QUFBQSxrQkFDSDtBQUFBLGtCQUNBLFdBQVcsQ0FBQzJCLE1BQU07QUFDaEIsMEJBQU1xRixTQUFTLEVBQUVqSCxHQUFHNEIsRUFBRUUsT0FBTzlCLEVBQUUsR0FBR0MsR0FBRzJCLEVBQUVFLE9BQU83QixFQUFFLEVBQUU7QUFDbERVLGtDQUFjNEUsWUFBWSxjQUFjMEIsTUFBTTtBQUFBLGtCQUNoRDtBQUFBO0FBQUEsZ0JBdkJLMUIsV0FBV3ZFO0FBQUFBLGdCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBd0JJO0FBQUEsWUFFTDtBQUFBLFlBR0FsRCxTQUFTSSxLQUFLNEM7QUFBQUEsY0FBSSxDQUFBc0UsUUFDakI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUM7QUFBQSxrQkFDQSxRQUFRdEgsU0FBU0U7QUFBQUEsa0JBQ2pCLGFBQWFGLFNBQVNHO0FBQUFBLGtCQUN0QixZQUFZRSxtQkFBbUJBLGdCQUFnQjZDLE9BQU9vRSxJQUFJcEU7QUFBQUEsa0JBQzFELFNBQVMsTUFBTTVDLG1CQUFtQmdILEdBQUc7QUFBQTtBQUFBLGdCQUxoQ0EsSUFBSXBFO0FBQUFBLGdCQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNeUM7QUFBQSxZQUUxQztBQUFBLFlBR0F6QyxZQUFZRSxjQUNYLG1DQUNFO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsUUFBUTtBQUFBLG9CQUNOQSxXQUFXNEYsWUFBWXJFO0FBQUFBLG9CQUN2QnZCLFdBQVc0RixZQUFZcEU7QUFBQUEsb0JBQ3ZCeEIsV0FBV3VCO0FBQUFBLG9CQUNYdkIsV0FBV3dCO0FBQUFBLGtCQUFDO0FBQUEsa0JBRWQsUUFBTztBQUFBLGtCQUNQLGFBQWE7QUFBQSxrQkFDYixNQUFNLENBQUMsR0FBRyxDQUFDO0FBQUE7QUFBQSxnQkFUYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTZTtBQUFBLGNBR2Y7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsR0FBR3hCLFdBQVc0RixZQUFZckU7QUFBQUEsa0JBQzFCLEdBQUd2QixXQUFXNEYsWUFBWXBFO0FBQUFBLGtCQUMxQixRQUFRO0FBQUEsa0JBQ1IsTUFBSztBQUFBLGtCQUNMLFFBQU87QUFBQSxrQkFDUCxhQUFhO0FBQUE7QUFBQSxnQkFOZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNaUI7QUFBQSxjQUdoQnhCLFdBQVc2RixtQkFDVjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxHQUFHN0YsV0FBVzZGLGdCQUFnQmpCLE1BQU1BLE1BQU1yRDtBQUFBQSxrQkFDMUMsR0FBR3ZCLFdBQVc2RixnQkFBZ0JqQixNQUFNQSxNQUFNcEQ7QUFBQUEsa0JBQzFDLFFBQVE7QUFBQSxrQkFDUixNQUFLO0FBQUEsa0JBQ0wsUUFBTztBQUFBLGtCQUNQLGFBQWE7QUFBQTtBQUFBLGdCQU5mO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1pQjtBQUFBLGlCQTdCckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQ0E7QUFBQSxlQXhISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBIQTtBQUFBO0FBQUEsUUFuSUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bb0lBLEtBcklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzSUE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRTJCO0FBQUEsU0EzSTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2SUE7QUFBQSxJQUVBLHVCQUFDLGtCQUFlLFlBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUM7QUFBQSxPQTNKckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRKQTtBQUVKO0FBQUNwQyxHQW5xQlFELEtBQUc7QUFBQXNKLEtBQUh0SjtBQXFxQlQsZUFBZUE7QUFBSSxJQUFBc0o7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJTdGFnZSIsIkxheWVyIiwiTGluZSIsIkNpcmNsZSIsIlJlY3QiLCJUb29sYmFyIiwiUHJvcGVydGllc1BhbmVsIiwiRXhlY3V0aW9uUGFuZWwiLCJQbGFjZSIsIlRyYW5zaXRpb24iLCJBcmMiLCJHcmlkIiwiSGlzdG9yeU1hbmFnZXIiLCJBcHAiLCJfcyIsImVsZW1lbnRzIiwic2V0RWxlbWVudHMiLCJwbGFjZXMiLCJ0cmFuc2l0aW9ucyIsImFyY3MiLCJzZWxlY3RlZEVsZW1lbnQiLCJzZXRTZWxlY3RlZEVsZW1lbnQiLCJtb2RlIiwic2V0TW9kZSIsImFyY1N0YXJ0Iiwic2V0QXJjU3RhcnQiLCJ0ZW1wQXJjRW5kIiwic2V0VGVtcEFyY0VuZCIsInN0YWdlUmVmIiwiYXBwUmVmIiwic3RhZ2VEaW1lbnNpb25zIiwic2V0U3RhZ2VEaW1lbnNpb25zIiwid2lkdGgiLCJoZWlnaHQiLCJncmlkU2l6ZSIsImNvbnRhaW5lclJlZiIsImRyYWdnZWRFbGVtZW50Iiwic2V0RHJhZ2dlZEVsZW1lbnQiLCJncmlkU25hcHBpbmdFbmFibGVkIiwic2V0R3JpZFNuYXBwaW5nRW5hYmxlZCIsImhpc3RvcnlNYW5hZ2VyIiwibWFuYWdlciIsImNhblVuZG8iLCJzZXRDYW5VbmRvIiwiY2FuUmVkbyIsInNldENhblJlZG8iLCJoaXN0b3J5U3RhdHVzIiwiYWRkU3RhdGUiLCJzbmFwVG9HcmlkIiwieCIsInkiLCJNYXRoIiwicm91bmQiLCJ0b2dnbGVHcmlkU25hcHBpbmciLCJwcmV2IiwiaGFuZGxlRHJhZ1N0YXJ0IiwiZWxlbWVudCIsImVsZW1lbnRUeXBlIiwidXBkYXRlSGlzdG9yeSIsIm5ld1N0YXRlIiwiaGFuZGxlRHJhZ0VuZCIsIm5ld1Bvc2l0aW9uIiwic25hcHBlZFBvcyIsIm1hcCIsInAiLCJpZCIsInQiLCJhZGRFbGVtZW50IiwidHlwZSIsIm5ld1BsYWNlIiwiRGF0ZSIsIm5vdyIsIm5hbWUiLCJsZW5ndGgiLCJ0b2tlbnMiLCJuZXdUcmFuc2l0aW9uIiwiaGFuZGxlU3RhZ2VDbGljayIsImUiLCJzdGFnZSIsInRhcmdldCIsImdldFN0YWdlIiwicG9pbnRlclBvc2l0aW9uIiwiZ2V0UG9pbnRlclBvc2l0aW9uIiwiY2xpY2tlZE9uRW1wdHlDYW52YXMiLCJjb25zb2xlIiwibG9nIiwiZ2V0Q2FyZGluYWxQb2ludHMiLCJwb2ludHMiLCJyYWRpdXMiLCJub3J0aCIsInNvdXRoIiwiZWFzdCIsIndlc3QiLCJmaW5kTmVhcmVzdENhcmRpbmFsUG9pbnQiLCJwb3NpdGlvbiIsIm5lYXJlc3QiLCJtaW5EaXN0YW5jZSIsIkluZmluaXR5IiwiT2JqZWN0IiwiZW50cmllcyIsImZvckVhY2giLCJkaXJlY3Rpb24iLCJwb2ludCIsImR4IiwiZHkiLCJkaXN0YW5jZSIsInNxcnQiLCJmaW5kUG90ZW50aWFsVGFyZ2V0Iiwic291cmNlVHlwZSIsInZhbGlkVGFyZ2V0VHlwZSIsInRhcmdldEVsZW1lbnRzIiwidmFsaWRUYXJnZXRzIiwiZmlsdGVyIiwiZWwiLCJzbmFwUmFkaXVzIiwiY2xvc2VzdEVsZW1lbnQiLCJjbG9zZXN0UG9pbnQiLCJoYW5kbGVNb3VzZU1vdmUiLCJzb3VyY2VQb2ludCIsInBvdGVudGlhbFRhcmdldCIsImhhbmRsZUVsZW1lbnRDbGljayIsInN0YXJ0VHlwZSIsImVuZFR5cGUiLCJzb3VyY2VEaXJlY3Rpb24iLCJ0YXJnZXREaXJlY3Rpb24iLCJ0YXJnZXRQb2ludCIsIm5ld0FyYyIsInNvdXJjZUlkIiwidGFyZ2V0SWQiLCJ0YXJnZXRUeXBlIiwid2VpZ2h0IiwiZGVsZXRlU2VsZWN0ZWRFbGVtZW50Iiwic3BsaXQiLCJhcmMiLCJmaWx0ZXJlZEFyY3MiLCJwbGFjZSIsInRyYW5zaXRpb24iLCJoYW5kbGVLZXlEb3duIiwia2V5IiwiY3RybEtleSIsImhhbmRsZVVuZG8iLCJoYW5kbGVSZWRvIiwicmVzdWx0IiwidW5kbyIsInN0YXRlIiwicmVkbyIsImNhbmNlbEFyY0NyZWF0aW9uIiwiaGFuZGxlTW9kZUNoYW5nZSIsIm5ld01vZGUiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwidXBkYXRlRGltZW5zaW9ucyIsImN1cnJlbnQiLCJjbGllbnRXaWR0aCIsImNsaWVudEhlaWdodCIsIndpbmRvdyIsInByb2Nlc3MiLCJlbnYiLCJOT0RFX0VOViIsIl9fUEVUUklfTkVUX1NUQVRFX18iLCJyYXdQb3MiLCJuZXdQb3MiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFN0YWdlLCBMYXllciwgTGluZSwgQ2lyY2xlLCBSZWN0IH0gZnJvbSAncmVhY3Qta29udmEnO1xuaW1wb3J0IFRvb2xiYXIgZnJvbSAnLi9jb21wb25lbnRzL1Rvb2xiYXInO1xuaW1wb3J0IFByb3BlcnRpZXNQYW5lbCBmcm9tICcuL2NvbXBvbmVudHMvUHJvcGVydGllc1BhbmVsJztcbmltcG9ydCBFeGVjdXRpb25QYW5lbCBmcm9tICcuL2NvbXBvbmVudHMvRXhlY3V0aW9uUGFuZWwnO1xuaW1wb3J0IFBsYWNlIGZyb20gJy4vY29tcG9uZW50cy9QbGFjZSc7XG5pbXBvcnQgVHJhbnNpdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvVHJhbnNpdGlvbic7XG5pbXBvcnQgQXJjIGZyb20gJy4vY29tcG9uZW50cy9BcmMnO1xuaW1wb3J0IEdyaWQgZnJvbSAnLi9jb21wb25lbnRzL0dyaWQnO1xuaW1wb3J0IHsgSGlzdG9yeU1hbmFnZXIgfSBmcm9tICcuL3V0aWxzL2hpc3RvcnlNYW5hZ2VyJztcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbZWxlbWVudHMsIHNldEVsZW1lbnRzXSA9IHVzZVN0YXRlKHtcbiAgICBwbGFjZXM6IFtdLFxuICAgIHRyYW5zaXRpb25zOiBbXSxcbiAgICBhcmNzOiBbXVxuICB9KTtcbiAgY29uc3QgW3NlbGVjdGVkRWxlbWVudCwgc2V0U2VsZWN0ZWRFbGVtZW50XSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZSgnc2VsZWN0Jyk7IC8vIHNlbGVjdCwgcGxhY2UsIHRyYW5zaXRpb24sIGFyY1xuICBjb25zdCBbYXJjU3RhcnQsIHNldEFyY1N0YXJ0XSA9IHVzZVN0YXRlKG51bGwpOyAvLyBGb3IgYXJjIGNyZWF0aW9uXG4gIGNvbnN0IFt0ZW1wQXJjRW5kLCBzZXRUZW1wQXJjRW5kXSA9IHVzZVN0YXRlKG51bGwpOyAvLyBGb3IgdmlzdWFsIGZlZWRiYWNrIGR1cmluZyBhcmMgY3JlYXRpb25cbiAgY29uc3Qgc3RhZ2VSZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IGFwcFJlZiA9IHVzZVJlZihudWxsKTsgLy8gUmVmZXJlbmNlIHRvIHRoZSBhcHAgY29udGFpbmVyIGZvciBrZXlib2FyZCBldmVudHNcblxuICAvLyBVc2Ugc3RhdGUgZm9yIHN0YWdlIGRpbWVuc2lvbnMgdG8gYWxsb3cgZm9yIHJlc2l6aW5nXG4gIGNvbnN0IFtzdGFnZURpbWVuc2lvbnMsIHNldFN0YWdlRGltZW5zaW9uc10gPSB1c2VTdGF0ZSh7XG4gICAgd2lkdGg6IDgwMCxcbiAgICBoZWlnaHQ6IDYwMFxuICB9KTtcbiAgY29uc3QgZ3JpZFNpemUgPSAyMDtcbiAgXG4gIC8vIFJlZmVyZW5jZSB0byB0aGUgY29udGFpbmVyIGRpdlxuICBjb25zdCBjb250YWluZXJSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgLy8gU3RhdGUgdG8gdHJhY2sgZWxlbWVudHMgYmVpbmcgZHJhZ2dlZCBmb3IgdmlzdWFsIGZlZWRiYWNrXG4gIGNvbnN0IFtkcmFnZ2VkRWxlbWVudCwgc2V0RHJhZ2dlZEVsZW1lbnRdID0gdXNlU3RhdGUobnVsbCk7XG4gIFxuICAvLyBTdGF0ZSB0byBjb250cm9sIGdyaWQgc25hcHBpbmdcbiAgY29uc3QgW2dyaWRTbmFwcGluZ0VuYWJsZWQsIHNldEdyaWRTbmFwcGluZ0VuYWJsZWRdID0gdXNlU3RhdGUodHJ1ZSk7XG4gIFxuICAvLyBIaXN0b3J5IG1hbmFnZXIgZm9yIHVuZG8vcmVkbyBmdW5jdGlvbmFsaXR5XG4gIGNvbnN0IFtoaXN0b3J5TWFuYWdlcl0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3QgbWFuYWdlciA9IG5ldyBIaXN0b3J5TWFuYWdlcihlbGVtZW50cyk7XG4gICAgcmV0dXJuIG1hbmFnZXI7XG4gIH0pO1xuICBjb25zdCBbY2FuVW5kbywgc2V0Q2FuVW5kb10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjYW5SZWRvLCBzZXRDYW5SZWRvXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhpc3RvcnlTdGF0dXMgPSBoaXN0b3J5TWFuYWdlci5hZGRTdGF0ZShlbGVtZW50cyk7XG4gICAgc2V0Q2FuVW5kbyhoaXN0b3J5U3RhdHVzLmNhblVuZG8pO1xuICAgIHNldENhblJlZG8oaGlzdG9yeVN0YXR1cy5jYW5SZWRvKTtcbiAgfSwgW2VsZW1lbnRzLCBoaXN0b3J5TWFuYWdlcl0pO1xuXG4gIC8vIEZ1bmN0aW9uIHRvIHNuYXAgcG9zaXRpb24gdG8gZ3JpZFxuICBjb25zdCBzbmFwVG9HcmlkID0gKHgsIHkpID0+IHtcbiAgICAvLyBPbmx5IHNuYXAgaWYgZ3JpZCBzbmFwcGluZyBpcyBlbmFibGVkXG4gICAgaWYgKGdyaWRTbmFwcGluZ0VuYWJsZWQpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHg6IE1hdGgucm91bmQoeCAvIGdyaWRTaXplKSAqIGdyaWRTaXplLFxuICAgICAgICB5OiBNYXRoLnJvdW5kKHkgLyBncmlkU2l6ZSkgKiBncmlkU2l6ZVxuICAgICAgfTtcbiAgICB9XG4gICAgLy8gT3RoZXJ3aXNlIHJldHVybiB0aGUgb3JpZ2luYWwgcG9zaXRpb25cbiAgICByZXR1cm4geyB4LCB5IH07XG4gIH07XG4gIFxuICAvLyBGdW5jdGlvbiB0byB0b2dnbGUgZ3JpZCBzbmFwcGluZ1xuICBjb25zdCB0b2dnbGVHcmlkU25hcHBpbmcgPSAoKSA9PiB7XG4gICAgc2V0R3JpZFNuYXBwaW5nRW5hYmxlZChwcmV2ID0+ICFwcmV2KTtcbiAgfTtcbiAgXG4gIC8vIEZ1bmN0aW9uIHRvIGhhbmRsZSB0aGUgc3RhcnQgb2YgZHJhZ2dpbmcgYW4gZWxlbWVudFxuICBjb25zdCBoYW5kbGVEcmFnU3RhcnQgPSAoZWxlbWVudCwgZWxlbWVudFR5cGUpID0+IHtcbiAgICBzZXREcmFnZ2VkRWxlbWVudCh7IGVsZW1lbnQsIGVsZW1lbnRUeXBlIH0pO1xuICB9O1xuICBcbiAgLy8gRnVuY3Rpb24gdG8gdXBkYXRlIGhpc3RvcnkgYWZ0ZXIgc3RhdGUgY2hhbmdlc1xuICBjb25zdCB1cGRhdGVIaXN0b3J5ID0gKG5ld1N0YXRlKSA9PiB7XG4gICAgY29uc3QgaGlzdG9yeVN0YXR1cyA9IGhpc3RvcnlNYW5hZ2VyLmFkZFN0YXRlKG5ld1N0YXRlKTtcbiAgICBzZXRDYW5VbmRvKGhpc3RvcnlTdGF0dXMuY2FuVW5kbyk7XG4gICAgc2V0Q2FuUmVkbyhoaXN0b3J5U3RhdHVzLmNhblJlZG8pO1xuICB9O1xuXG4gIC8vIEZ1bmN0aW9uIHRvIGhhbmRsZSB0aGUgZW5kIG9mIGRyYWdnaW5nIGFuIGVsZW1lbnRcbiAgY29uc3QgaGFuZGxlRHJhZ0VuZCA9IChlbGVtZW50LCBlbGVtZW50VHlwZSwgbmV3UG9zaXRpb24pID0+IHtcbiAgICAvLyBTbmFwIHRoZSBmaW5hbCBwb3NpdGlvbiB0byBncmlkXG4gICAgY29uc3Qgc25hcHBlZFBvcyA9IHNuYXBUb0dyaWQobmV3UG9zaXRpb24ueCwgbmV3UG9zaXRpb24ueSk7XG4gICAgXG4gICAgLy8gVXBkYXRlIHRoZSBlbGVtZW50J3MgcG9zaXRpb25cbiAgICBpZiAoZWxlbWVudFR5cGUgPT09ICdwbGFjZScpIHtcbiAgICAgIHNldEVsZW1lbnRzKHByZXYgPT4ge1xuICAgICAgICBjb25zdCBuZXdTdGF0ZSA9IHtcbiAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgIHBsYWNlczogcHJldi5wbGFjZXMubWFwKHAgPT4gXG4gICAgICAgICAgICBwLmlkID09PSBlbGVtZW50LmlkID8geyAuLi5wLCB4OiBzbmFwcGVkUG9zLngsIHk6IHNuYXBwZWRQb3MueSB9IDogcFxuICAgICAgICAgIClcbiAgICAgICAgfTtcbiAgICAgICAgLy8gQWRkIHRvIGhpc3RvcnkgYWZ0ZXIgc3RhdGUgdXBkYXRlXG4gICAgICAgIHVwZGF0ZUhpc3RvcnkobmV3U3RhdGUpO1xuICAgICAgICByZXR1cm4gbmV3U3RhdGU7XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKGVsZW1lbnRUeXBlID09PSAndHJhbnNpdGlvbicpIHtcbiAgICAgIHNldEVsZW1lbnRzKHByZXYgPT4ge1xuICAgICAgICBjb25zdCBuZXdTdGF0ZSA9IHtcbiAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgIHRyYW5zaXRpb25zOiBwcmV2LnRyYW5zaXRpb25zLm1hcCh0ID0+IFxuICAgICAgICAgICAgdC5pZCA9PT0gZWxlbWVudC5pZCA/IHsgLi4udCwgeDogc25hcHBlZFBvcy54LCB5OiBzbmFwcGVkUG9zLnkgfSA6IHRcbiAgICAgICAgICApXG4gICAgICAgIH07XG4gICAgICAgIC8vIEFkZCB0byBoaXN0b3J5IGFmdGVyIHN0YXRlIHVwZGF0ZVxuICAgICAgICB1cGRhdGVIaXN0b3J5KG5ld1N0YXRlKTtcbiAgICAgICAgcmV0dXJuIG5ld1N0YXRlO1xuICAgICAgfSk7XG4gICAgfVxuICAgIFxuICAgIC8vIENsZWFyIHRoZSBkcmFnZ2VkIGVsZW1lbnQgc3RhdGVcbiAgICBzZXREcmFnZ2VkRWxlbWVudChudWxsKTtcbiAgfTtcblxuICAvLyBGdW5jdGlvbiB0byBhZGQgYSBuZXcgZWxlbWVudCB0byB0aGUgY2FudmFzXG4gIGNvbnN0IGFkZEVsZW1lbnQgPSAodHlwZSwgeCwgeSkgPT4ge1xuICAgIGNvbnN0IHNuYXBwZWRQb3MgPSBzbmFwVG9HcmlkKHgsIHkpO1xuICAgIFxuICAgIGlmICh0eXBlID09PSAncGxhY2UnKSB7XG4gICAgICBjb25zdCBuZXdQbGFjZSA9IHtcbiAgICAgICAgaWQ6IGBwbGFjZS0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgeDogc25hcHBlZFBvcy54LFxuICAgICAgICB5OiBzbmFwcGVkUG9zLnksXG4gICAgICAgIG5hbWU6IGBQJHtlbGVtZW50cy5wbGFjZXMubGVuZ3RoICsgMX1gLFxuICAgICAgICB0b2tlbnM6IDBcbiAgICAgIH07XG4gICAgICBzZXRFbGVtZW50cyhwcmV2ID0+IHtcbiAgICAgICAgY29uc3QgbmV3U3RhdGUgPSB7XG4gICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICBwbGFjZXM6IFsuLi5wcmV2LnBsYWNlcywgbmV3UGxhY2VdXG4gICAgICAgIH07XG4gICAgICAgIC8vIEFkZCB0byBoaXN0b3J5IGFmdGVyIHN0YXRlIHVwZGF0ZVxuICAgICAgICB1cGRhdGVIaXN0b3J5KG5ld1N0YXRlKTtcbiAgICAgICAgcmV0dXJuIG5ld1N0YXRlO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSAndHJhbnNpdGlvbicpIHtcbiAgICAgIGNvbnN0IG5ld1RyYW5zaXRpb24gPSB7XG4gICAgICAgIGlkOiBgdHJhbnNpdGlvbi0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgeDogc25hcHBlZFBvcy54LFxuICAgICAgICB5OiBzbmFwcGVkUG9zLnksXG4gICAgICAgIG5hbWU6IGBUJHtlbGVtZW50cy50cmFuc2l0aW9ucy5sZW5ndGggKyAxfWBcbiAgICAgIH07XG4gICAgICBzZXRFbGVtZW50cyhwcmV2ID0+IHtcbiAgICAgICAgY29uc3QgbmV3U3RhdGUgPSB7XG4gICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICB0cmFuc2l0aW9uczogWy4uLnByZXYudHJhbnNpdGlvbnMsIG5ld1RyYW5zaXRpb25dXG4gICAgICAgIH07XG4gICAgICAgIC8vIEFkZCB0byBoaXN0b3J5IGFmdGVyIHN0YXRlIHVwZGF0ZVxuICAgICAgICB1cGRhdGVIaXN0b3J5KG5ld1N0YXRlKTtcbiAgICAgICAgcmV0dXJuIG5ld1N0YXRlO1xuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEZ1bmN0aW9uIHRvIGhhbmRsZSBzdGFnZSBjbGlja1xuICBjb25zdCBoYW5kbGVTdGFnZUNsaWNrID0gKGUpID0+IHtcbiAgICAvLyBHZXQgcG9zaXRpb24gcmVsYXRpdmUgdG8gdGhlIHN0YWdlXG4gICAgY29uc3Qgc3RhZ2UgPSBlLnRhcmdldC5nZXRTdGFnZSgpO1xuICAgIGNvbnN0IHBvaW50ZXJQb3NpdGlvbiA9IHN0YWdlLmdldFBvaW50ZXJQb3NpdGlvbigpO1xuICAgIGNvbnN0IHggPSBwb2ludGVyUG9zaXRpb24ueDtcbiAgICBjb25zdCB5ID0gcG9pbnRlclBvc2l0aW9uLnk7XG4gICAgXG4gICAgLy8gSW4gS29udmEsIHdlIGNhbiBjaGVjayB0aGUgbmFtZSBvZiB0aGUgY2xpY2tlZCB0YXJnZXRcbiAgICAvLyBUaGUgTGF5ZXIgYW5kIFN0YWdlIGRvbid0IGhhdmUgbmFtZXMsIHNvIGlmIGUudGFyZ2V0Lm5hbWUoKSBpcyB1bmRlZmluZWQsXG4gICAgLy8gd2UgY2xpY2tlZCBvbiB0aGUgZW1wdHkgY2FudmFzXG4gICAgY29uc3QgY2xpY2tlZE9uRW1wdHlDYW52YXMgPSBlLnRhcmdldCA9PT0gc3RhZ2UgfHwgZS50YXJnZXQubmFtZSgpID09PSAnYmFja2dyb3VuZCc7XG4gICAgXG4gICAgaWYgKG1vZGUgPT09ICdwbGFjZScpIHtcbiAgICAgIGFkZEVsZW1lbnQoJ3BsYWNlJywgeCwgeSk7XG4gICAgfSBlbHNlIGlmIChtb2RlID09PSAndHJhbnNpdGlvbicpIHtcbiAgICAgIGFkZEVsZW1lbnQoJ3RyYW5zaXRpb24nLCB4LCB5KTtcbiAgICB9IGVsc2UgaWYgKG1vZGUgPT09ICdhcmMnICYmIGFyY1N0YXJ0ICYmIGNsaWNrZWRPbkVtcHR5Q2FudmFzKSB7XG4gICAgICAvLyBJZiB3ZSdyZSBpbiBhcmMgY3JlYXRpb24gbW9kZSBhbmQgaGF2ZSBzdGFydGVkIGFuIGFyYyxcbiAgICAgIC8vIGNsaWNraW5nIG9uIGFuIGVtcHR5IGFyZWEgY2FuY2VscyB0aGUgYXJjIGNyZWF0aW9uXG4gICAgICBjb25zb2xlLmxvZygnQXJjIGNyZWF0aW9uIGNhbmNlbGVkJyk7XG4gICAgICBzZXRBcmNTdGFydChudWxsKTtcbiAgICAgIHNldFRlbXBBcmNFbmQobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIENhbGN1bGF0ZSBjYXJkaW5hbCBwb2ludHMgZm9yIGFuIGVsZW1lbnRcbiAgY29uc3QgZ2V0Q2FyZGluYWxQb2ludHMgPSAoZWxlbWVudCwgZWxlbWVudFR5cGUpID0+IHtcbiAgICBjb25zdCBwb2ludHMgPSB7fTtcbiAgICBpZiAoZWxlbWVudFR5cGUgPT09ICdwbGFjZScpIHtcbiAgICAgIC8vIEZvciBwbGFjZXMgKGNpcmNsZXMpXG4gICAgICBjb25zdCByYWRpdXMgPSAyMDtcbiAgICAgIHBvaW50cy5ub3J0aCA9IHsgeDogZWxlbWVudC54LCB5OiBlbGVtZW50LnkgLSByYWRpdXMgfTtcbiAgICAgIHBvaW50cy5zb3V0aCA9IHsgeDogZWxlbWVudC54LCB5OiBlbGVtZW50LnkgKyByYWRpdXMgfTtcbiAgICAgIHBvaW50cy5lYXN0ID0geyB4OiBlbGVtZW50LnggKyByYWRpdXMsIHk6IGVsZW1lbnQueSB9O1xuICAgICAgcG9pbnRzLndlc3QgPSB7IHg6IGVsZW1lbnQueCAtIHJhZGl1cywgeTogZWxlbWVudC55IH07XG4gICAgfSBlbHNlIGlmIChlbGVtZW50VHlwZSA9PT0gJ3RyYW5zaXRpb24nKSB7XG4gICAgICAvLyBGb3IgdHJhbnNpdGlvbnMgKHJlY3RhbmdsZXMpXG4gICAgICBjb25zdCB3aWR0aCA9IDMwO1xuICAgICAgY29uc3QgaGVpZ2h0ID0gNDA7XG4gICAgICBwb2ludHMubm9ydGggPSB7IHg6IGVsZW1lbnQueCwgeTogZWxlbWVudC55IC0gaGVpZ2h0LzIgfTtcbiAgICAgIHBvaW50cy5zb3V0aCA9IHsgeDogZWxlbWVudC54LCB5OiBlbGVtZW50LnkgKyBoZWlnaHQvMiB9O1xuICAgICAgcG9pbnRzLmVhc3QgPSB7IHg6IGVsZW1lbnQueCArIHdpZHRoLzIsIHk6IGVsZW1lbnQueSB9O1xuICAgICAgcG9pbnRzLndlc3QgPSB7IHg6IGVsZW1lbnQueCAtIHdpZHRoLzIsIHk6IGVsZW1lbnQueSB9O1xuICAgIH1cbiAgICByZXR1cm4gcG9pbnRzO1xuICB9O1xuICBcbiAgLy8gRmluZCB0aGUgbmVhcmVzdCBjYXJkaW5hbCBwb2ludCB0byBhIHBvc2l0aW9uXG4gIGNvbnN0IGZpbmROZWFyZXN0Q2FyZGluYWxQb2ludCA9IChlbGVtZW50LCBlbGVtZW50VHlwZSwgcG9zaXRpb24pID0+IHtcbiAgICBjb25zdCBwb2ludHMgPSBnZXRDYXJkaW5hbFBvaW50cyhlbGVtZW50LCBlbGVtZW50VHlwZSk7XG4gICAgbGV0IG5lYXJlc3QgPSAnbm9ydGgnO1xuICAgIGxldCBtaW5EaXN0YW5jZSA9IEluZmluaXR5O1xuICAgIFxuICAgIE9iamVjdC5lbnRyaWVzKHBvaW50cykuZm9yRWFjaCgoW2RpcmVjdGlvbiwgcG9pbnRdKSA9PiB7XG4gICAgICBjb25zdCBkeCA9IHBvaW50LnggLSBwb3NpdGlvbi54O1xuICAgICAgY29uc3QgZHkgPSBwb2ludC55IC0gcG9zaXRpb24ueTtcbiAgICAgIGNvbnN0IGRpc3RhbmNlID0gTWF0aC5zcXJ0KGR4ICogZHggKyBkeSAqIGR5KTtcbiAgICAgIFxuICAgICAgaWYgKGRpc3RhbmNlIDwgbWluRGlzdGFuY2UpIHtcbiAgICAgICAgbWluRGlzdGFuY2UgPSBkaXN0YW5jZTtcbiAgICAgICAgbmVhcmVzdCA9IGRpcmVjdGlvbjtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBcbiAgICByZXR1cm4geyBkaXJlY3Rpb246IG5lYXJlc3QsIHBvaW50OiBwb2ludHNbbmVhcmVzdF0gfTtcbiAgfTtcblxuICAvLyBGdW5jdGlvbiB0byBmaW5kIHBvdGVudGlhbCB0YXJnZXQgZWxlbWVudHMgbmVhciBhIHBvaW50XG4gIGNvbnN0IGZpbmRQb3RlbnRpYWxUYXJnZXQgPSAoeCwgeSkgPT4ge1xuICAgIC8vIENoZWNrIGlmIHBvaW50IGlzIG5lYXIgYW55IHBsYWNlIG9yIHRyYW5zaXRpb24gdGhhdCBjb3VsZCBiZSBhIHZhbGlkIHRhcmdldFxuICAgIGNvbnN0IHNvdXJjZVR5cGUgPSBhcmNTdGFydC5lbGVtZW50VHlwZTtcbiAgICBjb25zdCB2YWxpZFRhcmdldFR5cGUgPSBzb3VyY2VUeXBlID09PSAncGxhY2UnID8gJ3RyYW5zaXRpb24nIDogJ3BsYWNlJztcbiAgICBcbiAgICAvLyBDaGVjayBlbGVtZW50cyBvZiB0aGUgdmFsaWQgdGFyZ2V0IHR5cGVcbiAgICBjb25zdCB0YXJnZXRFbGVtZW50cyA9IHZhbGlkVGFyZ2V0VHlwZSA9PT0gJ3BsYWNlJyA/IGVsZW1lbnRzLnBsYWNlcyA6IGVsZW1lbnRzLnRyYW5zaXRpb25zO1xuICAgIFxuICAgIC8vIERvbid0IGFsbG93IGNvbm5lY3RpbmcgdG8gdGhlIHNvdXJjZSBlbGVtZW50IGl0c2VsZlxuICAgIGNvbnN0IHZhbGlkVGFyZ2V0cyA9IHRhcmdldEVsZW1lbnRzLmZpbHRlcihlbCA9PiBlbC5pZCAhPT0gYXJjU3RhcnQuZWxlbWVudC5pZCk7XG4gICAgXG4gICAgLy8gRmluZCB0aGUgY2xvc2VzdCBlbGVtZW50IHdpdGhpbiBhIGNlcnRhaW4gcmFkaXVzXG4gICAgY29uc3Qgc25hcFJhZGl1cyA9IDUwOyAvLyBQaXhlbHNcbiAgICBsZXQgY2xvc2VzdEVsZW1lbnQgPSBudWxsO1xuICAgIGxldCBtaW5EaXN0YW5jZSA9IHNuYXBSYWRpdXM7XG4gICAgbGV0IGNsb3Nlc3RQb2ludCA9IG51bGw7XG4gICAgXG4gICAgdmFsaWRUYXJnZXRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICBjb25zdCBwb2ludHMgPSBnZXRDYXJkaW5hbFBvaW50cyhlbGVtZW50LCB2YWxpZFRhcmdldFR5cGUpO1xuICAgICAgXG4gICAgICBPYmplY3QuZW50cmllcyhwb2ludHMpLmZvckVhY2goKFtkaXJlY3Rpb24sIHBvaW50XSkgPT4ge1xuICAgICAgICBjb25zdCBkeCA9IHBvaW50LnggLSB4O1xuICAgICAgICBjb25zdCBkeSA9IHBvaW50LnkgLSB5O1xuICAgICAgICBjb25zdCBkaXN0YW5jZSA9IE1hdGguc3FydChkeCAqIGR4ICsgZHkgKiBkeSk7XG4gICAgICAgIFxuICAgICAgICBpZiAoZGlzdGFuY2UgPCBtaW5EaXN0YW5jZSkge1xuICAgICAgICAgIG1pbkRpc3RhbmNlID0gZGlzdGFuY2U7XG4gICAgICAgICAgY2xvc2VzdEVsZW1lbnQgPSBlbGVtZW50O1xuICAgICAgICAgIGNsb3Nlc3RQb2ludCA9IHsgZGlyZWN0aW9uLCBwb2ludCB9O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBcbiAgICByZXR1cm4gY2xvc2VzdEVsZW1lbnQgPyB7IGVsZW1lbnQ6IGNsb3Nlc3RFbGVtZW50LCB0eXBlOiB2YWxpZFRhcmdldFR5cGUsIHBvaW50OiBjbG9zZXN0UG9pbnQgfSA6IG51bGw7XG4gIH07XG5cbiAgLy8gRnVuY3Rpb24gdG8gaGFuZGxlIG1vdXNlIG1vdmUgZm9yIGFyYyBjcmVhdGlvbiB2aXN1YWwgZmVlZGJhY2tcbiAgY29uc3QgaGFuZGxlTW91c2VNb3ZlID0gKGUpID0+IHtcbiAgICBpZiAobW9kZSA9PT0gJ2FyYycgJiYgYXJjU3RhcnQpIHtcbiAgICAgIGNvbnN0IHN0YWdlID0gZS50YXJnZXQuZ2V0U3RhZ2UoKTtcbiAgICAgIGNvbnN0IHBvaW50ZXJQb3NpdGlvbiA9IHN0YWdlLmdldFBvaW50ZXJQb3NpdGlvbigpO1xuICAgICAgXG4gICAgICAvLyBGaW5kIHRoZSBuZWFyZXN0IGNhcmRpbmFsIHBvaW50IG9uIHRoZSBzb3VyY2UgZWxlbWVudFxuICAgICAgY29uc3Qgc291cmNlUG9pbnQgPSBmaW5kTmVhcmVzdENhcmRpbmFsUG9pbnQoXG4gICAgICAgIGFyY1N0YXJ0LmVsZW1lbnQsIFxuICAgICAgICBhcmNTdGFydC5lbGVtZW50VHlwZSwgXG4gICAgICAgIHBvaW50ZXJQb3NpdGlvblxuICAgICAgKS5wb2ludDtcbiAgICAgIFxuICAgICAgLy8gQ2hlY2sgaWYgbW91c2UgaXMgbmVhciBhIHBvdGVudGlhbCB0YXJnZXRcbiAgICAgIGNvbnN0IHBvdGVudGlhbFRhcmdldCA9IGZpbmRQb3RlbnRpYWxUYXJnZXQocG9pbnRlclBvc2l0aW9uLngsIHBvaW50ZXJQb3NpdGlvbi55KTtcbiAgICAgIFxuICAgICAgc2V0VGVtcEFyY0VuZCh7XG4gICAgICAgIHNvdXJjZVBvaW50LFxuICAgICAgICB4OiBwb3RlbnRpYWxUYXJnZXQgPyBwb3RlbnRpYWxUYXJnZXQucG9pbnQucG9pbnQueCA6IHBvaW50ZXJQb3NpdGlvbi54LFxuICAgICAgICB5OiBwb3RlbnRpYWxUYXJnZXQgPyBwb3RlbnRpYWxUYXJnZXQucG9pbnQucG9pbnQueSA6IHBvaW50ZXJQb3NpdGlvbi55LFxuICAgICAgICBwb3RlbnRpYWxUYXJnZXRcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICAvLyBGdW5jdGlvbiB0byBoYW5kbGUgZWxlbWVudCBjbGljayBmb3IgYXJjIGNyZWF0aW9uXG4gIGNvbnN0IGhhbmRsZUVsZW1lbnRDbGljayA9IChlbGVtZW50LCBlbGVtZW50VHlwZSkgPT4ge1xuICAgIGlmIChtb2RlID09PSAnYXJjJykge1xuICAgICAgaWYgKCFhcmNTdGFydCkge1xuICAgICAgICAvLyBTdGFydCBjcmVhdGluZyBhbiBhcmNcbiAgICAgICAgc2V0QXJjU3RhcnQoeyBlbGVtZW50LCBlbGVtZW50VHlwZSB9KTtcbiAgICAgICAgY29uc29sZS5sb2coYEFyYyBjcmVhdGlvbiBzdGFydGVkIGZyb20gJHtlbGVtZW50VHlwZX0gJHtlbGVtZW50LmlkfWApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gQ29tcGxldGUgdGhlIGFyYyBpZiB2YWxpZCBjb25uZWN0aW9uXG4gICAgICAgIGNvbnN0IHN0YXJ0VHlwZSA9IGFyY1N0YXJ0LmVsZW1lbnRUeXBlO1xuICAgICAgICBjb25zdCBlbmRUeXBlID0gZWxlbWVudFR5cGU7XG4gICAgICAgIFxuICAgICAgICAvLyBWYWxpZGF0ZTogYXJjcyBjYW4gb25seSBjb25uZWN0IHBsYWNlLT50cmFuc2l0aW9uIG9yIHRyYW5zaXRpb24tPnBsYWNlXG4gICAgICAgIGlmICgoc3RhcnRUeXBlID09PSAncGxhY2UnICYmIGVuZFR5cGUgPT09ICd0cmFuc2l0aW9uJykgfHxcbiAgICAgICAgICAgIChzdGFydFR5cGUgPT09ICd0cmFuc2l0aW9uJyAmJiBlbmRUeXBlID09PSAncGxhY2UnKSkge1xuICAgICAgICAgIFxuICAgICAgICAgIC8vIFVzZSB0aGUgY3VycmVudCB0ZW1wQXJjRW5kIGRhdGEgaWYgaXQgZXhpc3RzIGFuZCBoYXMgYSBwb3RlbnRpYWwgdGFyZ2V0XG4gICAgICAgICAgLy8gdGhhdCBtYXRjaGVzIHRoZSBjbGlja2VkIGVsZW1lbnRcbiAgICAgICAgICBsZXQgc291cmNlRGlyZWN0aW9uLCB0YXJnZXREaXJlY3Rpb247XG4gICAgICAgICAgXG4gICAgICAgICAgaWYgKHRlbXBBcmNFbmQgJiYgdGVtcEFyY0VuZC5wb3RlbnRpYWxUYXJnZXQgJiYgXG4gICAgICAgICAgICAgIHRlbXBBcmNFbmQucG90ZW50aWFsVGFyZ2V0LmVsZW1lbnQuaWQgPT09IGVsZW1lbnQuaWQpIHtcbiAgICAgICAgICAgIC8vIFVzZSB0aGUgc25hcHBlZCBwb2ludHMgZnJvbSB0aGUgdmlzdWFsIGZlZWRiYWNrXG4gICAgICAgICAgICBzb3VyY2VEaXJlY3Rpb24gPSBmaW5kTmVhcmVzdENhcmRpbmFsUG9pbnQoXG4gICAgICAgICAgICAgIGFyY1N0YXJ0LmVsZW1lbnQsXG4gICAgICAgICAgICAgIHN0YXJ0VHlwZSxcbiAgICAgICAgICAgICAgdGVtcEFyY0VuZC5wb3RlbnRpYWxUYXJnZXQucG9pbnQucG9pbnRcbiAgICAgICAgICAgICkuZGlyZWN0aW9uO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0YXJnZXREaXJlY3Rpb24gPSB0ZW1wQXJjRW5kLnBvdGVudGlhbFRhcmdldC5wb2ludC5kaXJlY3Rpb247XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIENhbGN1bGF0ZSB0aGUgYmVzdCBwb2ludHMgaWYgbm8gdmlzdWFsIGZlZWRiYWNrIGlzIGF2YWlsYWJsZVxuICAgICAgICAgICAgY29uc3Qgc291cmNlUG9pbnQgPSBmaW5kTmVhcmVzdENhcmRpbmFsUG9pbnQoXG4gICAgICAgICAgICAgIGFyY1N0YXJ0LmVsZW1lbnQsIFxuICAgICAgICAgICAgICBzdGFydFR5cGUsIFxuICAgICAgICAgICAgICB7IHg6IGVsZW1lbnQueCwgeTogZWxlbWVudC55IH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldFBvaW50ID0gZmluZE5lYXJlc3RDYXJkaW5hbFBvaW50KFxuICAgICAgICAgICAgICBlbGVtZW50LCBcbiAgICAgICAgICAgICAgZW5kVHlwZSwgXG4gICAgICAgICAgICAgIHsgeDogYXJjU3RhcnQuZWxlbWVudC54LCB5OiBhcmNTdGFydC5lbGVtZW50LnkgfVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgc291cmNlRGlyZWN0aW9uID0gc291cmNlUG9pbnQuZGlyZWN0aW9uO1xuICAgICAgICAgICAgdGFyZ2V0RGlyZWN0aW9uID0gdGFyZ2V0UG9pbnQuZGlyZWN0aW9uO1xuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICBjb25zdCBuZXdBcmMgPSB7XG4gICAgICAgICAgICBpZDogYGFyYy0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgICAgIHNvdXJjZUlkOiBhcmNTdGFydC5lbGVtZW50LmlkLFxuICAgICAgICAgICAgc291cmNlVHlwZTogc3RhcnRUeXBlLFxuICAgICAgICAgICAgdGFyZ2V0SWQ6IGVsZW1lbnQuaWQsXG4gICAgICAgICAgICB0YXJnZXRUeXBlOiBlbmRUeXBlLFxuICAgICAgICAgICAgc291cmNlRGlyZWN0aW9uLFxuICAgICAgICAgICAgdGFyZ2V0RGlyZWN0aW9uLFxuICAgICAgICAgICAgd2VpZ2h0OiAxXG4gICAgICAgICAgfTtcbiAgICAgICAgICBcbiAgICAgICAgICBzZXRFbGVtZW50cyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5ld1N0YXRlID0ge1xuICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICBhcmNzOiBbLi4ucHJldi5hcmNzLCBuZXdBcmNdXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgLy8gQWRkIHRvIGhpc3RvcnkgYWZ0ZXIgc3RhdGUgdXBkYXRlXG4gICAgICAgICAgICB1cGRhdGVIaXN0b3J5KG5ld1N0YXRlKTtcbiAgICAgICAgICAgIHJldHVybiBuZXdTdGF0ZTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgQXJjIGNyZWF0ZWQgZnJvbSAke3N0YXJ0VHlwZX0gdG8gJHtlbmRUeXBlfWApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBJbnZhbGlkIGFyYyBjb25uZWN0aW9uOiAke3N0YXJ0VHlwZX0gdG8gJHtlbmRUeXBlfWApO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAvLyBSZXNldCBhcmMgc3RhcnQgYW5kIHRlbXAgZW5kXG4gICAgICAgIHNldEFyY1N0YXJ0KG51bGwpO1xuICAgICAgICBzZXRUZW1wQXJjRW5kKG51bGwpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAobW9kZSA9PT0gJ3NlbGVjdCcpIHtcbiAgICAgIC8vIFNlbGVjdCB0aGUgZWxlbWVudFxuICAgICAgc2V0U2VsZWN0ZWRFbGVtZW50KGVsZW1lbnQpO1xuICAgIH1cbiAgfTtcblxuICAvLyBGdW5jdGlvbiB0byBkZWxldGUgdGhlIHNlbGVjdGVkIGVsZW1lbnRcbiAgY29uc3QgZGVsZXRlU2VsZWN0ZWRFbGVtZW50ID0gKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRFbGVtZW50KSByZXR1cm47XG4gICAgXG4gICAgLy8gRGV0ZXJtaW5lIHRoZSB0eXBlIG9mIHRoZSBzZWxlY3RlZCBlbGVtZW50XG4gICAgY29uc3QgZWxlbWVudFR5cGUgPSBzZWxlY3RlZEVsZW1lbnQuaWQuc3BsaXQoJy0nKVswXTsgLy8gZS5nLiwgJ3BsYWNlJywgJ3RyYW5zaXRpb24nLCAnYXJjJ1xuICAgIFxuICAgIGlmIChlbGVtZW50VHlwZSA9PT0gJ2FyYycpIHtcbiAgICAgIC8vIEp1c3QgZGVsZXRlIHRoZSBhcmNcbiAgICAgIHNldEVsZW1lbnRzKHByZXYgPT4ge1xuICAgICAgICBjb25zdCBuZXdTdGF0ZSA9IHtcbiAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgIGFyY3M6IHByZXYuYXJjcy5maWx0ZXIoYXJjID0+IGFyYy5pZCAhPT0gc2VsZWN0ZWRFbGVtZW50LmlkKVxuICAgICAgICB9O1xuICAgICAgICAvLyBBZGQgdG8gaGlzdG9yeSBhZnRlciBzdGF0ZSB1cGRhdGVcbiAgICAgICAgdXBkYXRlSGlzdG9yeShuZXdTdGF0ZSk7XG4gICAgICAgIHJldHVybiBuZXdTdGF0ZTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoZWxlbWVudFR5cGUgPT09ICdwbGFjZScgfHwgZWxlbWVudFR5cGUgPT09ICd0cmFuc2l0aW9uJykge1xuICAgICAgLy8gRGVsZXRlIHRoZSBlbGVtZW50IGFuZCBhbGwgY29ubmVjdGVkIGFyY3NcbiAgICAgIHNldEVsZW1lbnRzKHByZXYgPT4ge1xuICAgICAgICAvLyBGaWx0ZXIgb3V0IGFyY3MgY29ubmVjdGVkIHRvIHRoaXMgZWxlbWVudFxuICAgICAgICBjb25zdCBmaWx0ZXJlZEFyY3MgPSBwcmV2LmFyY3MuZmlsdGVyKGFyYyA9PiBcbiAgICAgICAgICBhcmMuc291cmNlSWQgIT09IHNlbGVjdGVkRWxlbWVudC5pZCAmJiBhcmMudGFyZ2V0SWQgIT09IHNlbGVjdGVkRWxlbWVudC5pZFxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgLy8gRmlsdGVyIG91dCB0aGUgZWxlbWVudCBpdHNlbGZcbiAgICAgICAgbGV0IG5ld1N0YXRlO1xuICAgICAgICBpZiAoZWxlbWVudFR5cGUgPT09ICdwbGFjZScpIHtcbiAgICAgICAgICBuZXdTdGF0ZSA9IHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICBwbGFjZXM6IHByZXYucGxhY2VzLmZpbHRlcihwbGFjZSA9PiBwbGFjZS5pZCAhPT0gc2VsZWN0ZWRFbGVtZW50LmlkKSxcbiAgICAgICAgICAgIGFyY3M6IGZpbHRlcmVkQXJjc1xuICAgICAgICAgIH07XG4gICAgICAgIH0gZWxzZSB7IC8vIHRyYW5zaXRpb25cbiAgICAgICAgICBuZXdTdGF0ZSA9IHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICB0cmFuc2l0aW9uczogcHJldi50cmFuc2l0aW9ucy5maWx0ZXIodHJhbnNpdGlvbiA9PiB0cmFuc2l0aW9uLmlkICE9PSBzZWxlY3RlZEVsZW1lbnQuaWQpLFxuICAgICAgICAgICAgYXJjczogZmlsdGVyZWRBcmNzXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gQWRkIHRvIGhpc3RvcnkgYWZ0ZXIgc3RhdGUgdXBkYXRlXG4gICAgICAgIHVwZGF0ZUhpc3RvcnkobmV3U3RhdGUpO1xuICAgICAgICByZXR1cm4gbmV3U3RhdGU7XG4gICAgICB9KTtcbiAgICB9XG4gICAgXG4gICAgLy8gQ2xlYXIgc2VsZWN0aW9uIGFmdGVyIGRlbGV0aW9uXG4gICAgc2V0U2VsZWN0ZWRFbGVtZW50KG51bGwpO1xuICB9O1xuICBcbiAgLy8gRnVuY3Rpb24gdG8gaGFuZGxlIGtleWJvYXJkIGV2ZW50c1xuICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGUpID0+IHtcbiAgICAvLyBEZWxldGUga2V5IChib3RoIHJlZ3VsYXIgRGVsZXRlIGFuZCBCYWNrc3BhY2UpXG4gICAgaWYgKChlLmtleSA9PT0gJ0RlbGV0ZScgfHwgZS5rZXkgPT09ICdCYWNrc3BhY2UnKSAmJiBzZWxlY3RlZEVsZW1lbnQpIHtcbiAgICAgIGRlbGV0ZVNlbGVjdGVkRWxlbWVudCgpO1xuICAgIH1cbiAgICBcbiAgICAvLyBVbmRvIHdpdGggQ3RybCtaXG4gICAgaWYgKGUuY3RybEtleSAmJiBlLmtleSA9PT0gJ3onKSB7XG4gICAgICBoYW5kbGVVbmRvKCk7XG4gICAgfVxuICAgIFxuICAgIC8vIFJlZG8gd2l0aCBDdHJsK1lcbiAgICBpZiAoZS5jdHJsS2V5ICYmIGUua2V5ID09PSAneScpIHtcbiAgICAgIGhhbmRsZVJlZG8oKTtcbiAgICB9XG4gIH07XG4gIFxuICAvLyBGdW5jdGlvbiB0byBoYW5kbGUgdW5kb1xuICBjb25zdCBoYW5kbGVVbmRvID0gKCkgPT4ge1xuICAgIGlmICghY2FuVW5kbykgcmV0dXJuO1xuICAgIFxuICAgIGNvbnN0IHJlc3VsdCA9IGhpc3RvcnlNYW5hZ2VyLnVuZG8oKTtcbiAgICBpZiAocmVzdWx0KSB7XG4gICAgICAvLyBEaXJlY3RseSBzZXQgdGhlIGVsZW1lbnRzIHdpdGhvdXQgZ29pbmcgdGhyb3VnaCB1cGRhdGVIaXN0b3J5XG4gICAgICAvLyB0byBhdm9pZCBhZGRpbmcgdGhlIHN0YXRlIGJhY2sgdG8gaGlzdG9yeVxuICAgICAgc2V0RWxlbWVudHMocmVzdWx0LnN0YXRlKTtcbiAgICAgIHNldENhblVuZG8ocmVzdWx0LmNhblVuZG8pO1xuICAgICAgc2V0Q2FuUmVkbyhyZXN1bHQuY2FuUmVkbyk7XG4gICAgfVxuICB9O1xuICBcbiAgLy8gRnVuY3Rpb24gdG8gaGFuZGxlIHJlZG9cbiAgY29uc3QgaGFuZGxlUmVkbyA9ICgpID0+IHtcbiAgICBpZiAoIWNhblJlZG8pIHJldHVybjtcbiAgICBcbiAgICBjb25zdCByZXN1bHQgPSBoaXN0b3J5TWFuYWdlci5yZWRvKCk7XG4gICAgaWYgKHJlc3VsdCkge1xuICAgICAgLy8gRGlyZWN0bHkgc2V0IHRoZSBlbGVtZW50cyB3aXRob3V0IGdvaW5nIHRocm91Z2ggdXBkYXRlSGlzdG9yeVxuICAgICAgLy8gdG8gYXZvaWQgYWRkaW5nIHRoZSBzdGF0ZSBiYWNrIHRvIGhpc3RvcnlcbiAgICAgIHNldEVsZW1lbnRzKHJlc3VsdC5zdGF0ZSk7XG4gICAgICBzZXRDYW5VbmRvKHJlc3VsdC5jYW5VbmRvKTtcbiAgICAgIHNldENhblJlZG8ocmVzdWx0LmNhblJlZG8pO1xuICAgIH1cbiAgfTtcbiAgXG4gIC8vIEZ1bmN0aW9uIHRvIGNhbmNlbCBhcmMgY3JlYXRpb25cbiAgY29uc3QgY2FuY2VsQXJjQ3JlYXRpb24gPSAoKSA9PiB7XG4gICAgc2V0QXJjU3RhcnQobnVsbCk7XG4gICAgc2V0VGVtcEFyY0VuZChudWxsKTtcbiAgfTtcblxuICAvLyBVcGRhdGUgbW9kZSBoYW5kbGVyIHRvIHJlc2V0IGFyYyBjcmVhdGlvbiBzdGF0ZVxuICBjb25zdCBoYW5kbGVNb2RlQ2hhbmdlID0gKG5ld01vZGUpID0+IHtcbiAgICBpZiAobW9kZSA9PT0gJ2FyYycgJiYgbmV3TW9kZSAhPT0gJ2FyYycpIHtcbiAgICAgIGNhbmNlbEFyY0NyZWF0aW9uKCk7XG4gICAgfVxuICAgIHNldE1vZGUobmV3TW9kZSk7XG4gIH07XG5cbiAgLy8gRWZmZWN0IHRvIGFkZCBhbmQgcmVtb3ZlIGtleWJvYXJkIGV2ZW50IGxpc3RlbmVyc1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIC8vIEFkZCBldmVudCBsaXN0ZW5lciB3aGVuIHRoZSBjb21wb25lbnQgbW91bnRzXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgIFxuICAgIC8vIFJlbW92ZSBldmVudCBsaXN0ZW5lciB3aGVuIHRoZSBjb21wb25lbnQgdW5tb3VudHNcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgIH07XG4gIH0sIFtzZWxlY3RlZEVsZW1lbnQsIGNhblVuZG8sIGNhblJlZG9dKTsgLy8gUmUtYWRkIGxpc3RlbmVyIHdoZW4gZGVwZW5kZW5jaWVzIGNoYW5nZVxuICBcbiAgLy8gRWZmZWN0IHRvIHNldCBpbml0aWFsIHN0YWdlIGRpbWVuc2lvbnMgYW5kIGhhbmRsZSB3aW5kb3cgcmVzaXplXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlRGltZW5zaW9ucyA9ICgpID0+IHtcbiAgICAgIGlmIChjb250YWluZXJSZWYuY3VycmVudCkge1xuICAgICAgICBjb25zdCB7IGNsaWVudFdpZHRoLCBjbGllbnRIZWlnaHQgfSA9IGNvbnRhaW5lclJlZi5jdXJyZW50O1xuICAgICAgICBzZXRTdGFnZURpbWVuc2lvbnMoe1xuICAgICAgICAgIHdpZHRoOiBjbGllbnRXaWR0aCxcbiAgICAgICAgICBoZWlnaHQ6IGNsaWVudEhlaWdodFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9O1xuICAgIFxuICAgIC8vIFNldCBpbml0aWFsIGRpbWVuc2lvbnNcbiAgICB1cGRhdGVEaW1lbnNpb25zKCk7XG4gICAgXG4gICAgLy8gQWRkIHJlc2l6ZSBsaXN0ZW5lclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB1cGRhdGVEaW1lbnNpb25zKTtcbiAgICBcbiAgICAvLyBDbGVhbiB1cFxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdXBkYXRlRGltZW5zaW9ucyk7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIC8vIEFkZCB0aGlzIGVmZmVjdCB0byBleHBvc2Ugc3RhdGUgZm9yIHRlc3RpbmdcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcgfHwgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICd0ZXN0Jykge1xuICAgICAgd2luZG93Ll9fUEVUUklfTkVUX1NUQVRFX18gPSBlbGVtZW50cztcbiAgICB9XG4gIH0sIFtlbGVtZW50c10pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGgtc2NyZWVuXCIgcmVmPXthcHBSZWZ9PlxuICAgICAgPFRvb2xiYXIgXG4gICAgICAgIG1vZGU9e21vZGV9IFxuICAgICAgICBzZXRNb2RlPXtoYW5kbGVNb2RlQ2hhbmdlfSBcbiAgICAgICAgZ3JpZFNuYXBwaW5nRW5hYmxlZD17Z3JpZFNuYXBwaW5nRW5hYmxlZH1cbiAgICAgICAgdG9nZ2xlR3JpZFNuYXBwaW5nPXt0b2dnbGVHcmlkU25hcHBpbmd9XG4gICAgICAgIGNhblVuZG89e2NhblVuZG99XG4gICAgICAgIGNhblJlZG89e2NhblJlZG99XG4gICAgICAgIG9uVW5kbz17aGFuZGxlVW5kb31cbiAgICAgICAgb25SZWRvPXtoYW5kbGVSZWRvfVxuICAgICAgLz5cbiAgICAgIFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3ctaGlkZGVuXCIgcmVmPXtjb250YWluZXJSZWZ9PlxuICAgICAgICAgIDxTdGFnZSBcbiAgICAgICAgICAgIHJlZj17c3RhZ2VSZWZ9XG4gICAgICAgICAgICBkYXRhLXRlc3RpZD1cImNhbnZhc1wiXG4gICAgICAgICAgICB3aWR0aD17c3RhZ2VEaW1lbnNpb25zLndpZHRofSBcbiAgICAgICAgICAgIGhlaWdodD17c3RhZ2VEaW1lbnNpb25zLmhlaWdodH0gXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdGFnZUNsaWNrfVxuICAgICAgICAgICAgb25Nb3VzZU1vdmU9e2hhbmRsZU1vdXNlTW92ZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhbnZhcy1jb250YWluZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxMYXllcj5cbiAgICAgICAgICAgICAgey8qIEJhY2tncm91bmQgZm9yIGRldGVjdGluZyBjbGlja3Mgb24gZW1wdHkgY2FudmFzICovfVxuICAgICAgICAgICAgICA8UmVjdFxuICAgICAgICAgICAgICAgIHg9ezB9XG4gICAgICAgICAgICAgICAgeT17MH1cbiAgICAgICAgICAgICAgICB3aWR0aD17c3RhZ2VEaW1lbnNpb25zLndpZHRofVxuICAgICAgICAgICAgICAgIGhlaWdodD17c3RhZ2VEaW1lbnNpb25zLmhlaWdodH1cbiAgICAgICAgICAgICAgICBmaWxsPVwidHJhbnNwYXJlbnRcIlxuICAgICAgICAgICAgICAgIG5hbWU9XCJiYWNrZ3JvdW5kXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBHcmlkIGxpbmVzICovfVxuICAgICAgICAgICAgICA8R3JpZCB3aWR0aD17c3RhZ2VEaW1lbnNpb25zLndpZHRofSBoZWlnaHQ9e3N0YWdlRGltZW5zaW9ucy5oZWlnaHR9IGdyaWRTaXplPXtncmlkU2l6ZX0gLz5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBQbGFjZXMgKi99XG4gICAgICAgICAgICAgIHtlbGVtZW50cy5wbGFjZXMubWFwKHBsYWNlID0+IChcbiAgICAgICAgICAgICAgICA8UGxhY2VcbiAgICAgICAgICAgICAgICAgIGtleT17cGxhY2UuaWR9XG4gICAgICAgICAgICAgICAgICBwbGFjZT17cGxhY2V9XG4gICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkPXtzZWxlY3RlZEVsZW1lbnQgJiYgc2VsZWN0ZWRFbGVtZW50LmlkID09PSBwbGFjZS5pZCB8fCBcbiAgICAgICAgICAgICAgICAgICAgKGFyY1N0YXJ0ICYmIGFyY1N0YXJ0LmVsZW1lbnQuaWQgPT09IHBsYWNlLmlkKX1cbiAgICAgICAgICAgICAgICAgIGlzRHJhZ2dpbmc9e2RyYWdnZWRFbGVtZW50ICYmIGRyYWdnZWRFbGVtZW50LmVsZW1lbnQuaWQgPT09IHBsYWNlLmlkfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRWxlbWVudENsaWNrKHBsYWNlLCAncGxhY2UnKX1cbiAgICAgICAgICAgICAgICAgIG9uRHJhZ1N0YXJ0PXsoKSA9PiBoYW5kbGVEcmFnU3RhcnQocGxhY2UsICdwbGFjZScpfVxuICAgICAgICAgICAgICAgICAgb25EcmFnTW92ZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gR2V0IGN1cnJlbnQgcG9zaXRpb25cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF3UG9zID0geyB4OiBlLnRhcmdldC54KCksIHk6IGUudGFyZ2V0LnkoKSB9O1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgLy8gQ2FsY3VsYXRlIHNuYXBwZWQgcG9zaXRpb25cbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc25hcHBlZFBvcyA9IHNuYXBUb0dyaWQocmF3UG9zLngsIHJhd1Bvcy55KTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgdmlzdWFsIHBvc2l0aW9uIG9mIHRoZSBlbGVtZW50IGJlaW5nIGRyYWdnZWRcbiAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQucG9zaXRpb24oe1xuICAgICAgICAgICAgICAgICAgICAgIHg6IHNuYXBwZWRQb3MueCxcbiAgICAgICAgICAgICAgICAgICAgICB5OiBzbmFwcGVkUG9zLnlcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgb25EcmFnRW5kPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdQb3MgPSB7IHg6IGUudGFyZ2V0LngoKSwgeTogZS50YXJnZXQueSgpIH07XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZURyYWdFbmQocGxhY2UsICdwbGFjZScsIG5ld1Bvcyk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgey8qIFRyYW5zaXRpb25zICovfVxuICAgICAgICAgICAgICB7ZWxlbWVudHMudHJhbnNpdGlvbnMubWFwKHRyYW5zaXRpb24gPT4gKFxuICAgICAgICAgICAgICAgIDxUcmFuc2l0aW9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3RyYW5zaXRpb24uaWR9XG4gICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt0cmFuc2l0aW9ufVxuICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZD17c2VsZWN0ZWRFbGVtZW50ICYmIHNlbGVjdGVkRWxlbWVudC5pZCA9PT0gdHJhbnNpdGlvbi5pZCB8fCBcbiAgICAgICAgICAgICAgICAgICAgKGFyY1N0YXJ0ICYmIGFyY1N0YXJ0LmVsZW1lbnQuaWQgPT09IHRyYW5zaXRpb24uaWQpfVxuICAgICAgICAgICAgICAgICAgaXNEcmFnZ2luZz17ZHJhZ2dlZEVsZW1lbnQgJiYgZHJhZ2dlZEVsZW1lbnQuZWxlbWVudC5pZCA9PT0gdHJhbnNpdGlvbi5pZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVsZW1lbnRDbGljayh0cmFuc2l0aW9uLCAndHJhbnNpdGlvbicpfVxuICAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9eygpID0+IGhhbmRsZURyYWdTdGFydCh0cmFuc2l0aW9uLCAndHJhbnNpdGlvbicpfVxuICAgICAgICAgICAgICAgICAgb25EcmFnTW92ZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gR2V0IGN1cnJlbnQgcG9zaXRpb25cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF3UG9zID0geyB4OiBlLnRhcmdldC54KCksIHk6IGUudGFyZ2V0LnkoKSB9O1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgLy8gQ2FsY3VsYXRlIHNuYXBwZWQgcG9zaXRpb25cbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc25hcHBlZFBvcyA9IHNuYXBUb0dyaWQocmF3UG9zLngsIHJhd1Bvcy55KTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgdmlzdWFsIHBvc2l0aW9uIG9mIHRoZSBlbGVtZW50IGJlaW5nIGRyYWdnZWRcbiAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQucG9zaXRpb24oe1xuICAgICAgICAgICAgICAgICAgICAgIHg6IHNuYXBwZWRQb3MueCxcbiAgICAgICAgICAgICAgICAgICAgICB5OiBzbmFwcGVkUG9zLnlcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgb25EcmFnRW5kPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdQb3MgPSB7IHg6IGUudGFyZ2V0LngoKSwgeTogZS50YXJnZXQueSgpIH07XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZURyYWdFbmQodHJhbnNpdGlvbiwgJ3RyYW5zaXRpb24nLCBuZXdQb3MpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBBcmNzICovfVxuICAgICAgICAgICAgICB7ZWxlbWVudHMuYXJjcy5tYXAoYXJjID0+IChcbiAgICAgICAgICAgICAgICA8QXJjXG4gICAgICAgICAgICAgICAgICBrZXk9e2FyYy5pZH1cbiAgICAgICAgICAgICAgICAgIGFyYz17YXJjfVxuICAgICAgICAgICAgICAgICAgcGxhY2VzPXtlbGVtZW50cy5wbGFjZXN9XG4gICAgICAgICAgICAgICAgICB0cmFuc2l0aW9ucz17ZWxlbWVudHMudHJhbnNpdGlvbnN9XG4gICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkPXtzZWxlY3RlZEVsZW1lbnQgJiYgc2VsZWN0ZWRFbGVtZW50LmlkID09PSBhcmMuaWR9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZEVsZW1lbnQoYXJjKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBUZW1wb3JhcnkgYXJjIGR1cmluZyBjcmVhdGlvbiAqL31cbiAgICAgICAgICAgICAge2FyY1N0YXJ0ICYmIHRlbXBBcmNFbmQgJiYgKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8TGluZVxuICAgICAgICAgICAgICAgICAgICBwb2ludHM9e1tcbiAgICAgICAgICAgICAgICAgICAgICB0ZW1wQXJjRW5kLnNvdXJjZVBvaW50LngsXG4gICAgICAgICAgICAgICAgICAgICAgdGVtcEFyY0VuZC5zb3VyY2VQb2ludC55LFxuICAgICAgICAgICAgICAgICAgICAgIHRlbXBBcmNFbmQueCxcbiAgICAgICAgICAgICAgICAgICAgICB0ZW1wQXJjRW5kLnlcbiAgICAgICAgICAgICAgICAgICAgXX1cbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiI0ZGOTgwMFwiIC8qIE9yYW5nZSBjb2xvciBmb3IgdHJhbnNpZW50IG5hdHVyZSAqL1xuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cbiAgICAgICAgICAgICAgICAgICAgZGFzaD17WzUsIDVdfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHsvKiBWaXN1YWwgY3VlIGZvciBzb3VyY2UgcG9pbnQgKi99XG4gICAgICAgICAgICAgICAgICA8Q2lyY2xlXG4gICAgICAgICAgICAgICAgICAgIHg9e3RlbXBBcmNFbmQuc291cmNlUG9pbnQueH1cbiAgICAgICAgICAgICAgICAgICAgeT17dGVtcEFyY0VuZC5zb3VyY2VQb2ludC55fVxuICAgICAgICAgICAgICAgICAgICByYWRpdXM9ezR9XG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjRkY5ODAwXCJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwid2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17MX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB7LyogVmlzdWFsIGN1ZSBmb3IgdGFyZ2V0IHBvaW50IGlmIGhvdmVyaW5nIG5lYXIgYSB2YWxpZCB0YXJnZXQgKi99XG4gICAgICAgICAgICAgICAgICB7dGVtcEFyY0VuZC5wb3RlbnRpYWxUYXJnZXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8Q2lyY2xlXG4gICAgICAgICAgICAgICAgICAgICAgeD17dGVtcEFyY0VuZC5wb3RlbnRpYWxUYXJnZXQucG9pbnQucG9pbnQueH1cbiAgICAgICAgICAgICAgICAgICAgICB5PXt0ZW1wQXJjRW5kLnBvdGVudGlhbFRhcmdldC5wb2ludC5wb2ludC55fVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmFkaXVzPXs0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNGRjk4MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwid2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezF9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvTGF5ZXI+XHJcbiAgICAgICAgICA8L1N0YWdlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxQcm9wZXJ0aWVzUGFuZWwgXHJcbiAgICAgICAgICBzZWxlY3RlZEVsZW1lbnQ9e3NlbGVjdGVkRWxlbWVudH0gXHJcbiAgICAgICAgICBzZXRFbGVtZW50cz17c2V0RWxlbWVudHN9IFxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICAgPEV4ZWN1dGlvblBhbmVsIGVsZW1lbnRzPXtlbGVtZW50c30gLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9MZXZpL0Nhc2NhZGVQcm9qZWN0cy9wZXRyaS1uZXQtZWRpdG9yL3BldHJpLW5ldC1hcHAvc3JjL0FwcC5qc3gifQ==