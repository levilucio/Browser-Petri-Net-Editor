import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Transition.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Rect, Text, Group, Line } from "/node_modules/.vite/deps/react-konva.js?v=4e926b2f";
const Transition = ({ transition, isSelected, isDragging, onClick, onDragStart, onDragMove, onDragEnd }) => {
  const width = 30;
  const height = 40;
  const renderSnapIndicators = () => {
    if (!isDragging)
      return null;
    const indicatorLength = 10;
    const indicatorColor = "rgba(0, 150, 255, 0.7)";
    const indicatorWidth = 1;
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          points: [-width / 2 - indicatorLength, 0, width / 2 + indicatorLength, 0],
          stroke: indicatorColor,
          strokeWidth: indicatorWidth,
          dash: [4, 2]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx",
          lineNumber: 38,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          points: [0, -height / 2 - indicatorLength, 0, height / 2 + indicatorLength],
          stroke: indicatorColor,
          strokeWidth: indicatorWidth,
          dash: [4, 2]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx",
          lineNumber: 45,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(
    Group,
    {
      x: transition.x,
      y: transition.y,
      onClick,
      draggable: true,
      onDragStart,
      onDragMove,
      onDragEnd,
      children: [
        renderSnapIndicators(),
        /* @__PURE__ */ jsxDEV(
          Rect,
          {
            x: -width / 2,
            y: -height / 2,
            width,
            height,
            fill: "gray",
            stroke: isSelected ? "blue" : isDragging ? "rgba(0, 150, 255, 0.7)" : "black",
            strokeWidth: isSelected || isDragging ? 2 : 1
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx",
            lineNumber: 69,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Text,
          {
            text: transition.name,
            fontSize: 12,
            fill: "black",
            x: -width / 2,
            y: height / 2 + 5,
            width,
            align: "center"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx",
            lineNumber: 80,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx",
      lineNumber: 56,
      columnNumber: 5
    },
    this
  );
};
_c = Transition;
export default Transition;
var _c;
$RefreshReg$(_c, "Transition");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Transition.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNLG1CQUVFLGNBRkY7Ozs7Ozs7Ozs7Ozs7Ozs7QUFoQk4sT0FBT0EsV0FBVztBQUNsQixTQUFTQyxNQUFNQyxNQUFNQyxPQUFPQyxZQUFZO0FBRXhDLE1BQU1DLGFBQWFBLENBQUMsRUFBRUMsWUFBWUMsWUFBWUMsWUFBWUMsU0FBU0MsYUFBYUMsWUFBWUMsVUFBVSxNQUFNO0FBQzFHLFFBQU1DLFFBQVE7QUFDZCxRQUFNQyxTQUFTO0FBR2YsUUFBTUMsdUJBQXVCQSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ1A7QUFBWSxhQUFPO0FBRXhCLFVBQU1RLGtCQUFrQjtBQUN4QixVQUFNQyxpQkFBaUI7QUFDdkIsVUFBTUMsaUJBQWlCO0FBRXZCLFdBQ0UsbUNBRUU7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsUUFBUSxDQUFDLENBQUNMLFFBQU0sSUFBSUcsaUJBQWlCLEdBQUdILFFBQU0sSUFBSUcsaUJBQWlCLENBQUM7QUFBQSxVQUNwRSxRQUFRQztBQUFBQSxVQUNSLGFBQWFDO0FBQUFBLFVBQ2IsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUFBO0FBQUEsUUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJZTtBQUFBLE1BR2Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFFBQVEsQ0FBQyxHQUFHLENBQUNKLFNBQU8sSUFBSUUsaUJBQWlCLEdBQUdGLFNBQU8sSUFBSUUsZUFBZTtBQUFBLFVBQ3RFLFFBQVFDO0FBQUFBLFVBQ1IsYUFBYUM7QUFBQUEsVUFDYixNQUFNLENBQUMsR0FBRyxDQUFDO0FBQUE7QUFBQSxRQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUllO0FBQUEsU0FiakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsRUFFSjtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEdBQUdaLFdBQVdhO0FBQUFBLE1BQ2QsR0FBR2IsV0FBV2M7QUFBQUEsTUFDZDtBQUFBLE1BQ0EsV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BR0NMO0FBQUFBLDZCQUFxQjtBQUFBLFFBR3RCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFHLENBQUNGLFFBQVE7QUFBQSxZQUNaLEdBQUcsQ0FBQ0MsU0FBUztBQUFBLFlBQ2I7QUFBQSxZQUNBO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxRQUFRUCxhQUFhLFNBQVVDLGFBQWEsMkJBQTJCO0FBQUEsWUFDdkUsYUFBYUQsY0FBY0MsYUFBYSxJQUFJO0FBQUE7QUFBQSxVQVA5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPZ0Q7QUFBQSxRQUloRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTUYsV0FBV2U7QUFBQUEsWUFDakIsVUFBVTtBQUFBLFlBQ1YsTUFBSztBQUFBLFlBQ0wsR0FBRyxDQUFDUixRQUFRO0FBQUEsWUFDWixHQUFHQyxTQUFTLElBQUk7QUFBQSxZQUNoQjtBQUFBLFlBQ0EsT0FBTTtBQUFBO0FBQUEsVUFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPZ0I7QUFBQTtBQUFBO0FBQUEsSUEvQmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlDQTtBQUVKO0FBQUVRLEtBcEVJakI7QUFzRU4sZUFBZUE7QUFBVyxJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiUmVjdCIsIlRleHQiLCJHcm91cCIsIkxpbmUiLCJUcmFuc2l0aW9uIiwidHJhbnNpdGlvbiIsImlzU2VsZWN0ZWQiLCJpc0RyYWdnaW5nIiwib25DbGljayIsIm9uRHJhZ1N0YXJ0Iiwib25EcmFnTW92ZSIsIm9uRHJhZ0VuZCIsIndpZHRoIiwiaGVpZ2h0IiwicmVuZGVyU25hcEluZGljYXRvcnMiLCJpbmRpY2F0b3JMZW5ndGgiLCJpbmRpY2F0b3JDb2xvciIsImluZGljYXRvcldpZHRoIiwieCIsInkiLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUcmFuc2l0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBSZWN0LCBUZXh0LCBHcm91cCwgTGluZSB9IGZyb20gJ3JlYWN0LWtvbnZhJztcclxuXHJcbmNvbnN0IFRyYW5zaXRpb24gPSAoeyB0cmFuc2l0aW9uLCBpc1NlbGVjdGVkLCBpc0RyYWdnaW5nLCBvbkNsaWNrLCBvbkRyYWdTdGFydCwgb25EcmFnTW92ZSwgb25EcmFnRW5kIH0pID0+IHtcclxuICBjb25zdCB3aWR0aCA9IDMwO1xyXG4gIGNvbnN0IGhlaWdodCA9IDQwO1xyXG4gIFxyXG4gIC8vIFZpc3VhbCBpbmRpY2F0b3JzIGZvciBncmlkIHNuYXBwaW5nXHJcbiAgY29uc3QgcmVuZGVyU25hcEluZGljYXRvcnMgPSAoKSA9PiB7XHJcbiAgICBpZiAoIWlzRHJhZ2dpbmcpIHJldHVybiBudWxsO1xyXG4gICAgXHJcbiAgICBjb25zdCBpbmRpY2F0b3JMZW5ndGggPSAxMDtcclxuICAgIGNvbnN0IGluZGljYXRvckNvbG9yID0gJ3JnYmEoMCwgMTUwLCAyNTUsIDAuNyknO1xyXG4gICAgY29uc3QgaW5kaWNhdG9yV2lkdGggPSAxO1xyXG4gICAgXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8PlxyXG4gICAgICAgIHsvKiBIb3Jpem9udGFsIGluZGljYXRvciAqL31cclxuICAgICAgICA8TGluZVxyXG4gICAgICAgICAgcG9pbnRzPXtbLXdpZHRoLzIgLSBpbmRpY2F0b3JMZW5ndGgsIDAsIHdpZHRoLzIgKyBpbmRpY2F0b3JMZW5ndGgsIDBdfVxyXG4gICAgICAgICAgc3Ryb2tlPXtpbmRpY2F0b3JDb2xvcn1cclxuICAgICAgICAgIHN0cm9rZVdpZHRoPXtpbmRpY2F0b3JXaWR0aH1cclxuICAgICAgICAgIGRhc2g9e1s0LCAyXX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIHsvKiBWZXJ0aWNhbCBpbmRpY2F0b3IgKi99XHJcbiAgICAgICAgPExpbmVcclxuICAgICAgICAgIHBvaW50cz17WzAsIC1oZWlnaHQvMiAtIGluZGljYXRvckxlbmd0aCwgMCwgaGVpZ2h0LzIgKyBpbmRpY2F0b3JMZW5ndGhdfVxyXG4gICAgICAgICAgc3Ryb2tlPXtpbmRpY2F0b3JDb2xvcn1cclxuICAgICAgICAgIHN0cm9rZVdpZHRoPXtpbmRpY2F0b3JXaWR0aH1cclxuICAgICAgICAgIGRhc2g9e1s0LCAyXX1cclxuICAgICAgICAvPlxyXG4gICAgICA8Lz5cclxuICAgICk7XHJcbiAgfTtcclxuICBcclxuICByZXR1cm4gKFxyXG4gICAgPEdyb3VwXHJcbiAgICAgIHg9e3RyYW5zaXRpb24ueH1cclxuICAgICAgeT17dHJhbnNpdGlvbi55fVxyXG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxyXG4gICAgICBkcmFnZ2FibGU9e3RydWV9XHJcbiAgICAgIG9uRHJhZ1N0YXJ0PXtvbkRyYWdTdGFydH1cclxuICAgICAgb25EcmFnTW92ZT17b25EcmFnTW92ZX1cclxuICAgICAgb25EcmFnRW5kPXtvbkRyYWdFbmR9XHJcbiAgICA+XHJcbiAgICAgIHsvKiBHcmlkIHNuYXAgaW5kaWNhdG9ycyAqL31cclxuICAgICAge3JlbmRlclNuYXBJbmRpY2F0b3JzKCl9XHJcbiAgICAgIFxyXG4gICAgICB7LyogVHJhbnNpdGlvbiByZWN0YW5nbGUgKi99XHJcbiAgICAgIDxSZWN0XHJcbiAgICAgICAgeD17LXdpZHRoIC8gMn1cclxuICAgICAgICB5PXstaGVpZ2h0IC8gMn1cclxuICAgICAgICB3aWR0aD17d2lkdGh9XHJcbiAgICAgICAgaGVpZ2h0PXtoZWlnaHR9XHJcbiAgICAgICAgZmlsbD1cImdyYXlcIlxyXG4gICAgICAgIHN0cm9rZT17aXNTZWxlY3RlZCA/ICdibHVlJyA6IChpc0RyYWdnaW5nID8gJ3JnYmEoMCwgMTUwLCAyNTUsIDAuNyknIDogJ2JsYWNrJyl9XHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9e2lzU2VsZWN0ZWQgfHwgaXNEcmFnZ2luZyA/IDIgOiAxfVxyXG4gICAgICAvPlxyXG4gICAgICBcclxuICAgICAgey8qIFRyYW5zaXRpb24gbmFtZSAqL31cclxuICAgICAgPFRleHRcclxuICAgICAgICB0ZXh0PXt0cmFuc2l0aW9uLm5hbWV9XHJcbiAgICAgICAgZm9udFNpemU9ezEyfVxyXG4gICAgICAgIGZpbGw9XCJibGFja1wiXHJcbiAgICAgICAgeD17LXdpZHRoIC8gMn1cclxuICAgICAgICB5PXtoZWlnaHQgLyAyICsgNX1cclxuICAgICAgICB3aWR0aD17d2lkdGh9XHJcbiAgICAgICAgYWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAvPlxyXG4gICAgPC9Hcm91cD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNpdGlvbjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9MZXZpL0Nhc2NhZGVQcm9qZWN0cy9wZXRyaS1uZXQtZWRpdG9yL3BldHJpLW5ldC1hcHAvc3JjL2NvbXBvbmVudHMvVHJhbnNpdGlvbi5qc3gifQ==