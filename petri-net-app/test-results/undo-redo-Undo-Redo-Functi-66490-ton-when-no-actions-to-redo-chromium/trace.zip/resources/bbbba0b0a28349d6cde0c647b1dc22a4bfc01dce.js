import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Arc.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Line, Text, Group } from "/node_modules/.vite/deps/react-konva.js?v=4e926b2f";
const Arc = ({ arc, places, transitions, isSelected, onClick }) => {
  const source = arc.sourceType === "place" ? places.find((p) => p.id === arc.sourceId) : transitions.find((t) => t.id === arc.sourceId);
  const target = arc.targetType === "place" ? places.find((p) => p.id === arc.targetId) : transitions.find((t) => t.id === arc.targetId);
  if (!source || !target)
    return null;
  const startX = source.x;
  const startY = source.y;
  const endX = target.x;
  const endY = target.y;
  const dx = endX - startX;
  const dy = endY - startY;
  const angle = Math.atan2(dy, dx);
  let adjustedStartX, adjustedStartY, adjustedEndX, adjustedEndY;
  if (arc.sourceType === "place") {
    const radius = 20;
    adjustedStartX = startX + Math.cos(angle) * radius;
    adjustedStartY = startY + Math.sin(angle) * radius;
  } else {
    const width = 30;
    const height = 40;
    if (Math.abs(Math.cos(angle)) > Math.abs(Math.sin(angle))) {
      const sign = Math.cos(angle) > 0 ? 1 : -1;
      adjustedStartX = startX + sign * width / 2;
      adjustedStartY = startY + Math.sin(angle) / Math.cos(angle) * sign * width / 2;
    } else {
      const sign = Math.sin(angle) > 0 ? 1 : -1;
      adjustedStartX = startX + Math.cos(angle) / Math.sin(angle) * sign * height / 2;
      adjustedStartY = startY + sign * height / 2;
    }
  }
  if (arc.targetType === "place") {
    const radius = 20;
    adjustedEndX = endX - Math.cos(angle) * radius;
    adjustedEndY = endY - Math.sin(angle) * radius;
  } else {
    const width = 30;
    const height = 40;
    if (Math.abs(Math.cos(angle)) > Math.abs(Math.sin(angle))) {
      const sign = Math.cos(angle) > 0 ? -1 : 1;
      adjustedEndX = endX + sign * width / 2;
      adjustedEndY = endY + Math.sin(angle) / Math.cos(angle) * sign * width / 2;
    } else {
      const sign = Math.sin(angle) > 0 ? -1 : 1;
      adjustedEndX = endX + Math.cos(angle) / Math.sin(angle) * sign * height / 2;
      adjustedEndY = endY + sign * height / 2;
    }
  }
  const arrowHeadSize = 10;
  const arrowAngle1 = angle - Math.PI / 6;
  const arrowAngle2 = angle + Math.PI / 6;
  const arrowPoint1X = adjustedEndX - arrowHeadSize * Math.cos(arrowAngle1);
  const arrowPoint1Y = adjustedEndY - arrowHeadSize * Math.sin(arrowAngle1);
  const arrowPoint2X = adjustedEndX - arrowHeadSize * Math.cos(arrowAngle2);
  const arrowPoint2Y = adjustedEndY - arrowHeadSize * Math.sin(arrowAngle2);
  const midX = (adjustedStartX + adjustedEndX) / 2;
  const midY = (adjustedStartY + adjustedEndY) / 2;
  const labelOffsetX = -10 * Math.sin(angle);
  const labelOffsetY = 10 * Math.cos(angle);
  return /* @__PURE__ */ jsxDEV(Group, { onClick, children: [
    /* @__PURE__ */ jsxDEV(
      Line,
      {
        points: [adjustedStartX, adjustedStartY, adjustedEndX, adjustedEndY],
        stroke: "transparent",
        strokeWidth: 15,
        hitStrokeWidth: 20
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx",
        lineNumber: 118,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Line,
      {
        points: [adjustedStartX, adjustedStartY, adjustedEndX, adjustedEndY],
        stroke: isSelected ? "blue" : "black",
        strokeWidth: isSelected ? 2 : 1
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx",
        lineNumber: 126,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Line,
      {
        points: [
          adjustedEndX,
          adjustedEndY,
          arrowPoint1X,
          arrowPoint1Y,
          arrowPoint2X,
          arrowPoint2Y,
          adjustedEndX,
          adjustedEndY
        ],
        closed: true,
        fill: "black",
        stroke: "black"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx",
        lineNumber: 133,
        columnNumber: 7
      },
      this
    ),
    arc.weight && arc.weight > 1 && /* @__PURE__ */ jsxDEV(
      Text,
      {
        text: arc.weight.toString(),
        fontSize: 12,
        fill: "black",
        x: midX + labelOffsetX - 5,
        y: midY + labelOffsetY - 5,
        width: 10,
        align: "center"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx",
        lineNumber: 147,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx",
    lineNumber: 116,
    columnNumber: 5
  }, this);
};
_c = Arc;
export default Arc;
var _c;
$RefreshReg$(_c, "Arc");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Arc.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0dNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEdOLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsTUFBTUMsTUFBTUMsYUFBYTtBQUVsQyxNQUFNQyxNQUFNQSxDQUFDLEVBQUVDLEtBQUtDLFFBQVFDLGFBQWFDLFlBQVlDLFFBQVEsTUFBTTtBQUVqRSxRQUFNQyxTQUFTTCxJQUFJTSxlQUFlLFVBQzlCTCxPQUFPTSxLQUFLLENBQUFDLE1BQUtBLEVBQUVDLE9BQU9ULElBQUlVLFFBQVEsSUFDdENSLFlBQVlLLEtBQUssQ0FBQUksTUFBS0EsRUFBRUYsT0FBT1QsSUFBSVUsUUFBUTtBQUUvQyxRQUFNRSxTQUFTWixJQUFJYSxlQUFlLFVBQzlCWixPQUFPTSxLQUFLLENBQUFDLE1BQUtBLEVBQUVDLE9BQU9ULElBQUljLFFBQVEsSUFDdENaLFlBQVlLLEtBQUssQ0FBQUksTUFBS0EsRUFBRUYsT0FBT1QsSUFBSWMsUUFBUTtBQUUvQyxNQUFJLENBQUNULFVBQVUsQ0FBQ087QUFBUSxXQUFPO0FBRy9CLFFBQU1HLFNBQVNWLE9BQU9XO0FBQ3RCLFFBQU1DLFNBQVNaLE9BQU9hO0FBQ3RCLFFBQU1DLE9BQU9QLE9BQU9JO0FBQ3BCLFFBQU1JLE9BQU9SLE9BQU9NO0FBR3BCLFFBQU1HLEtBQUtGLE9BQU9KO0FBQ2xCLFFBQU1PLEtBQUtGLE9BQU9IO0FBQ2xCLFFBQU1NLFFBQVFDLEtBQUtDLE1BQU1ILElBQUlELEVBQUU7QUFHL0IsTUFBSUssZ0JBQWdCQyxnQkFBZ0JDLGNBQWNDO0FBRWxELE1BQUk3QixJQUFJTSxlQUFlLFNBQVM7QUFFOUIsVUFBTXdCLFNBQVM7QUFDZkoscUJBQWlCWCxTQUFTUyxLQUFLTyxJQUFJUixLQUFLLElBQUlPO0FBQzVDSCxxQkFBaUJWLFNBQVNPLEtBQUtRLElBQUlULEtBQUssSUFBSU87QUFBQUEsRUFDOUMsT0FBTztBQUVMLFVBQU1HLFFBQVE7QUFDZCxVQUFNQyxTQUFTO0FBR2YsUUFBSVYsS0FBS1csSUFBSVgsS0FBS08sSUFBSVIsS0FBSyxDQUFDLElBQUlDLEtBQUtXLElBQUlYLEtBQUtRLElBQUlULEtBQUssQ0FBQyxHQUFHO0FBRXpELFlBQU1hLE9BQU9aLEtBQUtPLElBQUlSLEtBQUssSUFBSSxJQUFJLElBQUk7QUFDdkNHLHVCQUFpQlgsU0FBU3FCLE9BQU9ILFFBQVE7QUFDekNOLHVCQUFpQlYsU0FBU08sS0FBS1EsSUFBSVQsS0FBSyxJQUFJQyxLQUFLTyxJQUFJUixLQUFLLElBQUlhLE9BQU9ILFFBQVE7QUFBQSxJQUMvRSxPQUFPO0FBRUwsWUFBTUcsT0FBT1osS0FBS1EsSUFBSVQsS0FBSyxJQUFJLElBQUksSUFBSTtBQUN2Q0csdUJBQWlCWCxTQUFTUyxLQUFLTyxJQUFJUixLQUFLLElBQUlDLEtBQUtRLElBQUlULEtBQUssSUFBSWEsT0FBT0YsU0FBUztBQUM5RVAsdUJBQWlCVixTQUFTbUIsT0FBT0YsU0FBUztBQUFBLElBQzVDO0FBQUEsRUFDRjtBQUVBLE1BQUlsQyxJQUFJYSxlQUFlLFNBQVM7QUFFOUIsVUFBTWlCLFNBQVM7QUFDZkYsbUJBQWVULE9BQU9LLEtBQUtPLElBQUlSLEtBQUssSUFBSU87QUFDeENELG1CQUFlVCxPQUFPSSxLQUFLUSxJQUFJVCxLQUFLLElBQUlPO0FBQUFBLEVBQzFDLE9BQU87QUFFTCxVQUFNRyxRQUFRO0FBQ2QsVUFBTUMsU0FBUztBQUdmLFFBQUlWLEtBQUtXLElBQUlYLEtBQUtPLElBQUlSLEtBQUssQ0FBQyxJQUFJQyxLQUFLVyxJQUFJWCxLQUFLUSxJQUFJVCxLQUFLLENBQUMsR0FBRztBQUV6RCxZQUFNYSxPQUFPWixLQUFLTyxJQUFJUixLQUFLLElBQUksSUFBSSxLQUFLO0FBQ3hDSyxxQkFBZVQsT0FBT2lCLE9BQU9ILFFBQVE7QUFDckNKLHFCQUFlVCxPQUFPSSxLQUFLUSxJQUFJVCxLQUFLLElBQUlDLEtBQUtPLElBQUlSLEtBQUssSUFBSWEsT0FBT0gsUUFBUTtBQUFBLElBQzNFLE9BQU87QUFFTCxZQUFNRyxPQUFPWixLQUFLUSxJQUFJVCxLQUFLLElBQUksSUFBSSxLQUFLO0FBQ3hDSyxxQkFBZVQsT0FBT0ssS0FBS08sSUFBSVIsS0FBSyxJQUFJQyxLQUFLUSxJQUFJVCxLQUFLLElBQUlhLE9BQU9GLFNBQVM7QUFDMUVMLHFCQUFlVCxPQUFPZ0IsT0FBT0YsU0FBUztBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUdBLFFBQU1HLGdCQUFnQjtBQUN0QixRQUFNQyxjQUFjZixRQUFRQyxLQUFLZSxLQUFLO0FBQ3RDLFFBQU1DLGNBQWNqQixRQUFRQyxLQUFLZSxLQUFLO0FBRXRDLFFBQU1FLGVBQWViLGVBQWVTLGdCQUFnQmIsS0FBS08sSUFBSU8sV0FBVztBQUN4RSxRQUFNSSxlQUFlYixlQUFlUSxnQkFBZ0JiLEtBQUtRLElBQUlNLFdBQVc7QUFDeEUsUUFBTUssZUFBZWYsZUFBZVMsZ0JBQWdCYixLQUFLTyxJQUFJUyxXQUFXO0FBQ3hFLFFBQU1JLGVBQWVmLGVBQWVRLGdCQUFnQmIsS0FBS1EsSUFBSVEsV0FBVztBQUd4RSxRQUFNSyxRQUFRbkIsaUJBQWlCRSxnQkFBZ0I7QUFDL0MsUUFBTWtCLFFBQVFuQixpQkFBaUJFLGdCQUFnQjtBQUcvQyxRQUFNa0IsZUFBZSxNQUFNdkIsS0FBS1EsSUFBSVQsS0FBSztBQUN6QyxRQUFNeUIsZUFBZSxLQUFLeEIsS0FBS08sSUFBSVIsS0FBSztBQUV4QyxTQUNFLHVCQUFDLFNBQU0sU0FFTDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxRQUFRLENBQUNHLGdCQUFnQkMsZ0JBQWdCQyxjQUFjQyxZQUFZO0FBQUEsUUFDbkUsUUFBTztBQUFBLFFBQ1AsYUFBYTtBQUFBLFFBQ2IsZ0JBQWdCO0FBQUE7QUFBQSxNQUpsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJcUI7QUFBQSxJQUlyQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsUUFBUSxDQUFDSCxnQkFBZ0JDLGdCQUFnQkMsY0FBY0MsWUFBWTtBQUFBLFFBQ25FLFFBQVExQixhQUFhLFNBQVM7QUFBQSxRQUM5QixhQUFhQSxhQUFhLElBQUk7QUFBQTtBQUFBLE1BSGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdrQztBQUFBLElBSWxDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxRQUFRO0FBQUEsVUFDTnlCO0FBQUFBLFVBQWNDO0FBQUFBLFVBQ2RZO0FBQUFBLFVBQWNDO0FBQUFBLFVBQ2RDO0FBQUFBLFVBQWNDO0FBQUFBLFVBQ2RoQjtBQUFBQSxVQUFjQztBQUFBQSxRQUFZO0FBQUEsUUFFNUIsUUFBUTtBQUFBLFFBQ1IsTUFBSztBQUFBLFFBQ0wsUUFBTztBQUFBO0FBQUEsTUFUVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTZ0I7QUFBQSxJQUlmN0IsSUFBSWlELFVBQVVqRCxJQUFJaUQsU0FBUyxLQUMxQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTWpELElBQUlpRCxPQUFPQyxTQUFTO0FBQUEsUUFDMUIsVUFBVTtBQUFBLFFBQ1YsTUFBSztBQUFBLFFBQ0wsR0FBR0wsT0FBT0UsZUFBZTtBQUFBLFFBQ3pCLEdBQUdELE9BQU9FLGVBQWU7QUFBQSxRQUN6QixPQUFPO0FBQUEsUUFDUCxPQUFNO0FBQUE7QUFBQSxNQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9nQjtBQUFBLE9BdENwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUNBO0FBRUo7QUFBRUcsS0F4SUlwRDtBQTBJTixlQUFlQTtBQUFJLElBQUFvRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJMaW5lIiwiVGV4dCIsIkdyb3VwIiwiQXJjIiwiYXJjIiwicGxhY2VzIiwidHJhbnNpdGlvbnMiLCJpc1NlbGVjdGVkIiwib25DbGljayIsInNvdXJjZSIsInNvdXJjZVR5cGUiLCJmaW5kIiwicCIsImlkIiwic291cmNlSWQiLCJ0IiwidGFyZ2V0IiwidGFyZ2V0VHlwZSIsInRhcmdldElkIiwic3RhcnRYIiwieCIsInN0YXJ0WSIsInkiLCJlbmRYIiwiZW5kWSIsImR4IiwiZHkiLCJhbmdsZSIsIk1hdGgiLCJhdGFuMiIsImFkanVzdGVkU3RhcnRYIiwiYWRqdXN0ZWRTdGFydFkiLCJhZGp1c3RlZEVuZFgiLCJhZGp1c3RlZEVuZFkiLCJyYWRpdXMiLCJjb3MiLCJzaW4iLCJ3aWR0aCIsImhlaWdodCIsImFicyIsInNpZ24iLCJhcnJvd0hlYWRTaXplIiwiYXJyb3dBbmdsZTEiLCJQSSIsImFycm93QW5nbGUyIiwiYXJyb3dQb2ludDFYIiwiYXJyb3dQb2ludDFZIiwiYXJyb3dQb2ludDJYIiwiYXJyb3dQb2ludDJZIiwibWlkWCIsIm1pZFkiLCJsYWJlbE9mZnNldFgiLCJsYWJlbE9mZnNldFkiLCJ3ZWlnaHQiLCJ0b1N0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXJjLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5lLCBUZXh0LCBHcm91cCB9IGZyb20gJ3JlYWN0LWtvbnZhJztcclxuXHJcbmNvbnN0IEFyYyA9ICh7IGFyYywgcGxhY2VzLCB0cmFuc2l0aW9ucywgaXNTZWxlY3RlZCwgb25DbGljayB9KSA9PiB7XHJcbiAgLy8gRmluZCBzb3VyY2UgYW5kIHRhcmdldCBlbGVtZW50c1xyXG4gIGNvbnN0IHNvdXJjZSA9IGFyYy5zb3VyY2VUeXBlID09PSAncGxhY2UnIFxyXG4gICAgPyBwbGFjZXMuZmluZChwID0+IHAuaWQgPT09IGFyYy5zb3VyY2VJZClcclxuICAgIDogdHJhbnNpdGlvbnMuZmluZCh0ID0+IHQuaWQgPT09IGFyYy5zb3VyY2VJZCk7XHJcbiAgXHJcbiAgY29uc3QgdGFyZ2V0ID0gYXJjLnRhcmdldFR5cGUgPT09ICdwbGFjZScgXHJcbiAgICA/IHBsYWNlcy5maW5kKHAgPT4gcC5pZCA9PT0gYXJjLnRhcmdldElkKVxyXG4gICAgOiB0cmFuc2l0aW9ucy5maW5kKHQgPT4gdC5pZCA9PT0gYXJjLnRhcmdldElkKTtcclxuXHJcbiAgaWYgKCFzb3VyY2UgfHwgIXRhcmdldCkgcmV0dXJuIG51bGw7XHJcblxyXG4gIC8vIENhbGN1bGF0ZSBzdGFydCBhbmQgZW5kIHBvaW50c1xyXG4gIGNvbnN0IHN0YXJ0WCA9IHNvdXJjZS54O1xyXG4gIGNvbnN0IHN0YXJ0WSA9IHNvdXJjZS55O1xyXG4gIGNvbnN0IGVuZFggPSB0YXJnZXQueDtcclxuICBjb25zdCBlbmRZID0gdGFyZ2V0Lnk7XHJcblxyXG4gIC8vIENhbGN1bGF0ZSBkaXN0YW5jZSBhbmQgYW5nbGUgZm9yIGFycm93IGhlYWRcclxuICBjb25zdCBkeCA9IGVuZFggLSBzdGFydFg7XHJcbiAgY29uc3QgZHkgPSBlbmRZIC0gc3RhcnRZO1xyXG4gIGNvbnN0IGFuZ2xlID0gTWF0aC5hdGFuMihkeSwgZHgpO1xyXG4gIFxyXG4gIC8vIEFkanVzdCBzdGFydCBhbmQgZW5kIHBvaW50cyBiYXNlZCBvbiBzb3VyY2UgYW5kIHRhcmdldCBzaGFwZXNcclxuICBsZXQgYWRqdXN0ZWRTdGFydFgsIGFkanVzdGVkU3RhcnRZLCBhZGp1c3RlZEVuZFgsIGFkanVzdGVkRW5kWTtcclxuICBcclxuICBpZiAoYXJjLnNvdXJjZVR5cGUgPT09ICdwbGFjZScpIHtcclxuICAgIC8vIEFkanVzdCBmb3IgY2lyY2xlIChwbGFjZSlcclxuICAgIGNvbnN0IHJhZGl1cyA9IDIwO1xyXG4gICAgYWRqdXN0ZWRTdGFydFggPSBzdGFydFggKyBNYXRoLmNvcyhhbmdsZSkgKiByYWRpdXM7XHJcbiAgICBhZGp1c3RlZFN0YXJ0WSA9IHN0YXJ0WSArIE1hdGguc2luKGFuZ2xlKSAqIHJhZGl1cztcclxuICB9IGVsc2Uge1xyXG4gICAgLy8gQWRqdXN0IGZvciByZWN0YW5nbGUgKHRyYW5zaXRpb24pXHJcbiAgICBjb25zdCB3aWR0aCA9IDMwO1xyXG4gICAgY29uc3QgaGVpZ2h0ID0gNDA7XHJcbiAgICBcclxuICAgIC8vIERldGVybWluZSB3aGljaCBzaWRlIG9mIHRoZSByZWN0YW5nbGUgdG8gc3RhcnQgZnJvbVxyXG4gICAgaWYgKE1hdGguYWJzKE1hdGguY29zKGFuZ2xlKSkgPiBNYXRoLmFicyhNYXRoLnNpbihhbmdsZSkpKSB7XHJcbiAgICAgIC8vIEhvcml6b250YWwgc2lkZVxyXG4gICAgICBjb25zdCBzaWduID0gTWF0aC5jb3MoYW5nbGUpID4gMCA/IDEgOiAtMTtcclxuICAgICAgYWRqdXN0ZWRTdGFydFggPSBzdGFydFggKyBzaWduICogd2lkdGggLyAyO1xyXG4gICAgICBhZGp1c3RlZFN0YXJ0WSA9IHN0YXJ0WSArIE1hdGguc2luKGFuZ2xlKSAvIE1hdGguY29zKGFuZ2xlKSAqIHNpZ24gKiB3aWR0aCAvIDI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBWZXJ0aWNhbCBzaWRlXHJcbiAgICAgIGNvbnN0IHNpZ24gPSBNYXRoLnNpbihhbmdsZSkgPiAwID8gMSA6IC0xO1xyXG4gICAgICBhZGp1c3RlZFN0YXJ0WCA9IHN0YXJ0WCArIE1hdGguY29zKGFuZ2xlKSAvIE1hdGguc2luKGFuZ2xlKSAqIHNpZ24gKiBoZWlnaHQgLyAyO1xyXG4gICAgICBhZGp1c3RlZFN0YXJ0WSA9IHN0YXJ0WSArIHNpZ24gKiBoZWlnaHQgLyAyO1xyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICBpZiAoYXJjLnRhcmdldFR5cGUgPT09ICdwbGFjZScpIHtcclxuICAgIC8vIEFkanVzdCBmb3IgY2lyY2xlIChwbGFjZSlcclxuICAgIGNvbnN0IHJhZGl1cyA9IDIwO1xyXG4gICAgYWRqdXN0ZWRFbmRYID0gZW5kWCAtIE1hdGguY29zKGFuZ2xlKSAqIHJhZGl1cztcclxuICAgIGFkanVzdGVkRW5kWSA9IGVuZFkgLSBNYXRoLnNpbihhbmdsZSkgKiByYWRpdXM7XHJcbiAgfSBlbHNlIHtcclxuICAgIC8vIEFkanVzdCBmb3IgcmVjdGFuZ2xlICh0cmFuc2l0aW9uKVxyXG4gICAgY29uc3Qgd2lkdGggPSAzMDtcclxuICAgIGNvbnN0IGhlaWdodCA9IDQwO1xyXG4gICAgXHJcbiAgICAvLyBEZXRlcm1pbmUgd2hpY2ggc2lkZSBvZiB0aGUgcmVjdGFuZ2xlIHRvIGVuZCBhdFxyXG4gICAgaWYgKE1hdGguYWJzKE1hdGguY29zKGFuZ2xlKSkgPiBNYXRoLmFicyhNYXRoLnNpbihhbmdsZSkpKSB7XHJcbiAgICAgIC8vIEhvcml6b250YWwgc2lkZVxyXG4gICAgICBjb25zdCBzaWduID0gTWF0aC5jb3MoYW5nbGUpID4gMCA/IC0xIDogMTtcclxuICAgICAgYWRqdXN0ZWRFbmRYID0gZW5kWCArIHNpZ24gKiB3aWR0aCAvIDI7XHJcbiAgICAgIGFkanVzdGVkRW5kWSA9IGVuZFkgKyBNYXRoLnNpbihhbmdsZSkgLyBNYXRoLmNvcyhhbmdsZSkgKiBzaWduICogd2lkdGggLyAyO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgLy8gVmVydGljYWwgc2lkZVxyXG4gICAgICBjb25zdCBzaWduID0gTWF0aC5zaW4oYW5nbGUpID4gMCA/IC0xIDogMTtcclxuICAgICAgYWRqdXN0ZWRFbmRYID0gZW5kWCArIE1hdGguY29zKGFuZ2xlKSAvIE1hdGguc2luKGFuZ2xlKSAqIHNpZ24gKiBoZWlnaHQgLyAyO1xyXG4gICAgICBhZGp1c3RlZEVuZFkgPSBlbmRZICsgc2lnbiAqIGhlaWdodCAvIDI7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyBDYWxjdWxhdGUgYXJyb3cgaGVhZCBwb2ludHNcclxuICBjb25zdCBhcnJvd0hlYWRTaXplID0gMTA7XHJcbiAgY29uc3QgYXJyb3dBbmdsZTEgPSBhbmdsZSAtIE1hdGguUEkgLyA2O1xyXG4gIGNvbnN0IGFycm93QW5nbGUyID0gYW5nbGUgKyBNYXRoLlBJIC8gNjtcclxuICBcclxuICBjb25zdCBhcnJvd1BvaW50MVggPSBhZGp1c3RlZEVuZFggLSBhcnJvd0hlYWRTaXplICogTWF0aC5jb3MoYXJyb3dBbmdsZTEpO1xyXG4gIGNvbnN0IGFycm93UG9pbnQxWSA9IGFkanVzdGVkRW5kWSAtIGFycm93SGVhZFNpemUgKiBNYXRoLnNpbihhcnJvd0FuZ2xlMSk7XHJcbiAgY29uc3QgYXJyb3dQb2ludDJYID0gYWRqdXN0ZWRFbmRYIC0gYXJyb3dIZWFkU2l6ZSAqIE1hdGguY29zKGFycm93QW5nbGUyKTtcclxuICBjb25zdCBhcnJvd1BvaW50MlkgPSBhZGp1c3RlZEVuZFkgLSBhcnJvd0hlYWRTaXplICogTWF0aC5zaW4oYXJyb3dBbmdsZTIpO1xyXG5cclxuICAvLyBDYWxjdWxhdGUgbWlkcG9pbnQgZm9yIHdlaWdodCBsYWJlbFxyXG4gIGNvbnN0IG1pZFggPSAoYWRqdXN0ZWRTdGFydFggKyBhZGp1c3RlZEVuZFgpIC8gMjtcclxuICBjb25zdCBtaWRZID0gKGFkanVzdGVkU3RhcnRZICsgYWRqdXN0ZWRFbmRZKSAvIDI7XHJcbiAgXHJcbiAgLy8gT2Zmc2V0IHRoZSBsYWJlbCBzbGlnaHRseSB0byBub3Qgb3ZlcmxhcCB3aXRoIHRoZSBsaW5lXHJcbiAgY29uc3QgbGFiZWxPZmZzZXRYID0gLTEwICogTWF0aC5zaW4oYW5nbGUpO1xyXG4gIGNvbnN0IGxhYmVsT2Zmc2V0WSA9IDEwICogTWF0aC5jb3MoYW5nbGUpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEdyb3VwIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICB7LyogSW52aXNpYmxlIHdpZGVyIGxpbmUgZm9yIGVhc2llciBzZWxlY3Rpb24gKi99XHJcbiAgICAgIDxMaW5lXHJcbiAgICAgICAgcG9pbnRzPXtbYWRqdXN0ZWRTdGFydFgsIGFkanVzdGVkU3RhcnRZLCBhZGp1c3RlZEVuZFgsIGFkanVzdGVkRW5kWV19XHJcbiAgICAgICAgc3Ryb2tlPVwidHJhbnNwYXJlbnRcIlxyXG4gICAgICAgIHN0cm9rZVdpZHRoPXsxNX1cclxuICAgICAgICBoaXRTdHJva2VXaWR0aD17MjB9XHJcbiAgICAgIC8+XHJcbiAgICAgIFxyXG4gICAgICB7LyogQXJjIGxpbmUgKi99XHJcbiAgICAgIDxMaW5lXHJcbiAgICAgICAgcG9pbnRzPXtbYWRqdXN0ZWRTdGFydFgsIGFkanVzdGVkU3RhcnRZLCBhZGp1c3RlZEVuZFgsIGFkanVzdGVkRW5kWV19XHJcbiAgICAgICAgc3Ryb2tlPXtpc1NlbGVjdGVkID8gJ2JsdWUnIDogJ2JsYWNrJ31cclxuICAgICAgICBzdHJva2VXaWR0aD17aXNTZWxlY3RlZCA/IDIgOiAxfVxyXG4gICAgICAvPlxyXG4gICAgICBcclxuICAgICAgey8qIEFycm93IGhlYWQgKi99XHJcbiAgICAgIDxMaW5lXHJcbiAgICAgICAgcG9pbnRzPXtbXHJcbiAgICAgICAgICBhZGp1c3RlZEVuZFgsIGFkanVzdGVkRW5kWSxcclxuICAgICAgICAgIGFycm93UG9pbnQxWCwgYXJyb3dQb2ludDFZLFxyXG4gICAgICAgICAgYXJyb3dQb2ludDJYLCBhcnJvd1BvaW50MlksXHJcbiAgICAgICAgICBhZGp1c3RlZEVuZFgsIGFkanVzdGVkRW5kWVxyXG4gICAgICAgIF19XHJcbiAgICAgICAgY2xvc2VkPXt0cnVlfVxyXG4gICAgICAgIGZpbGw9XCJibGFja1wiXHJcbiAgICAgICAgc3Ryb2tlPVwiYmxhY2tcIlxyXG4gICAgICAvPlxyXG4gICAgICBcclxuICAgICAgey8qIFdlaWdodCBsYWJlbCAqL31cclxuICAgICAge2FyYy53ZWlnaHQgJiYgYXJjLndlaWdodCA+IDEgJiYgKFxyXG4gICAgICAgIDxUZXh0XHJcbiAgICAgICAgICB0ZXh0PXthcmMud2VpZ2h0LnRvU3RyaW5nKCl9XHJcbiAgICAgICAgICBmb250U2l6ZT17MTJ9XHJcbiAgICAgICAgICBmaWxsPVwiYmxhY2tcIlxyXG4gICAgICAgICAgeD17bWlkWCArIGxhYmVsT2Zmc2V0WCAtIDV9XHJcbiAgICAgICAgICB5PXttaWRZICsgbGFiZWxPZmZzZXRZIC0gNX1cclxuICAgICAgICAgIHdpZHRoPXsxMH1cclxuICAgICAgICAgIGFsaWduPVwiY2VudGVyXCJcclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgPC9Hcm91cD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXJjO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0xldmkvQ2FzY2FkZVByb2plY3RzL3BldHJpLW5ldC1lZGl0b3IvcGV0cmktbmV0LWFwcC9zcmMvY29tcG9uZW50cy9BcmMuanN4In0=