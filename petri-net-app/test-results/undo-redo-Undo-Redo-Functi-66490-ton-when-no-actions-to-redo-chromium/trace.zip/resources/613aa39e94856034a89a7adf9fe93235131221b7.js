import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ExecutionPanel.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
const ExecutionPanel = ({ elements }) => {
  const { places, transitions, arcs } = elements;
  const enabledTransitions = [];
  return /* @__PURE__ */ jsxDEV("div", { className: "execution-panel p-4 bg-gray-100 border-t border-gray-300", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold mb-2", children: "Execution" }, void 0, false, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "current-marking mr-8", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-medium mb-2", children: "Current Marking" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
          lineNumber: 35,
          columnNumber: 11
        }, this),
        places.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No places defined" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
          lineNumber: 37,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-2", children: places.map(
          (place) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium mr-2", children: [
              place.name,
              ":"
            ] }, void 0, true, {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
              lineNumber: 42,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: place.tokens || 0 }, void 0, false, {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
              lineNumber: 43,
              columnNumber: 19
            }, this)
          ] }, place.id, true, {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
            lineNumber: 41,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
          lineNumber: 39,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "enabled-transitions", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-medium mb-2", children: "Enabled Transitions" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this),
        transitions.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No transitions defined" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
          lineNumber: 53,
          columnNumber: 11
        }, this) : enabledTransitions.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No enabled transitions" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
          lineNumber: 55,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: enabledTransitions.map(
          (transition) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "px-3 py-1 bg-green-100 border border-green-300 rounded hover:bg-green-200",
              children: transition.name
            },
            transition.id,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
              lineNumber: 59,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
          lineNumber: 57,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
};
_c = ExecutionPanel;
export default ExecutionPanel;
var _c;
$RefreshReg$(_c, "ExecutionPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/ExecutionPanel.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007Ozs7Ozs7Ozs7Ozs7Ozs7QUFYTixPQUFPQSxXQUFXO0FBRWxCLE1BQU1DLGlCQUFpQkEsQ0FBQyxFQUFFQyxTQUFTLE1BQU07QUFDdkMsUUFBTSxFQUFFQyxRQUFRQyxhQUFhQyxLQUFLLElBQUlIO0FBSXRDLFFBQU1JLHFCQUFxQjtBQUUzQixTQUNFLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSw4QkFBNkIseUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0Q7QUFBQSxJQUVwRCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSw0QkFBMkIsK0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Q7QUFBQSxRQUN2REgsT0FBT0ksV0FBVyxJQUNqQix1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLGlDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDLElBRTlDLHVCQUFDLFNBQUksV0FBVSwwQkFDWkosaUJBQU9LO0FBQUFBLFVBQUksQ0FBQUMsVUFDVix1QkFBQyxTQUFtQixXQUFVLHFCQUM1QjtBQUFBLG1DQUFDLFVBQUssV0FBVSxvQkFBb0JBO0FBQUFBLG9CQUFNQztBQUFBQSxjQUFLO0FBQUEsaUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsWUFDaEQsdUJBQUMsVUFBTUQsZ0JBQU1FLFVBQVUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxlQUZqQkYsTUFBTUcsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDRCQUEyQixtQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBQzNEUixZQUFZRyxXQUFXLElBQ3RCLHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0Isc0NBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQsSUFDakRELG1CQUFtQkMsV0FBVyxJQUNoQyx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLHNDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1ELElBRW5ELHVCQUFDLFNBQUksV0FBVSx3QkFDWkQsNkJBQW1CRTtBQUFBQSxVQUFJLENBQUFLLGVBQ3RCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FFVEEscUJBQVdIO0FBQUFBO0FBQUFBLFlBSFBHLFdBQVdEO0FBQUFBLFlBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFFBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsU0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9DQTtBQUFBLE9BdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3Q0E7QUFFSjtBQUFFRSxLQWxESWI7QUFvRE4sZUFBZUE7QUFBZSxJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJFeGVjdXRpb25QYW5lbCIsImVsZW1lbnRzIiwicGxhY2VzIiwidHJhbnNpdGlvbnMiLCJhcmNzIiwiZW5hYmxlZFRyYW5zaXRpb25zIiwibGVuZ3RoIiwibWFwIiwicGxhY2UiLCJuYW1lIiwidG9rZW5zIiwiaWQiLCJ0cmFuc2l0aW9uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJFeGVjdXRpb25QYW5lbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuY29uc3QgRXhlY3V0aW9uUGFuZWwgPSAoeyBlbGVtZW50cyB9KSA9PiB7XG4gIGNvbnN0IHsgcGxhY2VzLCB0cmFuc2l0aW9ucywgYXJjcyB9ID0gZWxlbWVudHM7XG4gIFxuICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHRoaXMgd291bGQgY29tcHV0ZSBlbmFibGVkIHRyYW5zaXRpb25zXG4gIC8vIGJhc2VkIG9uIHRoZSBjdXJyZW50IG1hcmtpbmcgKHRva2VuIGRpc3RyaWJ1dGlvbilcbiAgY29uc3QgZW5hYmxlZFRyYW5zaXRpb25zID0gW107XG4gIFxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhlY3V0aW9uLXBhbmVsIHAtNCBiZy1ncmF5LTEwMCBib3JkZXItdCBib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgbWItMlwiPkV4ZWN1dGlvbjwvaDI+XG4gICAgICBcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImN1cnJlbnQtbWFya2luZyBtci04XCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMlwiPkN1cnJlbnQgTWFya2luZzwvaDM+XG4gICAgICAgICAge3BsYWNlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+Tm8gcGxhY2VzIGRlZmluZWQ8L3A+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMlwiPlxuICAgICAgICAgICAgICB7cGxhY2VzLm1hcChwbGFjZSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e3BsYWNlLmlkfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gbXItMlwiPntwbGFjZS5uYW1lfTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57cGxhY2UudG9rZW5zIHx8IDB9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbmFibGVkLXRyYW5zaXRpb25zXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMlwiPkVuYWJsZWQgVHJhbnNpdGlvbnM8L2gzPlxuICAgICAgICAgIHt0cmFuc2l0aW9ucy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+Tm8gdHJhbnNpdGlvbnMgZGVmaW5lZDwvcD5cbiAgICAgICAgICApIDogZW5hYmxlZFRyYW5zaXRpb25zLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5ObyBlbmFibGVkIHRyYW5zaXRpb25zPC9wPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgIHtlbmFibGVkVHJhbnNpdGlvbnMubWFwKHRyYW5zaXRpb24gPT4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17dHJhbnNpdGlvbi5pZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1ncmVlbi0xMDAgYm9yZGVyIGJvcmRlci1ncmVlbi0zMDAgcm91bmRlZCBob3ZlcjpiZy1ncmVlbi0yMDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHt0cmFuc2l0aW9uLm5hbWV9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEV4ZWN1dGlvblBhbmVsO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9MZXZpL0Nhc2NhZGVQcm9qZWN0cy9wZXRyaS1uZXQtZWRpdG9yL3BldHJpLW5ldC1hcHAvc3JjL2NvbXBvbmVudHMvRXhlY3V0aW9uUGFuZWwuanN4In0=