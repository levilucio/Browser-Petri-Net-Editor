import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Toolbar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
const Toolbar = ({ mode, setMode, gridSnappingEnabled, toggleGridSnapping, canUndo, canRedo, onUndo, onRedo }) => {
  const separatorStyle = {
    width: "1px",
    backgroundColor: "#d1d5db",
    // gray-300
    margin: "0 16px",
    height: "100%",
    // Full height
    alignSelf: "stretch"
    // Stretch to fill container height
  };
  const buttonStyle = (isSelected) => ({
    padding: "0.25rem 0.75rem",
    borderRadius: "0.25rem",
    backgroundColor: isSelected ? "#4338ca" : "white",
    // indigo-700 or white
    color: isSelected ? "white" : "black",
    border: isSelected ? "none" : "1px solid #d1d5db",
    // gray-300
    margin: "0 0.25rem"
    // Even spacing on both sides
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "toolbar flex p-2 bg-gray-100 border-b border-gray-300", style: { minHeight: "70px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "file-operations", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold mb-1", children: "File" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsxDEV("button", { style: { ...buttonStyle(false) }, children: "Save" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 48,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { style: buttonStyle(false), children: "Load" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { style: buttonStyle(false), children: "Clear" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 54,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: separatorStyle }, void 0, false, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
      lineNumber: 61,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "editing-tools", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold mb-1", children: "Editing" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 65,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mr-4", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              id: "grid-snap-toggle",
              "data-testid": "grid-snap-toggle",
              checked: gridSnappingEnabled,
              onChange: toggleGridSnapping,
              className: "mr-1"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
              lineNumber: 69,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "grid-snap-toggle", className: "text-sm", children: "Snap to Grid" }, void 0, false, {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
            lineNumber: 77,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 68,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              style: { ...buttonStyle(mode === "select") },
              onClick: () => setMode("select"),
              children: "Select"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
              lineNumber: 80,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              style: buttonStyle(mode === "place"),
              "data-testid": "toolbar-place",
              onClick: () => setMode("place"),
              children: "Place"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
              lineNumber: 86,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              style: buttonStyle(mode === "transition"),
              onClick: () => setMode("transition"),
              children: "Transition"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
              lineNumber: 93,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              style: buttonStyle(mode === "arc"),
              onClick: () => setMode("arc"),
              children: "Arc"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
              lineNumber: 99,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 79,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 66,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: separatorStyle }, void 0, false, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "simulation-tools", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold mb-1", children: "Simulation" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsxDEV("button", { style: buttonStyle(false), children: "Step-by-Step" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 116,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { style: buttonStyle(false), children: "Quick Visual" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 119,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { style: buttonStyle(false), children: "Non-Visual" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 122,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { style: buttonStyle(false), children: "Stop" }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
          lineNumber: 125,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 115,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "history-tools ml-auto", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold mb-1", children: "History" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 132,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            style: { ...buttonStyle(false), opacity: canUndo ? 1 : 0.5 },
            onClick: onUndo,
            disabled: !canUndo,
            title: "Undo (Ctrl+Z)",
            children: "Undo"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
            lineNumber: 134,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            style: { ...buttonStyle(false), opacity: canRedo ? 1 : 0.5 },
            onClick: onRedo,
            disabled: !canRedo,
            title: "Redo (Ctrl+Y)",
            children: "Redo"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
            lineNumber: 142,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
        lineNumber: 133,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
      lineNumber: 131,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx",
    lineNumber: 43,
    columnNumber: 5
  }, this);
};
_c = Toolbar;
export default Toolbar;
var _c;
$RefreshReg$(_c, "Toolbar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Toolbar.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJROzs7Ozs7Ozs7Ozs7Ozs7O0FBMUJSLE9BQU9BLFdBQVc7QUFFbEIsTUFBTUMsVUFBVUEsQ0FBQyxFQUFFQyxNQUFNQyxTQUFTQyxxQkFBcUJDLG9CQUFvQkMsU0FBU0MsU0FBU0MsUUFBUUMsT0FBTyxNQUFNO0FBRWhILFFBQU1DLGlCQUFpQjtBQUFBLElBQ3JCQyxPQUFPO0FBQUEsSUFDUEMsaUJBQWlCO0FBQUE7QUFBQSxJQUNqQkMsUUFBUTtBQUFBLElBQ1JDLFFBQVE7QUFBQTtBQUFBLElBQ1JDLFdBQVc7QUFBQTtBQUFBLEVBQ2I7QUFHQSxRQUFNQyxjQUFjQSxDQUFDQyxnQkFBZ0I7QUFBQSxJQUNuQ0MsU0FBUztBQUFBLElBQ1RDLGNBQWM7QUFBQSxJQUNkUCxpQkFBaUJLLGFBQWEsWUFBWTtBQUFBO0FBQUEsSUFDMUNHLE9BQU9ILGFBQWEsVUFBVTtBQUFBLElBQzlCSSxRQUFRSixhQUFhLFNBQVM7QUFBQTtBQUFBLElBQzlCSixRQUFRO0FBQUE7QUFBQSxFQUNWO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUseURBQXdELE9BQU8sRUFBRVMsV0FBVyxPQUFPLEdBRWhHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDhCQUE2QixvQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLE1BQy9DLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLCtCQUFDLFlBQU8sT0FBTyxFQUFFLEdBQUdOLFlBQVksS0FBSyxFQUFFLEdBQUcsb0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxPQUFPQSxZQUFZLEtBQUssR0FBRyxvQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLE9BQU9BLFlBQVksS0FBSyxHQUFHLHFCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU9OLGtCQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxJQUc1Qix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsOEJBQTZCLHVCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsTUFDbEQsdUJBQUMsU0FBSSxXQUFVLHFCQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLElBQUc7QUFBQSxjQUNILGVBQVk7QUFBQSxjQUNaLFNBQVNOO0FBQUFBLGNBQ1QsVUFBVUM7QUFBQUEsY0FDVixXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1rQjtBQUFBLFVBRWxCLHVCQUFDLFdBQU0sU0FBUSxvQkFBbUIsV0FBVSxXQUFVLDRCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRTtBQUFBLGFBVHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU8sRUFBRSxHQUFHVyxZQUFZZCxTQUFTLFFBQVEsRUFBRTtBQUFBLGNBQzNDLFNBQVMsTUFBTUMsUUFBUSxRQUFRO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPYSxZQUFZZCxTQUFTLE9BQU87QUFBQSxjQUNuQyxlQUFZO0FBQUEsY0FDWixTQUFTLE1BQU1DLFFBQVEsT0FBTztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT2EsWUFBWWQsU0FBUyxZQUFZO0FBQUEsY0FDeEMsU0FBUyxNQUFNQyxRQUFRLFlBQVk7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9hLFlBQVlkLFNBQVMsS0FBSztBQUFBLGNBQ2pDLFNBQVMsTUFBTUMsUUFBUSxLQUFLO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsV0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdDQTtBQUFBLFNBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQ0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBT08sa0JBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0QjtBQUFBLElBRzVCLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSw4QkFBNkIsMEJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxNQUNyRCx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSwrQkFBQyxZQUFPLE9BQU9NLFlBQVksS0FBSyxHQUFHLDRCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sT0FBT0EsWUFBWSxLQUFLLEdBQUcsNEJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxPQUFPQSxZQUFZLEtBQUssR0FBRywwQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLE9BQU9BLFlBQVksS0FBSyxHQUFHLG9CQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDhCQUE2Qix1QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQ2xELHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPLEVBQUUsR0FBR0EsWUFBWSxLQUFLLEdBQUdPLFNBQVNqQixVQUFVLElBQUksSUFBSTtBQUFBLFlBQzNELFNBQVNFO0FBQUFBLFlBQ1QsVUFBVSxDQUFDRjtBQUFBQSxZQUNYLE9BQU07QUFBQSxZQUFlO0FBQUE7QUFBQSxVQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU8sRUFBRSxHQUFHVSxZQUFZLEtBQUssR0FBR08sU0FBU2hCLFVBQVUsSUFBSSxJQUFJO0FBQUEsWUFDM0QsU0FBU0U7QUFBQUEsWUFDVCxVQUFVLENBQUNGO0FBQUFBLFlBQ1gsT0FBTTtBQUFBLFlBQWU7QUFBQTtBQUFBLFVBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxPQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkdBO0FBRUo7QUFBRWlCLEtBcElJdkI7QUFzSU4sZUFBZUE7QUFBUSxJQUFBdUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiVG9vbGJhciIsIm1vZGUiLCJzZXRNb2RlIiwiZ3JpZFNuYXBwaW5nRW5hYmxlZCIsInRvZ2dsZUdyaWRTbmFwcGluZyIsImNhblVuZG8iLCJjYW5SZWRvIiwib25VbmRvIiwib25SZWRvIiwic2VwYXJhdG9yU3R5bGUiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsIm1hcmdpbiIsImhlaWdodCIsImFsaWduU2VsZiIsImJ1dHRvblN0eWxlIiwiaXNTZWxlY3RlZCIsInBhZGRpbmciLCJib3JkZXJSYWRpdXMiLCJjb2xvciIsImJvcmRlciIsIm1pbkhlaWdodCIsIm9wYWNpdHkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRvb2xiYXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcblxyXG5jb25zdCBUb29sYmFyID0gKHsgbW9kZSwgc2V0TW9kZSwgZ3JpZFNuYXBwaW5nRW5hYmxlZCwgdG9nZ2xlR3JpZFNuYXBwaW5nLCBjYW5VbmRvLCBjYW5SZWRvLCBvblVuZG8sIG9uUmVkbyB9KSA9PiB7XHJcbiAgLy8gU3R5bGVzIGZvciB0aGUgc2VwYXJhdG9yXHJcbiAgY29uc3Qgc2VwYXJhdG9yU3R5bGUgPSB7XHJcbiAgICB3aWR0aDogJzFweCcsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZDFkNWRiJywgLy8gZ3JheS0zMDBcclxuICAgIG1hcmdpbjogJzAgMTZweCcsXHJcbiAgICBoZWlnaHQ6ICcxMDAlJywgLy8gRnVsbCBoZWlnaHRcclxuICAgIGFsaWduU2VsZjogJ3N0cmV0Y2gnIC8vIFN0cmV0Y2ggdG8gZmlsbCBjb250YWluZXIgaGVpZ2h0XHJcbiAgfTtcclxuXHJcbiAgLy8gQ29tbW9uIGJ1dHRvbiBzdHlsZVxyXG4gIGNvbnN0IGJ1dHRvblN0eWxlID0gKGlzU2VsZWN0ZWQpID0+ICh7XHJcbiAgICBwYWRkaW5nOiAnMC4yNXJlbSAwLjc1cmVtJyxcclxuICAgIGJvcmRlclJhZGl1czogJzAuMjVyZW0nLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiBpc1NlbGVjdGVkID8gJyM0MzM4Y2EnIDogJ3doaXRlJywgLy8gaW5kaWdvLTcwMCBvciB3aGl0ZVxyXG4gICAgY29sb3I6IGlzU2VsZWN0ZWQgPyAnd2hpdGUnIDogJ2JsYWNrJyxcclxuICAgIGJvcmRlcjogaXNTZWxlY3RlZCA/ICdub25lJyA6ICcxcHggc29saWQgI2QxZDVkYicsIC8vIGdyYXktMzAwXHJcbiAgICBtYXJnaW46ICcwIDAuMjVyZW0nIC8vIEV2ZW4gc3BhY2luZyBvbiBib3RoIHNpZGVzXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInRvb2xiYXIgZmxleCBwLTIgYmctZ3JheS0xMDAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMzAwXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiAnNzBweCcgfX0+XHJcbiAgICAgIHsvKiBGaWxlIE9wZXJhdGlvbnMgR3JvdXAgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsZS1vcGVyYXRpb25zXCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCBtYi0xXCI+RmlsZTwvaDM+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgPGJ1dHRvbiBzdHlsZT17eyAuLi5idXR0b25TdHlsZShmYWxzZSkgfX0+XHJcbiAgICAgICAgICAgIFNhdmVcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiBzdHlsZT17YnV0dG9uU3R5bGUoZmFsc2UpfT5cclxuICAgICAgICAgICAgTG9hZFxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIHN0eWxlPXtidXR0b25TdHlsZShmYWxzZSl9PlxyXG4gICAgICAgICAgICBDbGVhclxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICAgey8qIFZpc3VhbCBzZXBhcmF0b3IgKi99XHJcbiAgICAgIDxkaXYgc3R5bGU9e3NlcGFyYXRvclN0eWxlfT48L2Rpdj5cclxuICAgICAgXHJcbiAgICAgIHsvKiBFZGl0aW5nIFRvb2xzIEdyb3VwICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImVkaXRpbmctdG9vbHNcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIG1iLTFcIj5FZGl0aW5nPC9oMz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICB7LyogR3JpZCBTbmFwcGluZyBUb2dnbGUgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG1yLTRcIj5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICBpZD1cImdyaWQtc25hcC10b2dnbGVcIlxyXG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZ3JpZC1zbmFwLXRvZ2dsZVwiXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17Z3JpZFNuYXBwaW5nRW5hYmxlZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17dG9nZ2xlR3JpZFNuYXBwaW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTFcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImdyaWQtc25hcC10b2dnbGVcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+U25hcCB0byBHcmlkPC9sYWJlbD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IC4uLmJ1dHRvblN0eWxlKG1vZGUgPT09ICdzZWxlY3QnKSB9fVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGUoJ3NlbGVjdCcpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgU2VsZWN0XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgIHN0eWxlPXtidXR0b25TdHlsZShtb2RlID09PSAncGxhY2UnKX1cclxuICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInRvb2xiYXItcGxhY2VcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGUoJ3BsYWNlJyl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBQbGFjZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgICBzdHlsZT17YnV0dG9uU3R5bGUobW9kZSA9PT0gJ3RyYW5zaXRpb24nKX1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RlKCd0cmFuc2l0aW9uJyl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBUcmFuc2l0aW9uXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgIHN0eWxlPXtidXR0b25TdHlsZShtb2RlID09PSAnYXJjJyl9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9kZSgnYXJjJyl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBcmNcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIFxyXG4gICAgICB7LyogVmlzdWFsIHNlcGFyYXRvciAqL31cclxuICAgICAgPGRpdiBzdHlsZT17c2VwYXJhdG9yU3R5bGV9PjwvZGl2PlxyXG4gICAgICBcclxuICAgICAgey8qIFNpbXVsYXRpb24gVG9vbHMgR3JvdXAgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2ltdWxhdGlvbi10b29sc1wiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgbWItMVwiPlNpbXVsYXRpb248L2gzPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxidXR0b24gc3R5bGU9e2J1dHRvblN0eWxlKGZhbHNlKX0+XHJcbiAgICAgICAgICAgIFN0ZXAtYnktU3RlcFxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIHN0eWxlPXtidXR0b25TdHlsZShmYWxzZSl9PlxyXG4gICAgICAgICAgICBRdWljayBWaXN1YWxcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiBzdHlsZT17YnV0dG9uU3R5bGUoZmFsc2UpfT5cclxuICAgICAgICAgICAgTm9uLVZpc3VhbFxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIHN0eWxlPXtidXR0b25TdHlsZShmYWxzZSl9PlxyXG4gICAgICAgICAgICBTdG9wXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnktdG9vbHMgbWwtYXV0b1wiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgbWItMVwiPkhpc3Rvcnk8L2gzPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IC4uLmJ1dHRvblN0eWxlKGZhbHNlKSwgb3BhY2l0eTogY2FuVW5kbyA/IDEgOiAwLjUgfX1cclxuICAgICAgICAgICAgb25DbGljaz17b25VbmRvfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IWNhblVuZG99XHJcbiAgICAgICAgICAgIHRpdGxlPVwiVW5kbyAoQ3RybCtaKVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFVuZG9cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgc3R5bGU9e3sgLi4uYnV0dG9uU3R5bGUoZmFsc2UpLCBvcGFjaXR5OiBjYW5SZWRvID8gMSA6IDAuNSB9fVxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvblJlZG99XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshY2FuUmVkb31cclxuICAgICAgICAgICAgdGl0bGU9XCJSZWRvIChDdHJsK1kpXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmVkb1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRvb2xiYXI7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvTGV2aS9DYXNjYWRlUHJvamVjdHMvcGV0cmktbmV0LWVkaXRvci9wZXRyaS1uZXQtYXBwL3NyYy9jb21wb25lbnRzL1Rvb2xiYXIuanN4In0=