import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Place.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Circle, Text, Group, Line } from "/node_modules/.vite/deps/react-konva.js?v=4e926b2f";
const Place = ({ place, isSelected, isDragging, onClick, onDragStart, onDragMove, onDragEnd }) => {
  const radius = 20;
  const renderSnapIndicators = () => {
    if (!isDragging)
      return null;
    const indicatorLength = 10;
    const indicatorColor = "rgba(0, 150, 255, 0.7)";
    const indicatorWidth = 1;
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          points: [-radius - indicatorLength, 0, radius + indicatorLength, 0],
          stroke: indicatorColor,
          strokeWidth: indicatorWidth,
          dash: [4, 2]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
          lineNumber: 37,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          points: [0, -radius - indicatorLength, 0, radius + indicatorLength],
          stroke: indicatorColor,
          strokeWidth: indicatorWidth,
          dash: [4, 2]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
          lineNumber: 44,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(
    Group,
    {
      x: place.x,
      y: place.y,
      onClick,
      draggable: true,
      onDragStart,
      onDragMove,
      onDragEnd,
      children: [
        renderSnapIndicators(),
        /* @__PURE__ */ jsxDEV(
          Circle,
          {
            radius,
            fill: "white",
            stroke: isSelected ? "blue" : isDragging ? "rgba(0, 150, 255, 0.7)" : "black",
            strokeWidth: isSelected || isDragging ? 2 : 1
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
            lineNumber: 68,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Text,
          {
            text: place.name,
            fontSize: 12,
            fill: "black",
            x: -radius,
            y: radius + 5,
            width: radius * 2,
            align: "center"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
            lineNumber: 76,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Text,
          {
            text: place.tokens.toString(),
            fontSize: 14,
            fill: "black",
            x: -radius,
            y: -7,
            width: radius * 2,
            align: "center"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
            lineNumber: 87,
            columnNumber: 7
          },
          this
        ),
        place.tokens > 0 && place.tokens <= 5 && /* @__PURE__ */ jsxDEV(Fragment, { children: Array.from({ length: place.tokens }).map((_, index) => {
          const angle = 2 * Math.PI * index / place.tokens;
          const tokenRadius = 4;
          const distance = radius / 2;
          const tokenX = Math.cos(angle) * distance;
          const tokenY = Math.sin(angle) * distance;
          return /* @__PURE__ */ jsxDEV(
            Circle,
            {
              x: tokenX,
              y: tokenY,
              radius: tokenRadius,
              fill: "black"
            },
            index,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
              lineNumber: 109,
              columnNumber: 13
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
          lineNumber: 99,
          columnNumber: 7
        }, this),
        place.tokens > 5 && /* @__PURE__ */ jsxDEV(
          Text,
          {
            text: place.tokens.toString(),
            fontSize: 16,
            fontStyle: "bold",
            fill: "black",
            x: -radius,
            y: -9,
            width: radius * 2,
            align: "center"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
            lineNumber: 123,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx",
      lineNumber: 55,
      columnNumber: 5
    },
    this
  );
};
_c = Place;
export default Place;
var _c;
$RefreshReg$(_c, "Place");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/Place.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU0sbUJBRUUsY0FGRjs7Ozs7Ozs7Ozs7Ozs7OztBQWZOLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsUUFBUUMsTUFBTUMsT0FBT0MsWUFBWTtBQUUxQyxNQUFNQyxRQUFRQSxDQUFDLEVBQUVDLE9BQU9DLFlBQVlDLFlBQVlDLFNBQVNDLGFBQWFDLFlBQVlDLFVBQVUsTUFBTTtBQUNoRyxRQUFNQyxTQUFTO0FBR2YsUUFBTUMsdUJBQXVCQSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ047QUFBWSxhQUFPO0FBRXhCLFVBQU1PLGtCQUFrQjtBQUN4QixVQUFNQyxpQkFBaUI7QUFDdkIsVUFBTUMsaUJBQWlCO0FBRXZCLFdBQ0UsbUNBRUU7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsUUFBUSxDQUFDLENBQUNKLFNBQVNFLGlCQUFpQixHQUFHRixTQUFTRSxpQkFBaUIsQ0FBQztBQUFBLFVBQ2xFLFFBQVFDO0FBQUFBLFVBQ1IsYUFBYUM7QUFBQUEsVUFDYixNQUFNLENBQUMsR0FBRyxDQUFDO0FBQUE7QUFBQSxRQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUllO0FBQUEsTUFHZjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsUUFBUSxDQUFDLEdBQUcsQ0FBQ0osU0FBU0UsaUJBQWlCLEdBQUdGLFNBQVNFLGVBQWU7QUFBQSxVQUNsRSxRQUFRQztBQUFBQSxVQUNSLGFBQWFDO0FBQUFBLFVBQ2IsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUFBO0FBQUEsUUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJZTtBQUFBLFNBYmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLEVBRUo7QUFFQSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxHQUFHWCxNQUFNWTtBQUFBQSxNQUNULEdBQUdaLE1BQU1hO0FBQUFBLE1BQ1Q7QUFBQSxNQUNBLFdBQVc7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUdDTDtBQUFBQSw2QkFBcUI7QUFBQSxRQUd0QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLE1BQUs7QUFBQSxZQUNMLFFBQVFQLGFBQWEsU0FBVUMsYUFBYSwyQkFBMkI7QUFBQSxZQUN2RSxhQUFhRCxjQUFjQyxhQUFhLElBQUk7QUFBQTtBQUFBLFVBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlnRDtBQUFBLFFBSWhEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNRixNQUFNYztBQUFBQSxZQUNaLFVBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLEdBQUcsQ0FBQ1A7QUFBQUEsWUFDSixHQUFHQSxTQUFTO0FBQUEsWUFDWixPQUFPQSxTQUFTO0FBQUEsWUFDaEIsT0FBTTtBQUFBO0FBQUEsVUFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPZ0I7QUFBQSxRQUloQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTVAsTUFBTWUsT0FBT0MsU0FBUztBQUFBLFlBQzVCLFVBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLEdBQUcsQ0FBQ1Q7QUFBQUEsWUFDSixHQUFHO0FBQUEsWUFDSCxPQUFPQSxTQUFTO0FBQUEsWUFDaEIsT0FBTTtBQUFBO0FBQUEsVUFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPZ0I7QUFBQSxRQUlmUCxNQUFNZSxTQUFTLEtBQUtmLE1BQU1lLFVBQVUsS0FDbkMsbUNBQ0dFLGdCQUFNQyxLQUFLLEVBQUVDLFFBQVFuQixNQUFNZSxPQUFPLENBQUMsRUFBRUssSUFBSSxDQUFDQyxHQUFHQyxVQUFVO0FBRXRELGdCQUFNQyxRQUFTLElBQUlDLEtBQUtDLEtBQUtILFFBQVN0QixNQUFNZTtBQUM1QyxnQkFBTVcsY0FBYztBQUNwQixnQkFBTUMsV0FBV3BCLFNBQVM7QUFDMUIsZ0JBQU1xQixTQUFTSixLQUFLSyxJQUFJTixLQUFLLElBQUlJO0FBQ2pDLGdCQUFNRyxTQUFTTixLQUFLTyxJQUFJUixLQUFLLElBQUlJO0FBRWpDLGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxHQUFHQztBQUFBQSxjQUNILEdBQUdFO0FBQUFBLGNBQ0gsUUFBUUo7QUFBQUEsY0FDUixNQUFLO0FBQUE7QUFBQSxZQUpBSjtBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLYztBQUFBLFFBR2xCLENBQUMsS0FsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBSUR0QixNQUFNZSxTQUFTLEtBQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU1mLE1BQU1lLE9BQU9DLFNBQVM7QUFBQSxZQUM1QixVQUFVO0FBQUEsWUFDVixXQUFVO0FBQUEsWUFDVixNQUFLO0FBQUEsWUFDTCxHQUFHLENBQUNUO0FBQUFBLFlBQ0osR0FBRztBQUFBLFlBQ0gsT0FBT0EsU0FBUztBQUFBLFlBQ2hCLE9BQU07QUFBQTtBQUFBLFVBUlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUWdCO0FBQUE7QUFBQTtBQUFBLElBNUVwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUErRUE7QUFFSjtBQUFFeUIsS0FqSElqQztBQW1ITixlQUFlQTtBQUFNLElBQUFpQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJDaXJjbGUiLCJUZXh0IiwiR3JvdXAiLCJMaW5lIiwiUGxhY2UiLCJwbGFjZSIsImlzU2VsZWN0ZWQiLCJpc0RyYWdnaW5nIiwib25DbGljayIsIm9uRHJhZ1N0YXJ0Iiwib25EcmFnTW92ZSIsIm9uRHJhZ0VuZCIsInJhZGl1cyIsInJlbmRlclNuYXBJbmRpY2F0b3JzIiwiaW5kaWNhdG9yTGVuZ3RoIiwiaW5kaWNhdG9yQ29sb3IiLCJpbmRpY2F0b3JXaWR0aCIsIngiLCJ5IiwibmFtZSIsInRva2VucyIsInRvU3RyaW5nIiwiQXJyYXkiLCJmcm9tIiwibGVuZ3RoIiwibWFwIiwiXyIsImluZGV4IiwiYW5nbGUiLCJNYXRoIiwiUEkiLCJ0b2tlblJhZGl1cyIsImRpc3RhbmNlIiwidG9rZW5YIiwiY29zIiwidG9rZW5ZIiwic2luIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQbGFjZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2lyY2xlLCBUZXh0LCBHcm91cCwgTGluZSB9IGZyb20gJ3JlYWN0LWtvbnZhJztcclxuXHJcbmNvbnN0IFBsYWNlID0gKHsgcGxhY2UsIGlzU2VsZWN0ZWQsIGlzRHJhZ2dpbmcsIG9uQ2xpY2ssIG9uRHJhZ1N0YXJ0LCBvbkRyYWdNb3ZlLCBvbkRyYWdFbmQgfSkgPT4ge1xyXG4gIGNvbnN0IHJhZGl1cyA9IDIwO1xyXG4gIFxyXG4gIC8vIFZpc3VhbCBpbmRpY2F0b3JzIGZvciBncmlkIHNuYXBwaW5nXHJcbiAgY29uc3QgcmVuZGVyU25hcEluZGljYXRvcnMgPSAoKSA9PiB7XHJcbiAgICBpZiAoIWlzRHJhZ2dpbmcpIHJldHVybiBudWxsO1xyXG4gICAgXHJcbiAgICBjb25zdCBpbmRpY2F0b3JMZW5ndGggPSAxMDtcclxuICAgIGNvbnN0IGluZGljYXRvckNvbG9yID0gJ3JnYmEoMCwgMTUwLCAyNTUsIDAuNyknO1xyXG4gICAgY29uc3QgaW5kaWNhdG9yV2lkdGggPSAxO1xyXG4gICAgXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8PlxyXG4gICAgICAgIHsvKiBIb3Jpem9udGFsIGluZGljYXRvciAqL31cclxuICAgICAgICA8TGluZVxyXG4gICAgICAgICAgcG9pbnRzPXtbLXJhZGl1cyAtIGluZGljYXRvckxlbmd0aCwgMCwgcmFkaXVzICsgaW5kaWNhdG9yTGVuZ3RoLCAwXX1cclxuICAgICAgICAgIHN0cm9rZT17aW5kaWNhdG9yQ29sb3J9XHJcbiAgICAgICAgICBzdHJva2VXaWR0aD17aW5kaWNhdG9yV2lkdGh9XHJcbiAgICAgICAgICBkYXNoPXtbNCwgMl19XHJcbiAgICAgICAgLz5cclxuICAgICAgICB7LyogVmVydGljYWwgaW5kaWNhdG9yICovfVxyXG4gICAgICAgIDxMaW5lXHJcbiAgICAgICAgICBwb2ludHM9e1swLCAtcmFkaXVzIC0gaW5kaWNhdG9yTGVuZ3RoLCAwLCByYWRpdXMgKyBpbmRpY2F0b3JMZW5ndGhdfVxyXG4gICAgICAgICAgc3Ryb2tlPXtpbmRpY2F0b3JDb2xvcn1cclxuICAgICAgICAgIHN0cm9rZVdpZHRoPXtpbmRpY2F0b3JXaWR0aH1cclxuICAgICAgICAgIGRhc2g9e1s0LCAyXX1cclxuICAgICAgICAvPlxyXG4gICAgICA8Lz5cclxuICAgICk7XHJcbiAgfTtcclxuICBcclxuICByZXR1cm4gKFxyXG4gICAgPEdyb3VwXHJcbiAgICAgIHg9e3BsYWNlLnh9XHJcbiAgICAgIHk9e3BsYWNlLnl9XHJcbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XHJcbiAgICAgIGRyYWdnYWJsZT17dHJ1ZX1cclxuICAgICAgb25EcmFnU3RhcnQ9e29uRHJhZ1N0YXJ0fVxyXG4gICAgICBvbkRyYWdNb3ZlPXtvbkRyYWdNb3ZlfVxyXG4gICAgICBvbkRyYWdFbmQ9e29uRHJhZ0VuZH1cclxuICAgID5cclxuICAgICAgey8qIEdyaWQgc25hcCBpbmRpY2F0b3JzICovfVxyXG4gICAgICB7cmVuZGVyU25hcEluZGljYXRvcnMoKX1cclxuICAgICAgXHJcbiAgICAgIHsvKiBQbGFjZSBjaXJjbGUgKi99XHJcbiAgICAgIDxDaXJjbGVcclxuICAgICAgICByYWRpdXM9e3JhZGl1c31cclxuICAgICAgICBmaWxsPVwid2hpdGVcIlxyXG4gICAgICAgIHN0cm9rZT17aXNTZWxlY3RlZCA/ICdibHVlJyA6IChpc0RyYWdnaW5nID8gJ3JnYmEoMCwgMTUwLCAyNTUsIDAuNyknIDogJ2JsYWNrJyl9XHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9e2lzU2VsZWN0ZWQgfHwgaXNEcmFnZ2luZyA/IDIgOiAxfVxyXG4gICAgICAvPlxyXG4gICAgICBcclxuICAgICAgey8qIFBsYWNlIG5hbWUgKi99XHJcbiAgICAgIDxUZXh0XHJcbiAgICAgICAgdGV4dD17cGxhY2UubmFtZX1cclxuICAgICAgICBmb250U2l6ZT17MTJ9XHJcbiAgICAgICAgZmlsbD1cImJsYWNrXCJcclxuICAgICAgICB4PXstcmFkaXVzfVxyXG4gICAgICAgIHk9e3JhZGl1cyArIDV9XHJcbiAgICAgICAgd2lkdGg9e3JhZGl1cyAqIDJ9XHJcbiAgICAgICAgYWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAvPlxyXG4gICAgICBcclxuICAgICAgey8qIFRva2VuIGNvdW50ICovfVxyXG4gICAgICA8VGV4dFxyXG4gICAgICAgIHRleHQ9e3BsYWNlLnRva2Vucy50b1N0cmluZygpfVxyXG4gICAgICAgIGZvbnRTaXplPXsxNH1cclxuICAgICAgICBmaWxsPVwiYmxhY2tcIlxyXG4gICAgICAgIHg9ey1yYWRpdXN9XHJcbiAgICAgICAgeT17LTd9XHJcbiAgICAgICAgd2lkdGg9e3JhZGl1cyAqIDJ9XHJcbiAgICAgICAgYWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAvPlxyXG4gICAgICBcclxuICAgICAgey8qIFJlbmRlciB0b2tlbnMgdmlzdWFsbHkgaWYgdGhlcmUgYXJlIGFueSAqL31cclxuICAgICAge3BsYWNlLnRva2VucyA+IDAgJiYgcGxhY2UudG9rZW5zIDw9IDUgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogcGxhY2UudG9rZW5zIH0pLm1hcCgoXywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgLy8gUG9zaXRpb24gdG9rZW5zIGluIGEgY2lyY2xlIG9yIGdyaWQgcGF0dGVyblxyXG4gICAgICAgICAgICBjb25zdCBhbmdsZSA9ICgyICogTWF0aC5QSSAqIGluZGV4KSAvIHBsYWNlLnRva2VucztcclxuICAgICAgICAgICAgY29uc3QgdG9rZW5SYWRpdXMgPSA0O1xyXG4gICAgICAgICAgICBjb25zdCBkaXN0YW5jZSA9IHJhZGl1cyAvIDI7XHJcbiAgICAgICAgICAgIGNvbnN0IHRva2VuWCA9IE1hdGguY29zKGFuZ2xlKSAqIGRpc3RhbmNlO1xyXG4gICAgICAgICAgICBjb25zdCB0b2tlblkgPSBNYXRoLnNpbihhbmdsZSkgKiBkaXN0YW5jZTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPENpcmNsZVxyXG4gICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgIHg9e3Rva2VuWH1cclxuICAgICAgICAgICAgICAgIHk9e3Rva2VuWX1cclxuICAgICAgICAgICAgICAgIHJhZGl1cz17dG9rZW5SYWRpdXN9XHJcbiAgICAgICAgICAgICAgICBmaWxsPVwiYmxhY2tcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgICAgXHJcbiAgICAgIHsvKiBGb3IgbW9yZSB0aGFuIDUgdG9rZW5zLCBqdXN0IHNob3cgdGhlIG51bWJlciAqL31cclxuICAgICAge3BsYWNlLnRva2VucyA+IDUgJiYgKFxyXG4gICAgICAgIDxUZXh0XHJcbiAgICAgICAgICB0ZXh0PXtwbGFjZS50b2tlbnMudG9TdHJpbmcoKX1cclxuICAgICAgICAgIGZvbnRTaXplPXsxNn1cclxuICAgICAgICAgIGZvbnRTdHlsZT1cImJvbGRcIlxyXG4gICAgICAgICAgZmlsbD1cImJsYWNrXCJcclxuICAgICAgICAgIHg9ey1yYWRpdXN9XHJcbiAgICAgICAgICB5PXstOX1cclxuICAgICAgICAgIHdpZHRoPXtyYWRpdXMgKiAyfVxyXG4gICAgICAgICAgYWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L0dyb3VwPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQbGFjZTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9MZXZpL0Nhc2NhZGVQcm9qZWN0cy9wZXRyaS1uZXQtZWRpdG9yL3BldHJpLW5ldC1hcHAvc3JjL2NvbXBvbmVudHMvUGxhY2UuanN4In0=