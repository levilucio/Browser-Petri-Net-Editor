import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PropertiesPanel.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e926b2f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4e926b2f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
const PropertiesPanel = ({ selectedElement, setElements }) => {
  if (!selectedElement) {
    return /* @__PURE__ */ jsxDEV("div", { className: "properties-panel w-64 p-4 bg-gray-50 border-l border-gray-300 overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold mb-4", children: "Properties" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "Select an element to edit its properties" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this);
  }
  const handleNameChange = (e) => {
    const newName = e.target.value;
    if (selectedElement.id.startsWith("place")) {
      setElements((prev) => ({
        ...prev,
        places: prev.places.map(
          (place) => place.id === selectedElement.id ? { ...place, name: newName } : place
        )
      }));
    } else if (selectedElement.id.startsWith("transition")) {
      setElements((prev) => ({
        ...prev,
        transitions: prev.transitions.map(
          (transition) => transition.id === selectedElement.id ? { ...transition, name: newName } : transition
        )
      }));
    } else if (selectedElement.id.startsWith("arc")) {
      setElements((prev) => ({
        ...prev,
        arcs: prev.arcs.map(
          (arc) => arc.id === selectedElement.id ? { ...arc, name: newName } : arc
        )
      }));
    }
  };
  const handleTokensChange = (e) => {
    if (!selectedElement.id.startsWith("place"))
      return;
    const tokens = parseInt(e.target.value) || 0;
    const validTokens = Math.min(Math.max(tokens, 0), 20);
    setElements((prev) => ({
      ...prev,
      places: prev.places.map(
        (place) => place.id === selectedElement.id ? { ...place, tokens: validTokens } : place
      )
    }));
  };
  const handleWeightChange = (e) => {
    if (!selectedElement.id.startsWith("arc"))
      return;
    const weight = parseInt(e.target.value) || 1;
    const validWeight = Math.max(weight, 1);
    setElements((prev) => ({
      ...prev,
      arcs: prev.arcs.map(
        (arc) => arc.id === selectedElement.id ? { ...arc, weight: validWeight } : arc
      )
    }));
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "properties-panel w-64 p-4 bg-gray-50 border-l border-gray-300 overflow-y-auto", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold mb-4", children: "Properties" }, void 0, false, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Name" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 94,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: selectedElement.name || "",
          onChange: handleNameChange,
          className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
          lineNumber: 97,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
      lineNumber: 93,
      columnNumber: 7
    }, this),
    selectedElement.id.startsWith("place") && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Tokens (0-20)" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 107,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "number",
          min: "0",
          max: "20",
          value: selectedElement.tokens || 0,
          onChange: handleTokensChange,
          className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
          lineNumber: 110,
          columnNumber: 11
        },
        this
      ),
      selectedElement.tokens > 20 && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: "Token count exceeds 20" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 119,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
      lineNumber: 106,
      columnNumber: 7
    }, this),
    selectedElement.id.startsWith("arc") && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Weight (≥ 1)" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 126,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "number",
          min: "1",
          value: selectedElement.weight || 1,
          onChange: handleWeightChange,
          className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
          lineNumber: 129,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
      lineNumber: 125,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Position" }, void 0, false, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 140,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-gray-500", children: "X" }, void 0, false, {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
            lineNumber: 145,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              value: selectedElement.x || 0,
              disabled: true,
              className: "w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-md shadow-sm"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
              lineNumber: 146,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
          lineNumber: 144,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-gray-500", children: "Y" }, void 0, false, {
            fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
            lineNumber: 154,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              value: selectedElement.y || 0,
              disabled: true,
              className: "w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-md shadow-sm"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
              lineNumber: 155,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
          lineNumber: 153,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
        lineNumber: 143,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
      lineNumber: 139,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx",
    lineNumber: 90,
    columnNumber: 5
  }, this);
};
_c = PropertiesPanel;
export default PropertiesPanel;
var _c;
$RefreshReg$(_c, "PropertiesPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Levi/CascadeProjects/petri-net-editor/petri-net-app/src/components/PropertiesPanel.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFOUixPQUFPQSxXQUFXO0FBRWxCLE1BQU1DLGtCQUFrQkEsQ0FBQyxFQUFFQyxpQkFBaUJDLFlBQVksTUFBTTtBQUM1RCxNQUFJLENBQUNELGlCQUFpQjtBQUNwQixXQUNFLHVCQUFDLFNBQUksV0FBVSxpRkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSw4QkFBNkIsMEJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxNQUNyRCx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLHdEQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsU0FGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUVBLFFBQU1FLG1CQUFtQkEsQ0FBQ0MsTUFBTTtBQUM5QixVQUFNQyxVQUFVRCxFQUFFRSxPQUFPQztBQUV6QixRQUFJTixnQkFBZ0JPLEdBQUdDLFdBQVcsT0FBTyxHQUFHO0FBQzFDUCxrQkFBWSxDQUFBUSxVQUFTO0FBQUEsUUFDbkIsR0FBR0E7QUFBQUEsUUFDSEMsUUFBUUQsS0FBS0MsT0FBT0M7QUFBQUEsVUFBSSxDQUFBQyxVQUN0QkEsTUFBTUwsT0FBT1AsZ0JBQWdCTyxLQUFLLEVBQUUsR0FBR0ssT0FBT0MsTUFBTVQsUUFBUSxJQUFJUTtBQUFBQSxRQUNsRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0osV0FBV1osZ0JBQWdCTyxHQUFHQyxXQUFXLFlBQVksR0FBRztBQUN0RFAsa0JBQVksQ0FBQVEsVUFBUztBQUFBLFFBQ25CLEdBQUdBO0FBQUFBLFFBQ0hLLGFBQWFMLEtBQUtLLFlBQVlIO0FBQUFBLFVBQUksQ0FBQUksZUFDaENBLFdBQVdSLE9BQU9QLGdCQUFnQk8sS0FBSyxFQUFFLEdBQUdRLFlBQVlGLE1BQU1ULFFBQVEsSUFBSVc7QUFBQUEsUUFDNUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKLFdBQVdmLGdCQUFnQk8sR0FBR0MsV0FBVyxLQUFLLEdBQUc7QUFDL0NQLGtCQUFZLENBQUFRLFVBQVM7QUFBQSxRQUNuQixHQUFHQTtBQUFBQSxRQUNITyxNQUFNUCxLQUFLTyxLQUFLTDtBQUFBQSxVQUFJLENBQUFNLFFBQ2xCQSxJQUFJVixPQUFPUCxnQkFBZ0JPLEtBQUssRUFBRSxHQUFHVSxLQUFLSixNQUFNVCxRQUFRLElBQUlhO0FBQUFBLFFBQzlEO0FBQUEsTUFDRixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxxQkFBcUJBLENBQUNmLE1BQU07QUFDaEMsUUFBSSxDQUFDSCxnQkFBZ0JPLEdBQUdDLFdBQVcsT0FBTztBQUFHO0FBRTdDLFVBQU1XLFNBQVNDLFNBQVNqQixFQUFFRSxPQUFPQyxLQUFLLEtBQUs7QUFFM0MsVUFBTWUsY0FBY0MsS0FBS0MsSUFBSUQsS0FBS0UsSUFBSUwsUUFBUSxDQUFDLEdBQUcsRUFBRTtBQUVwRGxCLGdCQUFZLENBQUFRLFVBQVM7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNIQyxRQUFRRCxLQUFLQyxPQUFPQztBQUFBQSxRQUFJLENBQUFDLFVBQ3RCQSxNQUFNTCxPQUFPUCxnQkFBZ0JPLEtBQUssRUFBRSxHQUFHSyxPQUFPTyxRQUFRRSxZQUFZLElBQUlUO0FBQUFBLE1BQ3hFO0FBQUEsSUFDRixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1hLHFCQUFxQkEsQ0FBQ3RCLE1BQU07QUFDaEMsUUFBSSxDQUFDSCxnQkFBZ0JPLEdBQUdDLFdBQVcsS0FBSztBQUFHO0FBRTNDLFVBQU1rQixTQUFTTixTQUFTakIsRUFBRUUsT0FBT0MsS0FBSyxLQUFLO0FBRTNDLFVBQU1xQixjQUFjTCxLQUFLRSxJQUFJRSxRQUFRLENBQUM7QUFFdEN6QixnQkFBWSxDQUFBUSxVQUFTO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSE8sTUFBTVAsS0FBS08sS0FBS0w7QUFBQUEsUUFBSSxDQUFBTSxRQUNsQkEsSUFBSVYsT0FBT1AsZ0JBQWdCTyxLQUFLLEVBQUUsR0FBR1UsS0FBS1MsUUFBUUMsWUFBWSxJQUFJVjtBQUFBQSxNQUNwRTtBQUFBLElBQ0YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxpRkFDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSw4QkFBNkIsMEJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUQ7QUFBQSxJQUVyRCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLFdBQU0sV0FBVSxnREFBK0Msb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9qQixnQkFBZ0JhLFFBQVE7QUFBQSxVQUMvQixVQUFVWDtBQUFBQSxVQUNWLFdBQVU7QUFBQTtBQUFBLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXVJO0FBQUEsU0FSekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQ0YsZ0JBQWdCTyxHQUFHQyxXQUFXLE9BQU8sS0FDcEMsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxLQUFJO0FBQUEsVUFDSixLQUFJO0FBQUEsVUFDSixPQUFPUixnQkFBZ0JtQixVQUFVO0FBQUEsVUFDakMsVUFBVUQ7QUFBQUEsVUFDVixXQUFVO0FBQUE7QUFBQSxRQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU11STtBQUFBLE1BRXRJbEIsZ0JBQWdCbUIsU0FBUyxNQUN4Qix1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLHNDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsU0FibkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFHRG5CLGdCQUFnQk8sR0FBR0MsV0FBVyxLQUFLLEtBQ2xDLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsS0FBSTtBQUFBLFVBQ0osT0FBT1IsZ0JBQWdCMEIsVUFBVTtBQUFBLFVBQ2pDLFVBQVVEO0FBQUFBLFVBQ1YsV0FBVTtBQUFBO0FBQUEsUUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLdUk7QUFBQSxTQVR6STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUdGLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLCtCQUE4QixpQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT3pCLGdCQUFnQjRCLEtBQUs7QUFBQSxjQUM1QjtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJc0Y7QUFBQSxhQU54RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsK0JBQThCLGlCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ2hEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPNUIsZ0JBQWdCNkIsS0FBSztBQUFBLGNBQzVCO0FBQUEsY0FDQSxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlzRjtBQUFBLGFBTnhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsT0F6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBFQTtBQUVKO0FBQUVDLEtBaEpJL0I7QUFrSk4sZUFBZUE7QUFBZ0IsSUFBQStCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlByb3BlcnRpZXNQYW5lbCIsInNlbGVjdGVkRWxlbWVudCIsInNldEVsZW1lbnRzIiwiaGFuZGxlTmFtZUNoYW5nZSIsImUiLCJuZXdOYW1lIiwidGFyZ2V0IiwidmFsdWUiLCJpZCIsInN0YXJ0c1dpdGgiLCJwcmV2IiwicGxhY2VzIiwibWFwIiwicGxhY2UiLCJuYW1lIiwidHJhbnNpdGlvbnMiLCJ0cmFuc2l0aW9uIiwiYXJjcyIsImFyYyIsImhhbmRsZVRva2Vuc0NoYW5nZSIsInRva2VucyIsInBhcnNlSW50IiwidmFsaWRUb2tlbnMiLCJNYXRoIiwibWluIiwibWF4IiwiaGFuZGxlV2VpZ2h0Q2hhbmdlIiwid2VpZ2h0IiwidmFsaWRXZWlnaHQiLCJ4IiwieSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvcGVydGllc1BhbmVsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuY29uc3QgUHJvcGVydGllc1BhbmVsID0gKHsgc2VsZWN0ZWRFbGVtZW50LCBzZXRFbGVtZW50cyB9KSA9PiB7XHJcbiAgaWYgKCFzZWxlY3RlZEVsZW1lbnQpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvcGVydGllcy1wYW5lbCB3LTY0IHAtNCBiZy1ncmF5LTUwIGJvcmRlci1sIGJvcmRlci1ncmF5LTMwMCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIG1iLTRcIj5Qcm9wZXJ0aWVzPC9oMj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+U2VsZWN0IGFuIGVsZW1lbnQgdG8gZWRpdCBpdHMgcHJvcGVydGllczwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlTmFtZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdOYW1lID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBcclxuICAgIGlmIChzZWxlY3RlZEVsZW1lbnQuaWQuc3RhcnRzV2l0aCgncGxhY2UnKSkge1xyXG4gICAgICBzZXRFbGVtZW50cyhwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBwbGFjZXM6IHByZXYucGxhY2VzLm1hcChwbGFjZSA9PiBcclxuICAgICAgICAgIHBsYWNlLmlkID09PSBzZWxlY3RlZEVsZW1lbnQuaWQgPyB7IC4uLnBsYWNlLCBuYW1lOiBuZXdOYW1lIH0gOiBwbGFjZVxyXG4gICAgICAgIClcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIGlmIChzZWxlY3RlZEVsZW1lbnQuaWQuc3RhcnRzV2l0aCgndHJhbnNpdGlvbicpKSB7XHJcbiAgICAgIHNldEVsZW1lbnRzKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRyYW5zaXRpb25zOiBwcmV2LnRyYW5zaXRpb25zLm1hcCh0cmFuc2l0aW9uID0+IFxyXG4gICAgICAgICAgdHJhbnNpdGlvbi5pZCA9PT0gc2VsZWN0ZWRFbGVtZW50LmlkID8geyAuLi50cmFuc2l0aW9uLCBuYW1lOiBuZXdOYW1lIH0gOiB0cmFuc2l0aW9uXHJcbiAgICAgICAgKVxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2UgaWYgKHNlbGVjdGVkRWxlbWVudC5pZC5zdGFydHNXaXRoKCdhcmMnKSkge1xyXG4gICAgICBzZXRFbGVtZW50cyhwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBhcmNzOiBwcmV2LmFyY3MubWFwKGFyYyA9PiBcclxuICAgICAgICAgIGFyYy5pZCA9PT0gc2VsZWN0ZWRFbGVtZW50LmlkID8geyAuLi5hcmMsIG5hbWU6IG5ld05hbWUgfSA6IGFyY1xyXG4gICAgICAgIClcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRva2Vuc0NoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRWxlbWVudC5pZC5zdGFydHNXaXRoKCdwbGFjZScpKSByZXR1cm47XHJcbiAgICBcclxuICAgIGNvbnN0IHRva2VucyA9IHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSB8fCAwO1xyXG4gICAgLy8gVmFsaWRhdGUgdG9rZW4gY291bnQgKDAtMjApXHJcbiAgICBjb25zdCB2YWxpZFRva2VucyA9IE1hdGgubWluKE1hdGgubWF4KHRva2VucywgMCksIDIwKTtcclxuICAgIFxyXG4gICAgc2V0RWxlbWVudHMocHJldiA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBwbGFjZXM6IHByZXYucGxhY2VzLm1hcChwbGFjZSA9PiBcclxuICAgICAgICBwbGFjZS5pZCA9PT0gc2VsZWN0ZWRFbGVtZW50LmlkID8geyAuLi5wbGFjZSwgdG9rZW5zOiB2YWxpZFRva2VucyB9IDogcGxhY2VcclxuICAgICAgKVxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVdlaWdodENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRWxlbWVudC5pZC5zdGFydHNXaXRoKCdhcmMnKSkgcmV0dXJuO1xyXG4gICAgXHJcbiAgICBjb25zdCB3ZWlnaHQgPSBwYXJzZUludChlLnRhcmdldC52YWx1ZSkgfHwgMTtcclxuICAgIC8vIFZhbGlkYXRlIHdlaWdodCAo4omlIDEpXHJcbiAgICBjb25zdCB2YWxpZFdlaWdodCA9IE1hdGgubWF4KHdlaWdodCwgMSk7XHJcbiAgICBcclxuICAgIHNldEVsZW1lbnRzKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgYXJjczogcHJldi5hcmNzLm1hcChhcmMgPT4gXHJcbiAgICAgICAgYXJjLmlkID09PSBzZWxlY3RlZEVsZW1lbnQuaWQgPyB7IC4uLmFyYywgd2VpZ2h0OiB2YWxpZFdlaWdodCB9IDogYXJjXHJcbiAgICAgIClcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcm9wZXJ0aWVzLXBhbmVsIHctNjQgcC00IGJnLWdyYXktNTAgYm9yZGVyLWwgYm9yZGVyLWdyYXktMzAwIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIG1iLTRcIj5Qcm9wZXJ0aWVzPC9oMj5cclxuICAgICAgXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgTmFtZVxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbGVtZW50Lm5hbWUgfHwgJyd9XHJcbiAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlTmFtZUNoYW5nZX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge3NlbGVjdGVkRWxlbWVudC5pZC5zdGFydHNXaXRoKCdwbGFjZScpICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICBUb2tlbnMgKDAtMjApXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgbWF4PVwiMjBcIlxyXG4gICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbGVtZW50LnRva2VucyB8fCAwfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVG9rZW5zQ2hhbmdlfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7c2VsZWN0ZWRFbGVtZW50LnRva2VucyA+IDIwICYmIChcclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlRva2VuIGNvdW50IGV4Y2VlZHMgMjA8L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3NlbGVjdGVkRWxlbWVudC5pZC5zdGFydHNXaXRoKCdhcmMnKSAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgV2VpZ2h0ICjiiaUgMSlcclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgIG1pbj1cIjFcIlxyXG4gICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbGVtZW50LndlaWdodCB8fCAxfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlV2VpZ2h0Q2hhbmdlfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgIFBvc2l0aW9uXHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5YPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRWxlbWVudC54IHx8IDB9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+WTwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVsZW1lbnQueSB8fCAwfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1ncmF5LTEwMCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9wZXJ0aWVzUGFuZWw7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvTGV2aS9DYXNjYWRlUHJvamVjdHMvcGV0cmktbmV0LWVkaXRvci9wZXRyaS1uZXQtYXBwL3NyYy9jb21wb25lbnRzL1Byb3BlcnRpZXNQYW5lbC5qc3gifQ==