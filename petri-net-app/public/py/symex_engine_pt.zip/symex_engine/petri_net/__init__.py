"""
Petri net instantiation(s) of the symbolic-execution kernel.

Currently includes a Place/Transition (P/T) net explorer that:
- parses a PNML P/T net subset (as produced by Browser-Petri-Net-Editor),
- optionally parses embedded tool-specific properties,
- explores the reachability graph and reports witnesses.
"""

