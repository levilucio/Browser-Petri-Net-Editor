"""
Partial-Order Reduction for P/T Nets

Implements Confluence Modulo Constraints (Section 11 of main.tex) for
reducing state space explosion due to interleaving non-determinism.

For P/T nets, the read/write sets are determined by the pre/post arcs:
  - Read(t): Places in pre-set (tokens consumed)
  - Write(t): Places in pre-set ∪ post-set (tokens consumed or produced)

This module uses the common POR abstractions from core/por.py and
provides P/T net-specific implementations.

Key insight for P/T nets:
  Two transitions t₁ and t₂ are independent if their pre/post sets
  don't overlap (no structural conflict). This is a purely static
  analysis based on the net structure.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property

from .pt_model import PTNet, Marking, enabled
from .pt_properties import PropertySpec, Predicate, Expr
from ..core.por import (
    ActionFootprint as BaseFootprint,
    AmpleSetResult,
    PORStats,
    compute_ample_set as base_compute_ample_set,
)


# =============================================================================
# Action Footprint for P/T Net Transitions
# =============================================================================

# Use place indices as resource identifiers
ActionFootprint = BaseFootprint[int]


def compute_transition_footprint(net: PTNet, t_idx: int) -> ActionFootprint:
    """
    Compute the footprint of a transition.
    
    For P/T nets:
      - reads: Pre-set places (tokens are checked and consumed)
      - writes: Pre-set ∪ Post-set places (tokens consumed or produced)
      - guard_reads: Same as reads (enablement depends on pre-set)
    """
    pre_places = frozenset(net.pre[t_idx].keys())
    post_places = frozenset(net.post[t_idx].keys())
    
    return ActionFootprint(
        reads=pre_places,
        writes=pre_places | post_places,  # Both consume and produce modify places
        guard_reads=pre_places,  # Enablement depends on pre-set
        action_id=t_idx,
    )


@dataclass
class PTNetFootprints:
    """Pre-computed footprints for all transitions in a P/T net."""
    net: PTNet
    footprints: tuple[ActionFootprint, ...]
    
    @classmethod
    def from_net(cls, net: PTNet) -> PTNetFootprints:
        """Compute all transition footprints once at exploration start."""
        fps = tuple(
            compute_transition_footprint(net, t_idx)
            for t_idx in range(len(net.transitions))
        )
        return cls(net=net, footprints=fps)
    
    def get_enabled_footprints(self, m: Marking) -> list[tuple[int, ActionFootprint]]:
        """Get footprints for enabled transitions at marking m."""
        result: list[tuple[int, ActionFootprint]] = []
        for t_idx, fp in enumerate(self.footprints):
            if enabled(self.net, m, t_idx):
                result.append((t_idx, fp))
        return result


# =============================================================================
# Visibility Analysis for P/T Net Properties
# =============================================================================

def places_in_predicate(pred: Predicate) -> frozenset[int]:
    """Extract all place indices mentioned in a predicate."""
    # This would require access to the net for place index lookup
    # For now, we collect place IDs as strings and convert later
    raise NotImplementedError("Use extract_visible_places_from_props instead")


def _places_in_expr(net: PTNet, expr: Expr) -> set[int]:
    """Extract place indices from an expression."""
    result: set[int] = set()
    if expr.op == "place" and expr.place is not None:
        if expr.place in net.place_index:
            result.add(net.place_index[expr.place])
    elif expr.op == "sum":
        for pid in expr.places:
            if pid in net.place_index:
                result.add(net.place_index[pid])
    elif expr.op == "lin":
        for _, pid in expr.terms:
            if pid in net.place_index:
                result.add(net.place_index[pid])
    return result


def _places_in_predicate(net: PTNet, pred: Predicate) -> set[int]:
    """Extract place indices from a predicate."""
    result: set[int] = set()
    if pred.lhs is not None:
        result |= _places_in_expr(net, pred.lhs)
    if pred.rhs is not None:
        result |= _places_in_expr(net, pred.rhs)
    for arg in pred.args:
        result |= _places_in_predicate(net, arg)
    return result


def extract_visible_places(
    net: PTNet,
    props: tuple[PropertySpec, ...],
) -> frozenset[int]:
    """
    Extract all place indices mentioned in property specifications.
    
    These places are "visible" - transitions modifying them cannot be
    reduced by POR when checking existential properties.
    """
    result: set[int] = set()
    for prop in props:
        if prop.predicate is not None:
            result |= _places_in_predicate(net, prop.predicate)
    return frozenset(result)


# =============================================================================
# Ample Set Computation for P/T Nets
# =============================================================================

def compute_ample_set(
    footprints: PTNetFootprints,
    m: Marking,
    *,
    visible_places: frozenset[int] = frozenset(),
) -> tuple[list[int], AmpleSetResult]:
    """
    Compute an ample set of transitions to fire from marking m.
    
    Args:
        footprints: Pre-computed transition footprints
        m: Current marking
        visible_places: Places mentioned in properties (for visibility)
    
    Returns:
        (transition_indices, result): List of transitions in the ample set
                                      and the ample set computation result
    """
    enabled_pairs = footprints.get_enabled_footprints(m)
    
    if not enabled_pairs:
        return [], AmpleSetResult(frozenset(), True, "no enabled transitions")
    
    # Extract just the footprints for the ample set computation
    enabled_fps = [fp for _, fp in enabled_pairs]
    
    # Compute ample set using common algorithm
    result = base_compute_ample_set(enabled_fps, visible_resources=visible_places)
    
    # Map ample indices back to transition indices
    ample_transitions = [
        enabled_pairs[i][0]  # Get the t_idx from the (t_idx, fp) pair
        for i in result.ample_indices
    ]
    
    return ample_transitions, result


# =============================================================================
# Independence Analysis - Static (Structure-Based)
# =============================================================================

def are_structurally_independent(net: PTNet, t1_idx: int, t2_idx: int) -> bool:
    """
    Check if two transitions are structurally independent.
    
    Two transitions are structurally independent if their pre/post sets
    are disjoint. This is a sufficient condition for independence.
    """
    # Get places involved in t1
    t1_pre = set(net.pre[t1_idx].keys())
    t1_post = set(net.post[t1_idx].keys())
    t1_places = t1_pre | t1_post
    
    # Get places involved in t2
    t2_pre = set(net.pre[t2_idx].keys())
    t2_post = set(net.post[t2_idx].keys())
    t2_places = t2_pre | t2_post
    
    # Independent if disjoint
    return t1_places.isdisjoint(t2_places)


class IndependenceMatrix:
    """
    Pre-computed independence relation for all transition pairs.
    
    This is a static analysis based on net structure only.
    """
    
    def __init__(self, net: PTNet):
        self.net = net
        n = len(net.transitions)
        # independence[i][j] = True iff transitions i and j are independent
        self._matrix: list[list[bool]] = [
            [False] * n for _ in range(n)
        ]
        # Compute independence for all pairs
        for i in range(n):
            self._matrix[i][i] = False  # A transition is not independent of itself
            for j in range(i + 1, n):
                indep = are_structurally_independent(net, i, j)
                self._matrix[i][j] = indep
                self._matrix[j][i] = indep
    
    def are_independent(self, t1_idx: int, t2_idx: int) -> bool:
        """Check if two transitions are independent (O(1) lookup)."""
        return self._matrix[t1_idx][t2_idx]
    
    def get_dependent_transitions(self, t_idx: int) -> frozenset[int]:
        """Get all transitions that are dependent on (conflict with) t_idx."""
        n = len(self.net.transitions)
        return frozenset(
            i for i in range(n)
            if i != t_idx and not self._matrix[t_idx][i]
        )
