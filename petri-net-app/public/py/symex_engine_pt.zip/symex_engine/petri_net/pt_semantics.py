"""
Place/Transition Net Semantics - Kernel Transition Rules

This module defines the small-step transition relation for P/T nets,
corresponding to the kernel's symbolic transition concept.

Kernel mapping:
  - successors(): Implements the kernel's Succ function
    σ' ∈ Succ(σ) iff transition t is enabled at marking σ and σ' = fire(t, σ)
  - is_deadlock(): Checks for terminal states (no enabled transitions)

The transitions are concrete (no symbolic branching or constraint splitting)
because P/T net semantics are deterministic given a chosen transition.
"""
from __future__ import annotations

from collections.abc import Iterable

from .pt_model import Marking, PTNet, enabled, fire


def successors(net: PTNet, m: Marking) -> Iterable[tuple[int, Marking]]:
    """
    Yield (t_idx, successor_marking) pairs in deterministic order.
    """
    # Avoid allocating an intermediate list/tuple of enabled transitions:
    # this is a hot path for large graphs.
    n = len(net.transitions)
    for t_idx in range(n):
        if enabled(net, m, t_idx):
            yield t_idx, fire(net, m, t_idx)


def is_deadlock(net: PTNet, m: Marking) -> bool:
    # Early-exit scan; avoids allocating enabled_transitions tuple.
    n = len(net.transitions)
    for t_idx in range(n):
        if enabled(net, m, t_idx):
            return False
    return True

