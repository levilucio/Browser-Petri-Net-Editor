from __future__ import annotations

from dataclasses import dataclass, field

from symex_engine.core.render import render_dot

from .pt_model import Marking, PTNet, pretty_marking


@dataclass(frozen=True, slots=True)
class PTNode:
    id: int
    marking: Marking


EDGE_FLAG_KM_ACCEL = 1 << 0
EDGE_FLAG_SUBSUMED = 1 << 1


PTPackedEdge = tuple[int, int, int, int]  # (src, dst, t_idx, flags)


@dataclass
class PTExecGraph:
    net: PTNet
    nodes: dict[int, PTNode] = field(default_factory=dict)
    edges: list[PTPackedEdge] = field(default_factory=list)

    def edge_label(self, e: PTPackedEdge) -> str:
        src, dst, t_idx, flags = e
        _ = src, dst  # unused for label; keep tuple format explicit
        base = f"fire({self.net.transitions[t_idx].name})"
        if flags & EDGE_FLAG_KM_ACCEL:
            base += "; km_accel"
        if flags & EDGE_FLAG_SUBSUMED:
            base += " (subsumed)"
        return base

    def to_dot(self) -> str:
        return render_dot(
            self.nodes.keys(),
            ((edge[0], edge[1], edge) for edge in self.edges),
            lambda node_id: f"{node_id}: {pretty_marking(self.net, self.nodes[node_id].marking)}",
            self.edge_label,
            node_shape_fn=lambda _node_id: "box",
        )

