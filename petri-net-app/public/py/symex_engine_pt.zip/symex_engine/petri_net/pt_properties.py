from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .pt_model import PlaceId, PTNet, TokenCount, tc, TC_OMEGA


ExprOp = Literal["const", "place", "sum", "lin"]
CmpOp = Literal["<=", ">=", "=="]
BoolOp = Literal["and", "or", "not"]


@dataclass(frozen=True)
class Expr:
    op: ExprOp
    k: int | None = None
    place: PlaceId | None = None
    places: tuple[PlaceId, ...] = ()
    terms: tuple[tuple[int, PlaceId], ...] = ()  # (coeff, place)

    def eval(self, net: PTNet, m: tuple[TokenCount, ...]) -> TokenCount:
        if self.op == "const":
            assert self.k is not None
            return tc(int(self.k))
        if self.op == "place":
            assert self.place is not None
            idx = net.place_index[self.place]
            return m[idx]
        if self.op == "sum":
            total: TokenCount = tc(0)
            for pid in self.places:
                v = m[net.place_index[pid]]
                if v.is_omega():
                    return TC_OMEGA
                total = total.add(v)
            return total
        if self.op == "lin":
            total: TokenCount = tc(0)
            for coeff, pid in self.terms:
                v = m[net.place_index[pid]]
                if v.is_omega():
                    return TC_OMEGA
                total = total.add(tc(coeff * v.unwrap_finite()))
            return total
        raise ValueError(f"Unknown Expr op: {self.op}")


@dataclass(frozen=True)
class Predicate:
    # Either a comparison (cmp_op) or a boolean connective (bool_op).
    cmp_op: CmpOp | None = None
    lhs: Expr | None = None
    rhs: Expr | None = None

    bool_op: BoolOp | None = None
    args: tuple["Predicate", ...] = ()

    def eval(self, net: PTNet, m: tuple[TokenCount, ...]) -> bool:
        if self.cmp_op is not None:
            assert self.lhs is not None and self.rhs is not None
            a = self.lhs.eval(net, m)
            b = self.rhs.eval(net, m)
            if self.cmp_op == "==":
                return a == b
            if self.cmp_op == ">=":
                # ω >= k is true; k >= ω is false
                if a.is_omega():
                    return True
                if b.is_omega():
                    return False
                return a.unwrap_finite() >= b.unwrap_finite()
            if self.cmp_op == "<=":
                # ω <= k is false (finite k); k <= ω is true
                if b.is_omega():
                    return True
                if a.is_omega():
                    return False
                return a.unwrap_finite() <= b.unwrap_finite()
            raise ValueError(f"Unknown cmp op: {self.cmp_op}")

        if self.bool_op is not None:
            if self.bool_op == "not":
                assert len(self.args) == 1
                return not self.args[0].eval(net, m)
            if self.bool_op == "and":
                return all(a.eval(net, m) for a in self.args)
            if self.bool_op == "or":
                return any(a.eval(net, m) for a in self.args)
            raise ValueError(f"Unknown bool op: {self.bool_op}")

        raise ValueError("Predicate must be either comparison or boolean connective")


PropertyType = Literal["invariant", "exists_coverable", "exists_deadlock"]
Severity = Literal["error", "warning"]


@dataclass(frozen=True)
class PropertySpec:
    id: str
    name: str
    type: PropertyType
    severity: Severity
    predicate: Predicate | None = None


PropertyStatus = Literal[
    # Exact-mode definitive results
    "holds",
    "violated",
    "witnessed",
    # Bounded exploration
    "unknown_truncated",
    # Over-approximate exploration (e.g., KM / WQO mode)
    "unknown_overapprox",
    "may_violated",
    "may_witnessed",
]


@dataclass
class PropertyResult:
    spec: PropertySpec
    status: PropertyStatus
    witness_node: int | None = None
    witness_marking: dict[str, str] | None = None  # place name -> token string
    witness_trace: list[str] | None = None  # transition names/ids along a path


def marking_to_name_map(net: PTNet, m: tuple[TokenCount, ...]) -> dict[str, str]:
    out: dict[str, str] = {}
    for i, p in enumerate(net.places):
        c = m[i]
        out[p.name] = str(c)
    return out

