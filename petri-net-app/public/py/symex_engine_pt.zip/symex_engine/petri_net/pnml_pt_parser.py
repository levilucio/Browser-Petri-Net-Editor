from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import xml.etree.ElementTree as ET

from .pt_model import PTNet, Place, PlaceId, Transition, TransId
from .pt_properties import Expr, Predicate, PropertySpec


@dataclass(frozen=True)
class ParsedPNML:
    net: PTNet
    properties: tuple[PropertySpec, ...]


def _strip_ns(tag: str) -> str:
    # "{ns}local" -> "local"
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _find_child_text(elem: ET.Element, path: list[str]) -> str | None:
    cur: ET.Element | None = elem
    for p in path:
        if cur is None:
            return None
        cur = next((c for c in list(cur) if _strip_ns(c.tag) == p), None)
    if cur is None:
        return None
    return (cur.text or "").strip() or None


def _parse_int_text(s: str | None, *, default: int = 0) -> int:
    if s is None:
        return default
    s2 = s.strip()
    if not s2:
        return default
    return int(s2)


def _parse_place(elem: ET.Element) -> Place:
    pid = PlaceId(elem.attrib["id"])
    name = _find_child_text(elem, ["name", "text"]) or str(pid)
    return Place(id=pid, name=name)


def _parse_transition(elem: ET.Element) -> Transition:
    tid = TransId(elem.attrib["id"])
    name = _find_child_text(elem, ["name", "text"]) or str(tid)
    return Transition(id=tid, name=name)


def _parse_arc_weight(arc: ET.Element) -> int:
    # Default inscription weight is 1
    txt = _find_child_text(arc, ["inscription", "text"])
    return _parse_int_text(txt, default=1)


def _expect_known_place(net: PTNet, pid: PlaceId) -> None:
    if pid not in net.place_index:
        raise ValueError(f"Property references unknown place id: {pid}")


def _parse_expr(net: PTNet, e: ET.Element) -> Expr:
    tag = _strip_ns(e.tag)
    if tag == "const":
        k = _parse_int_text(e.attrib.get("k"), default=0)
        return Expr(op="const", k=k)
    if tag == "placeRef":
        pid = PlaceId(e.attrib["place"])
        _expect_known_place(net, pid)
        return Expr(op="place", place=pid)
    if tag == "sum":
        places: list[PlaceId] = []
        for ch in list(e):
            if _strip_ns(ch.tag) != "placeRef":
                raise ValueError(f"sum expects <placeRef/>, got <{_strip_ns(ch.tag)}>")
            pid = PlaceId(ch.attrib["place"])
            _expect_known_place(net, pid)
            places.append(pid)
        return Expr(op="sum", places=tuple(places))
    if tag == "lin":
        terms: list[tuple[int, PlaceId]] = []
        for ch in list(e):
            if _strip_ns(ch.tag) != "term":
                raise ValueError(f"lin expects <term/>, got <{_strip_ns(ch.tag)}>")
            pid = PlaceId(ch.attrib["place"])
            _expect_known_place(net, pid)
            coeff = int(ch.attrib.get("coeff", "1"))
            terms.append((coeff, pid))
        return Expr(op="lin", terms=tuple(terms))
    raise ValueError(f"Unsupported expr tag: <{tag}>")


def _parse_predicate(net: PTNet, e: ET.Element) -> Predicate:
    tag = _strip_ns(e.tag)

    if tag in ("and", "or"):
        args = tuple(_parse_predicate(net, ch) for ch in list(e))
        return Predicate(bool_op=tag, args=args)

    if tag == "not":
        kids = list(e)
        if len(kids) != 1:
            raise ValueError("<not> expects exactly 1 child predicate")
        return Predicate(bool_op="not", args=( _parse_predicate(net, kids[0]),))

    if tag in ("ge", "le"):
        # Short form: <ge place="..." k="..."/>
        if "place" in e.attrib and "k" in e.attrib:
            pid = PlaceId(e.attrib["place"])
            _expect_known_place(net, pid)
            k = int(e.attrib["k"])
            lhs = Expr(op="place", place=pid)
            rhs = Expr(op="const", k=k)
            return Predicate(cmp_op=">=" if tag == "ge" else "<=", lhs=lhs, rhs=rhs)
        # General form: <ge> <expr/> <expr/> </ge>
        kids = list(e)
        if len(kids) != 2:
            raise ValueError(f"<{tag}> expects either (place,k) attrs or exactly 2 child exprs")
        lhs = _parse_expr(net, kids[0])
        rhs = _parse_expr(net, kids[1])
        return Predicate(cmp_op=">=" if tag == "ge" else "<=", lhs=lhs, rhs=rhs)

    if tag == "eq":
        kids = list(e)
        if len(kids) != 2:
            raise ValueError("<eq> expects exactly 2 child exprs")
        lhs = _parse_expr(net, kids[0])
        rhs = _parse_expr(net, kids[1])
        return Predicate(cmp_op="==", lhs=lhs, rhs=rhs)

    raise ValueError(f"Unsupported predicate tag: <{tag}>")


def _parse_toolspecific_properties(net: PTNet, net_elem: ET.Element) -> tuple[PropertySpec, ...]:
    props: list[PropertySpec] = []
    for ts in list(net_elem):
        if _strip_ns(ts.tag) != "toolspecific":
            continue
        tool = ts.attrib.get("tool")
        version = ts.attrib.get("version")
        if tool != "Browser-Petri-Net-Editor" or version != "1":
            continue
        props_elem = next((c for c in list(ts) if _strip_ns(c.tag) == "properties"), None)
        if props_elem is None:
            continue
        for p in list(props_elem):
            if _strip_ns(p.tag) != "property":
                continue
            pid = p.attrib.get("id") or ""
            name = p.attrib.get("name") or pid or "property"
            ptype = (p.attrib.get("type") or "").strip()
            severity = p.attrib.get("severity") or "error"
            # Property kinds:
            # - exact mode: invariant / exists_deadlock / exists_coverable (same as reachability witness)
            # - km mode: exists_coverable is the sound existential query (upward-closed)
            if ptype == "exists_reachable":
                # Backwards-compatibility: old name. We normalize to exists_coverable.
                ptype = "exists_coverable"
            if ptype not in ("invariant", "exists_coverable", "exists_deadlock"):
                raise ValueError(f"Unsupported property type: {ptype}")
            if severity not in ("error", "warning"):
                raise ValueError(f"Unsupported property severity: {severity}")
            pred: Predicate | None = None
            pred_elem = next((c for c in list(p) if _strip_ns(c.tag) == "predicate"), None)
            if ptype != "exists_deadlock":
                if pred_elem is None:
                    raise ValueError(f"Property {name} expects <predicate>...</predicate>")
                kids = [c for c in list(pred_elem)]
                if len(kids) != 1:
                    raise ValueError("<predicate> expects exactly 1 child")
                pred = _parse_predicate(net, kids[0])
            props.append(
                PropertySpec(
                    id=pid or name,
                    name=name,
                    type=ptype,  # type: ignore[arg-type]
                    severity=severity,  # type: ignore[arg-type]
                    predicate=pred,
                )
            )
    return tuple(props)


def parse_pnml_pt(path: str | Path) -> ParsedPNML:
    path = Path(path)
    root = ET.fromstring(path.read_text(encoding="utf-8"))
    if _strip_ns(root.tag) != "pnml":
        raise ValueError("Not a PNML document (root != <pnml>)")

    # PNML can use namespaces and can reset xmlns=""; we therefore search by stripped local names.
    net_elem = next((c for c in list(root) if _strip_ns(c.tag) == "net"), None)
    if net_elem is None:
        raise ValueError("PNML missing <net>")

    # Guard against accidentally parsing algebraic nets as P/T nets.
    # Browser-Petri-Net-Editor tags algebraic fixtures with netMode="algebraic-*".
    net_mode = net_elem.attrib.get("netMode", "").strip()
    if net_mode and net_mode != "pt":
        raise ValueError(f"Unsupported PNML netMode for P/T parser: {net_mode}")

    net_type = net_elem.attrib.get("type", "").strip()
    if net_type and "ptnet" not in net_type:
        raise ValueError(f"Unsupported PNML net type for P/T parser: {net_type}")

    page = next((c for c in list(net_elem) if _strip_ns(c.tag) == "page"), None)
    if page is None:
        raise ValueError("PNML missing <page> inside <net>")

    places: list[Place] = []
    transitions: list[Transition] = []
    place_elems: dict[PlaceId, ET.Element] = {}
    trans_elems: dict[TransId, ET.Element] = {}

    for c in list(page):
        tg = _strip_ns(c.tag)
        if tg == "place":
            pl = _parse_place(c)
            if pl.id in place_elems:
                raise ValueError(f"Duplicate place id in PNML: {pl.id}")
            places.append(pl)
            place_elems[pl.id] = c
        elif tg == "transition":
            tr = _parse_transition(c)
            if tr.id in trans_elems:
                raise ValueError(f"Duplicate transition id in PNML: {tr.id}")
            transitions.append(tr)
            trans_elems[tr.id] = c

    # Deterministic ordering: by PNML id.
    places.sort(key=lambda p: str(p.id))
    transitions.sort(key=lambda t: str(t.id))

    place_index = {p.id: i for i, p in enumerate(places)}
    trans_index = {t.id: i for i, t in enumerate(transitions)}

    m0: list[int] = [0 for _ in places]
    for p in places:
        pe = place_elems.get(p.id)
        if pe is None:
            continue
        im = _find_child_text(pe, ["initialMarking", "text"])
        v = _parse_int_text(im, default=0)
        if v < 0:
            raise ValueError(f"Negative initial marking for place {p.id}: {v}")
        m0[place_index[p.id]] = v

    pre: list[dict[int, int]] = [dict() for _ in transitions]
    post: list[dict[int, int]] = [dict() for _ in transitions]

    for c in list(page):
        if _strip_ns(c.tag) != "arc":
            continue
        src = c.attrib.get("source")
        dst = c.attrib.get("target")
        if not src or not dst:
            continue
        w = _parse_arc_weight(c)
        if w <= 0:
            raise ValueError(f"Arc weight must be positive, got {w} (source={src}, target={dst})")

        if PlaceId(src) in place_index and TransId(dst) in trans_index:
            p_idx = place_index[PlaceId(src)]
            t_idx = trans_index[TransId(dst)]
            pre[t_idx][p_idx] = pre[t_idx].get(p_idx, 0) + w
        elif TransId(src) in trans_index and PlaceId(dst) in place_index:
            t_idx = trans_index[TransId(src)]
            p_idx = place_index[PlaceId(dst)]
            post[t_idx][p_idx] = post[t_idx].get(p_idx, 0) + w
        else:
            # Strict mode for the webapp subset: we only accept place->transition and transition->place arcs.
            # Anything else usually means the PNML has additional elements we don't support yet.
            raise ValueError(f"Unsupported arc endpoints (expected place<->transition): source={src}, target={dst}")

    net = PTNet(
        places=tuple(places),
        transitions=tuple(transitions),
        pre=tuple(pre),
        post=tuple(post),
        m0=tuple(m0),
    )

    props = _parse_toolspecific_properties(net, net_elem)
    return ParsedPNML(net=net, properties=props)

