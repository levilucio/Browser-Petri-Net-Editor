"""
Place/Transition Net Model - Kernel Instantiation

Kernel mapping for P/T nets:
  - U (symbolic universe): ∅ (empty - no symbolic variables in basic P/T nets)
  - S (structure): Marking = tuple[TokenCount, ...] where TokenCount = OmegaInt (ω-extended integer)
  - Θ (constraints): ∅ (empty - no path constraints)

This is a *concrete* instantiation of the symbolic execution kernel where the
full (U, S, Θ) machinery degenerates to just the marking. The state space is
explored via explicit marking enumeration rather than SMT-based constraint solving.

For algebraic Petri nets or colored Petri nets with symbolic data, a separate
implementation would use the full core/state.py infrastructure with Z3 constraints.

See: petri-net-pt.tex for the mathematical instantiation.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property
from typing import NewType

PlaceId = NewType("PlaceId", str)
TransId = NewType("TransId", str)


@dataclass(frozen=True)
class Place:
    id: PlaceId
    name: str


@dataclass(frozen=True)
class Transition:
    id: TransId
    name: str


# Token count in a marking, using the shared ω-extended integer abstraction.
from ..core.abstract_domains import OmegaInt, PointwiseTupleOrder

TokenCount = OmegaInt
Marking = tuple[TokenCount, ...]

def tc(n: int) -> TokenCount:
    return OmegaInt.finite(int(n))

TC_OMEGA: TokenCount = OmegaInt.omega()
_MARKING_ORDER = PointwiseTupleOrder[TokenCount](lambda left, right: left.leq(right))


def _add_tc(a: TokenCount, b: TokenCount) -> TokenCount:
    return a.add(b)


def _sub_tc(a: TokenCount, b: int) -> TokenCount:
    return a.sub_finite(int(b))


@dataclass(frozen=True)
class PTNet:
    places: tuple[Place, ...]
    transitions: tuple[Transition, ...]
    # Dense matrices via per-transition dicts: transition index -> {place index -> weight}
    pre: tuple[dict[int, int], ...]
    post: tuple[dict[int, int], ...]
    m0: tuple[int, ...]

    def __post_init__(self) -> None:
        if len(self.m0) != len(self.places):
            raise ValueError(f"m0 length {len(self.m0)} != #places {len(self.places)}")
        if len(self.pre) != len(self.transitions):
            raise ValueError(f"pre length {len(self.pre)} != #transitions {len(self.transitions)}")
        if len(self.post) != len(self.transitions):
            raise ValueError(f"post length {len(self.post)} != #transitions {len(self.transitions)}")

        n_places = len(self.places)
        for t_idx, d in enumerate(self.pre):
            for p_idx, w in d.items():
                if not (0 <= p_idx < n_places):
                    raise ValueError(f"pre[{t_idx}] references out-of-range place index {p_idx}")
                if w <= 0:
                    raise ValueError(f"pre[{t_idx}][{p_idx}] has non-positive weight {w}")
        for t_idx, d in enumerate(self.post):
            for p_idx, w in d.items():
                if not (0 <= p_idx < n_places):
                    raise ValueError(f"post[{t_idx}] references out-of-range place index {p_idx}")
                if w <= 0:
                    raise ValueError(f"post[{t_idx}][{p_idx}] has non-positive weight {w}")

    @cached_property
    def place_index(self) -> dict[PlaceId, int]:
        return {p.id: i for i, p in enumerate(self.places)}

    @cached_property
    def trans_index(self) -> dict[TransId, int]:
        return {t.id: i for i, t in enumerate(self.transitions)}


def enabled(net: PTNet, m: Marking, t_idx: int) -> bool:
    pre = net.pre[t_idx]
    for p_idx, w in pre.items():
        c = m[p_idx]
        if c.is_omega():
            continue
        if c.unwrap_finite() < w:
            return False
    return True


def fire(net: PTNet, m: Marking, t_idx: int) -> Marking:
    # assumes enabled
    pre = net.pre[t_idx]
    post = net.post[t_idx]
    out = list(m)
    for p_idx, w in pre.items():
        out[p_idx] = _sub_tc(out[p_idx], w)
    for p_idx, w in post.items():
        out[p_idx] = _add_tc(out[p_idx], tc(w))
    return tuple(out)


def marking_le(a: Marking, b: Marking) -> bool:
    # a <= b componentwise, with ω as top
    return _MARKING_ORDER.leq(a, b)


def marking_eq(a: Marking, b: Marking) -> bool:
    return a == b


def pretty_marking(net: PTNet, m: Marking, *, show_zeros: bool = False) -> str:
    parts: list[str] = []
    for i, p in enumerate(net.places):
        c = m[i]
        if not show_zeros and (not c.is_omega()) and c.unwrap_finite() == 0:
            continue
        v = str(c)
        parts.append(f"{p.name}={v}")
    if not parts:
        return "∅"
    return ", ".join(parts)

