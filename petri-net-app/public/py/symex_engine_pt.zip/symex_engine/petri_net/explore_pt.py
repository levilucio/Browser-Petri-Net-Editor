"""
Place/Transition Net Explorer - Kernel Instantiation

This module implements symbolic execution for P/T nets as a kernel instantiation.

Kernel mapping:
  - Symbolic state: Marking (concrete tuple of token counts)
  - Symbolic transition: Transition firing (consume pre-places, produce post-places)
  - Subsumption: marking_le (componentwise ≤ with ω as top)
  - Abstraction: Karp-Miller acceleration (promote to ω on strictly increasing paths)
  - POR: Partial-Order Reduction via structural independence (shared places)

This implementation does NOT use core/state.py or core/z3_backend.py because:
  1. P/T nets have no symbolic variables (U = ∅)
  2. P/T nets have no path constraints (Θ = ∅)
  3. Subsumption is simple tuple comparison, not SMT entailment

The exploration is purely concrete, making it much faster than SMT-based approaches.
For algebraic/colored Petri nets with symbolic data, a separate implementation
would import from core/ and use Z3-backed symbolic states.

See: petri-net-pt.tex for the mathematical instantiation.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
import time
from typing import Hashable, Literal

from .pnml_pt_parser import ParsedPNML, parse_pnml_pt
from .pt_graph import (
    EDGE_FLAG_KM_ACCEL,
    EDGE_FLAG_SUBSUMED,
    PTExecGraph,
    PTNode,
)
from .pt_model import Marking, PTNet, fire, marking_le, pretty_marking, tc, TC_OMEGA
from .pt_properties import PropertyResult, PropertySpec, marking_to_name_map
from .pt_semantics import is_deadlock, successors
from .por import (
    PTNetFootprints,
    compute_ample_set,
    extract_visible_places,
)
from ..core.abstract_domains import promote_increasing_components_to_top
from ..core.explorer import (
    CoreExplorationResult,
    CoreExplorer,
    CoreStep,
    ExplorerConfig,
    ExplorationContext,
)
from ..core.por import PORStats
from ..core.properties import PropertyQueryResult, query_exists, query_invariant
from ..core.well_structured import (
    AncestorWidening,
    WellStructuredPreorder,
    first_covering_ancestor,
)


Mode = Literal["exact", "km"]


@dataclass(frozen=True)
class ExploreStats:
    mode: Mode
    nodes: int
    edges: int
    truncated: bool
    max_nodes: int
    max_steps: int
    parse_s: float = 0.0
    explore_s: float = 0.0
    total_s: float = 0.0
    # POR statistics
    use_por: bool = False
    por_choice_points: int = 0
    por_reduced_points: int = 0
    por_total_enabled: int = 0
    por_total_explored: int = 0


@dataclass(frozen=True)
class ExploreResult:
    parsed: ParsedPNML
    graph: PTExecGraph
    property_results: tuple[PropertyResult, ...]
    stats: ExploreStats


def _check_properties(
    net: PTNet,
    core_result: CoreExplorationResult[Marking, PTLabel],
    props: tuple[PropertySpec, ...],
    *,
    mode: Mode,
    truncated: bool,
) -> tuple[PropertyResult, ...]:
    """Interpret P/T property specs over the kernel exploration result.

    Node scanning and witness-trace recovery are delegated to the reusable
    ``core.properties`` query layer. This function keeps only the P/T-specific
    predicates (coverability vectors, deadlock) and the domain verdict policy
    (exact vs. Karp-Miller soundness).
    """

    results: list[PropertyResult] = []

    def _unknown_or_overapprox() -> str:
        if truncated:
            return "unknown_truncated"
        if mode == "km":
            return "unknown_overapprox"
        return "unknown_truncated"

    def _extract_cover_vector(spec: PropertySpec) -> Marking:
        """
        For KM mode, `exists_coverable` is interpreted as a target vector v, i.e.
        a conjunction of lower bounds of the form M(p) >= k.
        This is upward-closed and soundly checkable via coverability.

        Returns a Marking (tuple of OmegaInt) for use with marking_le.
        """
        if spec.predicate is None:
            raise ValueError("exists_coverable requires a predicate")

        # Flatten conjunctions of >=(place,const)
        req: dict[int, int] = {}

        def add_ge(pred) -> None:
            if pred.cmp_op != ">=" or pred.lhs is None or pred.rhs is None:
                raise ValueError("exists_coverable supports only >= comparisons")
            if pred.lhs.op != "place" or pred.lhs.place is None:
                raise ValueError("exists_coverable supports only >= with place on LHS")
            if pred.rhs.op != "const" or pred.rhs.k is None:
                raise ValueError("exists_coverable supports only >= with const on RHS")
            k = int(pred.rhs.k)
            if k < 0:
                raise ValueError("exists_coverable expects non-negative bounds")
            p_idx = net.place_index[pred.lhs.place]
            req[p_idx] = max(req.get(p_idx, 0), k)

        def walk(pred) -> None:
            if pred.bool_op == "and":
                for a in pred.args:
                    walk(a)
                return
            add_ge(pred)

        walk(spec.predicate)

        # Build cover vector as OmegaInt marking (for use with marking_le)
        v = [tc(0) for _ in net.places]
        for idx, k in req.items():
            v[idx] = tc(k)
        return tuple(v)

    def _witness(
        result: PropertyQueryResult[PTLabel],
    ) -> tuple[int | None, dict[str, str] | None, list[str] | None]:
        """Map a kernel query witness to the P/T presentation triple."""
        if result.witness_node is None:
            return None, None, None
        marking = core_result.graph.nodes[result.witness_node].state
        trace = [net.transitions[label.t_idx].name for label in result.witness_trace]
        return result.witness_node, marking_to_name_map(net, marking), trace

    for spec in props:
        if spec.type == "invariant":
            result = query_invariant(
                core_result,
                lambda m, spec=spec: spec.predicate.eval(net, m),
            )
            if result.witness_node is None:
                if mode == "km":
                    # In KM mode, invariants are not generally sound unless phrased as upward-closed coverability queries.
                    results.append(PropertyResult(spec=spec, status=_unknown_or_overapprox()))  # type: ignore[arg-type]
                else:
                    status: Literal["holds", "unknown_truncated"] = "unknown_truncated" if truncated else "holds"
                    results.append(PropertyResult(spec=spec, status=status))
            else:
                witness_node, witness_marking, witness_trace = _witness(result)
                results.append(
                    PropertyResult(
                        spec=spec,
                        status="may_violated" if mode == "km" else "violated",
                        witness_node=witness_node,
                        witness_marking=witness_marking,
                        witness_trace=witness_trace,
                    )
                )

        elif spec.type == "exists_coverable":
            if mode == "km":
                target = _extract_cover_vector(spec)
                result = query_exists(
                    core_result,
                    lambda m, target=target: marking_le(target, m),
                )
            else:
                result = query_exists(
                    core_result,
                    lambda m, spec=spec: spec.predicate.eval(net, m),
                )
            if result.witness_node is None:
                status2: Literal["unknown_truncated", "violated"] = "unknown_truncated" if truncated else "violated"
                results.append(PropertyResult(spec=spec, status=status2))
            else:
                witness_node, witness_marking, witness_trace = _witness(result)
                results.append(
                    PropertyResult(
                        spec=spec,
                        status="witnessed",
                        witness_node=witness_node,
                        witness_marking=witness_marking,
                        witness_trace=witness_trace,
                    )
                )

        elif spec.type == "exists_deadlock":
            result = query_exists(core_result, lambda m: is_deadlock(net, m))
            if result.witness_node is not None:
                witness_node, witness_marking, witness_trace = _witness(result)
                results.append(
                    PropertyResult(
                        spec=spec,
                        status="may_witnessed" if mode == "km" else "witnessed",
                        witness_node=witness_node,
                        witness_marking=witness_marking,
                        witness_trace=witness_trace,
                    )
                )
            else:
                if mode == "km":
                    results.append(PropertyResult(spec=spec, status=_unknown_or_overapprox()))  # type: ignore[arg-type]
                else:
                    status3: Literal["unknown_truncated", "violated"] = "unknown_truncated" if truncated else "violated"
                    results.append(PropertyResult(spec=spec, status=status3))
        else:
            raise ValueError(f"Unsupported property type: {spec.type}")

    return tuple(results)

def _km_accel(ancestor: Marking, cur: Marking) -> Marking:
    """Karp-Miller promotion as the L2/L4 pointwise helper instance."""

    # α_KM(A,B): if B(p) > A(p) then ω else B(p)
    return promote_increasing_components_to_top(
        ancestor,
        cur,
        gt=lambda current, old: old < current,
        top=TC_OMEGA,
    )


PT_MARKING_PREORDER = WellStructuredPreorder[Marking](
    name="P/T marking cover order",
    leq=marking_le,
    wqo_witness="L2 omega-integers lifted pointwise by L4/L5",
    denotation_argument="M <= N implies denotation(M) is included in denotation(N)",
    compatibility_argument="P/T firing is monotone with respect to componentwise marking order",
)

PT_KM_WIDENING = AncestorWidening(
    preorder=PT_MARKING_PREORDER,
    widen=_km_accel,
    name="Karp-Miller ancestor acceleration",
)


@dataclass(frozen=True)
class PTLabel:
    """Transition index preserved when converting back to `PTExecGraph`."""

    t_idx: int


class _PTAdapter:
    """Adapter from P/T net small-step semantics to `CoreExplorer`."""

    def __init__(
        self,
        net: PTNet,
        *,
        mode: Mode,
        use_por: bool,
        footprints: PTNetFootprints | None,
        visible_places: frozenset[int],
        por_stats: PORStats,
    ) -> None:
        self.net = net
        self.mode = mode
        self.use_por = use_por
        self.footprints = footprints
        self.visible_places = visible_places
        self.por_stats = por_stats
        self._km_accel_applied = False

    def initial_states(self) -> tuple[Marking, ...]:
        return (tuple(tc(int(x)) for x in self.net.m0),)

    def successors(self, marking: Marking) -> list[CoreStep[Marking, PTLabel]]:
        if self.use_por and self.footprints is not None:
            ample_transitions, por_result = compute_ample_set(
                self.footprints,
                marking,
                visible_places=self.visible_places,
            )
            all_enabled = [t for t, _ in self.footprints.get_enabled_footprints(marking)]
            self.por_stats.total_choice_points += 1
            self.por_stats.total_enabled += len(all_enabled)
            self.por_stats.total_explored += len(ample_transitions)
            if not por_result.is_full:
                self.por_stats.reduced_choice_points += 1
            return [
                CoreStep(fire(self.net, marking, t_idx), PTLabel(t_idx))
                for t_idx in ample_transitions
            ]

        return [
            CoreStep(dst_m, PTLabel(t_idx))
            for t_idx, dst_m in successors(self.net, marking)
        ]

    def signature(self, marking: Marking) -> Hashable:
        return marking

    def is_terminal(self, marking: Marking) -> bool:
        return is_deadlock(self.net, marking)

    def abstract_successor(
        self,
        marking: Marking,
        context: ExplorationContext[Marking, PTLabel],
    ) -> Marking:
        if self.mode != "km":
            return marking

        self._km_accel_applied = False
        outcome = PT_KM_WIDENING.apply(marking, context.ancestor_chain)
        self._km_accel_applied = outcome.changed
        return outcome.state

    def subsumed_by_ancestor(
        self,
        candidate: Marking,
        context: ExplorationContext[Marking, PTLabel],
    ) -> int | None:
        if self.mode != "km":
            return None
        return first_covering_ancestor(candidate, context.ancestor_chain, PT_MARKING_PREORDER)

    def extra_edge_flags(
        self,
        _candidate: Marking,
        _context: ExplorationContext[Marking, PTLabel],
    ) -> frozenset[str]:
        if self._km_accel_applied:
            return frozenset({"km_accel"})
        return frozenset()


def _to_pt_graph(core_graph, *, net: PTNet) -> PTExecGraph:
    graph = PTExecGraph(net=net)
    for node_id, core_node in sorted(core_graph.nodes.items()):
        graph.nodes[node_id] = PTNode(id=node_id, marking=core_node.state)
    for core_edge in core_graph.edges:
        flags = 0
        if "km_accel" in core_edge.flags:
            flags |= EDGE_FLAG_KM_ACCEL
        if "subsumed" in core_edge.flags:
            flags |= EDGE_FLAG_SUBSUMED
        graph.edges.append((core_edge.src, core_edge.dst, core_edge.label.t_idx, flags))
    return graph


def explore_pt(
    parsed: ParsedPNML,
    *,
    mode: Mode = "exact",
    max_nodes: int = 50_000,
    max_steps: int = 200_000,
    use_por: bool = False,
) -> ExploreResult:
    net = parsed.net

    por_stats = PORStats()
    footprints: PTNetFootprints | None = None
    visible_places: frozenset[int] = frozenset()
    if use_por:
        footprints = PTNetFootprints.from_net(net)
        visible_places = extract_visible_places(net, parsed.properties)

    adapter = _PTAdapter(
        net,
        mode=mode,
        use_por=use_por,
        footprints=footprints,
        visible_places=visible_places,
        por_stats=por_stats,
    )
    core_result = CoreExplorer(
        adapter,
        config=ExplorerConfig(
            max_nodes=max_nodes,
            max_steps=max_steps,
            search_order="bfs",
            subsumption="none",
        ),
    ).explore()

    g = _to_pt_graph(core_result.graph, net=net)
    truncated = core_result.stats.truncated

    prop_results = _check_properties(net, core_result, parsed.properties, mode=mode, truncated=truncated)
    stats = ExploreStats(
        mode=mode,
        nodes=len(g.nodes),
        edges=len(g.edges),
        truncated=truncated,
        max_nodes=max_nodes,
        max_steps=max_steps,
        use_por=use_por,
        por_choice_points=por_stats.total_choice_points,
        por_reduced_points=por_stats.reduced_choice_points,
        por_total_enabled=por_stats.total_enabled,
        por_total_explored=por_stats.total_explored,
    )
    return ExploreResult(parsed=parsed, graph=g, property_results=prop_results, stats=stats)


def _results_json(res: ExploreResult) -> dict:
    net = res.parsed.net
    return {
        "schema_version": 1,
        "net": {
            "id": "net1",
            "places": [{"id": str(p.id), "name": p.name} for p in net.places],
            "transitions": [{"id": str(t.id), "name": t.name} for t in net.transitions],
            "m0": {str(p.id): str(net.m0[i]) for i, p in enumerate(net.places)},
        },
        "stats": asdict(res.stats),
        "properties": [
            {
                "id": r.spec.id,
                "name": r.spec.name,
                "type": r.spec.type,
                "severity": r.spec.severity,
                "status": r.status,
                "witness_node": r.witness_node,
                "witness_marking": r.witness_marking,
                "witness_trace": r.witness_trace,
            }
            for r in res.property_results
        ],
        "graph": {
            "nodes": [
                {
                    "id": n.id,
                    "marking_by_place_id": {str(p.id): str(n.marking[i]) for i, p in enumerate(net.places)},
                    "marking_pretty": pretty_marking(net, n.marking, show_zeros=True),
                }
                for n in sorted(res.graph.nodes.values(), key=lambda x: x.id)
            ],
            "edges": [
                {"src": e[0], "dst": e[1], "label": res.graph.edge_label(e)}
                for e in res.graph.edges
            ],
        },
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Explore a PNML Place/Transition net.")
    ap.add_argument("pnml", type=str, help="Path to PNML file")
    ap.add_argument("--mode", choices=["exact", "km"], default="exact")
    ap.add_argument("--max-nodes", type=int, default=50_000)
    ap.add_argument("--max-steps", type=int, default=200_000)
    ap.add_argument("--out-dot", type=str, default="", help="Write DOT output to this path")
    ap.add_argument("--out-json", type=str, default="", help="Write JSON output to this path")
    ap.add_argument(
        "--time",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Include parse/explore timing information in the stdout summary (default: enabled).",
    )
    ap.add_argument(
        "--por",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Enable Partial-Order Reduction to reduce state space (default: disabled).",
    )
    args = ap.parse_args(argv)

    t0 = time.perf_counter()
    t_parse0 = time.perf_counter()
    parsed = parse_pnml_pt(args.pnml)
    t_parse1 = time.perf_counter()
    t_explore0 = time.perf_counter()
    res = explore_pt(
        parsed,
        mode=args.mode,
        max_nodes=args.max_nodes,
        max_steps=args.max_steps,
        use_por=args.por,
    )
    t_explore1 = time.perf_counter()
    t1 = time.perf_counter()

    # Enrich stats with timing info for CLI reporting/artifacts.
    res = ExploreResult(
        parsed=res.parsed,
        graph=res.graph,
        property_results=res.property_results,
        stats=ExploreStats(
            mode=res.stats.mode,
            nodes=res.stats.nodes,
            edges=res.stats.edges,
            truncated=res.stats.truncated,
            max_nodes=res.stats.max_nodes,
            max_steps=res.stats.max_steps,
            parse_s=t_parse1 - t_parse0,
            explore_s=t_explore1 - t_explore0,
            total_s=t1 - t0,
            use_por=res.stats.use_por,
            por_choice_points=res.stats.por_choice_points,
            por_reduced_points=res.stats.por_reduced_points,
            por_total_enabled=res.stats.por_total_enabled,
            por_total_explored=res.stats.por_total_explored,
        ),
    )

    if args.out_dot:
        Path(args.out_dot).write_text(res.graph.to_dot(), encoding="utf-8")
    if args.out_json:
        Path(args.out_json).write_text(json.dumps(_results_json(res), indent=2), encoding="utf-8")

    # Always print a concise summary to stdout (useful for CI / quick runs).
    stats_json = asdict(res.stats)
    if not args.time:
        # Strip timing fields if user disables timing output.
        stats_json.pop("parse_s", None)
        stats_json.pop("explore_s", None)
        stats_json.pop("total_s", None)
    print(json.dumps({"stats": stats_json, "properties": [asdict(r) for r in res.property_results]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

