"""
Symbolic execution engine package.

The package is structured as a small shared core plus language-specific plugins:
- `symex_engine.core`: shared reusable building blocks (e.g., Z3 backend, symbolic state)
- `symex_engine.tiny_imperative_language`: tiny language front-end + symbolic checker
- `symex_engine.petri_net`: P/T-net front-end + symbolic checker
- `symex_engine.til_petri_product`: surface specs for TIL x P/T composition
- `symex_engine.promela`: Mini-Promela front-end + CTL-oriented explorer
- `symex_engine.mini_lisp`: Mini-Lisp front-end + concrete/symbolic explorer
- `symex_engine.dtmc`: finite DTMC support exploration + PCTL-lite probabilities
- `symex_engine.mdp`: finite MDP support exploration + min/max probabilities
"""

__all__ = [
    "core",
    "tiny_imperative_language",
    "petri_net",
    "til_petri_product",
    "promela",
    "mini_lisp",
    "dtmc",
    "mdp",
]



