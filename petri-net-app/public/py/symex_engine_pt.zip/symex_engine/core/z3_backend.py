"""
Z3 Backend with Performance Optimizations

Tier 1 Optimizations:
  1. Constraint hash caching for SAT/entails checks
  2. Concrete fast-path to skip Z3 entirely for ground expressions
  3. IncrementalSolver with push/pop for reused contexts
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

import z3


class Z3BackendError(ValueError):
    pass


@dataclass
class SymbolFactory:
    counters: dict[tuple[str, z3.SortRef], int] = field(default_factory=dict)
    universe: set[z3.ExprRef] = field(default_factory=set)

    def fresh(self, base: str, sort: z3.SortRef) -> z3.ExprRef:
        key = (base, sort)
        k = self.counters.get(key, 0)
        self.counters[key] = k + 1
        name = f"{base}!{k}"
        if sort == z3.IntSort():
            sym = z3.Int(name)
        elif sort == z3.BoolSort():
            sym = z3.Bool(name)
        elif isinstance(sort, z3.ArraySortRef):
            sym = z3.Array(name, sort.domain(), sort.range())
        else:
            raise Z3BackendError(f"Unsupported sort: {sort}")
        self.universe.add(sym)
        return sym


# =============================================================================
# Concrete Fast-Path Helpers
# =============================================================================

def is_concrete(e: z3.ExprRef) -> bool:
    """Check if an expression is fully concrete (no symbolic variables)."""
    return z3.is_int_value(e) or z3.is_true(e) or z3.is_false(e)


def concrete_bool(e: z3.ExprRef) -> bool | None:
    """Get concrete boolean value, or None if symbolic."""
    if z3.is_true(e):
        return True
    if z3.is_false(e):
        return False
    s = z3.simplify(e)
    if z3.is_true(s):
        return True
    if z3.is_false(s):
        return False
    return None


def concrete_int(e: z3.ExprRef) -> int | None:
    """Get concrete integer value, or None if symbolic."""
    if z3.is_int_value(e):
        return e.as_long()
    s = z3.simplify(e)
    if z3.is_int_value(s):
        return s.as_long()
    return None


# =============================================================================
# SAT Checking with Caching
# =============================================================================

def _constraints_key(constraints: Iterable[z3.BoolRef]) -> tuple[int, ...]:
    """Order-sensitive but stable hash for constraint sequences."""
    return tuple(int(c.hash()) for c in constraints)


_SAT_BOOL_CACHE: dict[tuple[int, ...], bool] = {}
_ENTAILS_BOOL_CACHE: dict[tuple[tuple[int, ...], int], bool] = {}
_CACHE_MAX_SIZE = 100000


def _cache_put_sat(key: tuple[int, ...], value: bool) -> None:
    global _SAT_BOOL_CACHE
    if len(_SAT_BOOL_CACHE) > _CACHE_MAX_SIZE:
        keys_to_remove = list(_SAT_BOOL_CACHE.keys())[:_CACHE_MAX_SIZE // 2]
        for k in keys_to_remove:
            del _SAT_BOOL_CACHE[k]
    _SAT_BOOL_CACHE[key] = value


def _cache_put_entails(key: tuple[tuple[int, ...], int], value: bool) -> None:
    global _ENTAILS_BOOL_CACHE
    if len(_ENTAILS_BOOL_CACHE) > _CACHE_MAX_SIZE:
        keys_to_remove = list(_ENTAILS_BOOL_CACHE.keys())[:_CACHE_MAX_SIZE // 2]
        for k in keys_to_remove:
            del _ENTAILS_BOOL_CACHE[k]
    _ENTAILS_BOOL_CACHE[key] = value


def is_sat(constraints: Iterable[z3.BoolRef]) -> tuple[bool, z3.ModelRef | None]:
    """Backwards-compatible API: check satisfiable and return a model."""
    return check_sat(constraints, need_model=True)


def check_sat(
    constraints: Iterable[z3.BoolRef],
    *,
    need_model: bool = False,
) -> tuple[bool, z3.ModelRef | None]:
    """Check satisfiability with caching and concrete fast-path."""
    cs = list(constraints)
    
    # Fast-path: check for concrete true/false
    for c in cs:
        val = concrete_bool(c)
        if val is False:
            return False, None
    
    if all(concrete_bool(c) is True for c in cs):
        return True, None if not need_model else (True, None)
    
    if not need_model:
        k = _constraints_key(cs)
        cached = _SAT_BOOL_CACHE.get(k)
        if cached is not None:
            return cached, None

    s = z3.Solver()
    s.add(*cs)
    r = s.check()
    
    if r == z3.sat:
        if need_model:
            return True, s.model()
        _cache_put_sat(_constraints_key(cs), True)
        return True, None
    if r == z3.unsat:
        if not need_model:
            _cache_put_sat(_constraints_key(cs), False)
        return False, None
    return False, None


def check_sat_concrete_first(constraints: list[z3.BoolRef], extra: z3.BoolRef) -> bool:
    """Optimized check for constraints + extra with concrete fast-path."""
    extra_val = concrete_bool(extra)
    if extra_val is False:
        return False
    if extra_val is True:
        if not constraints:
            return True
    sat, _ = check_sat(constraints + [extra], need_model=False)
    return sat


def simplify(e: z3.ExprRef) -> z3.ExprRef:
    return z3.simplify(e)


def conjoin(constraints: Iterable[z3.BoolRef]) -> z3.BoolRef:
    cs = list(constraints)
    if not cs:
        return z3.BoolVal(True)
    return z3.And(*cs)


def project(formula: z3.BoolRef, eliminate: Iterable[z3.ExprRef]) -> z3.BoolRef:
    """Existentially eliminate variables from a Boolean formula.

    This is the shared projection primitive for SMT-backed abstractions:
    domains can forget variables while preserving all consequences over the
    remaining vocabulary.  Z3's ``qe`` tactic is complete for the linear
    arithmetic fragments used by the current adapters; unsupported fragments may
    leave quantifiers in the simplified result.
    """

    vars_to_eliminate = list(eliminate)
    if not vars_to_eliminate:
        return z3.simplify(formula)
    try:
        projected = z3.Tactic("qe")(z3.Exists(vars_to_eliminate, formula)).as_expr()
    except z3.Z3Exception as exc:
        raise Z3BackendError("projection failed") from exc
    return z3.simplify(projected)


def project_conjunction(
    constraints: Iterable[z3.BoolRef],
    eliminate: Iterable[z3.ExprRef],
) -> z3.BoolRef:
    """Project a conjunction of constraints over the remaining variables."""

    return project(conjoin(constraints), eliminate)


def entails(assumptions: Iterable[z3.BoolRef], conclusion: z3.BoolRef) -> bool:
    """Check whether assumptions entail conclusion."""
    asm = list(assumptions)
    
    if concrete_bool(conclusion) is True:
        return True
    if concrete_bool(conclusion) is False:
        sat, _ = check_sat(asm, need_model=False)
        return not sat
    
    k = (_constraints_key(asm), int(conclusion.hash()))
    cached = _ENTAILS_BOOL_CACHE.get(k)
    if cached is not None:
        return cached

    s = z3.Solver()
    s.add(*asm)
    s.add(z3.Not(conclusion))
    r = s.check()
    out = r == z3.unsat
    _cache_put_entails(k, out)
    return out


@dataclass
class IncrementalSolver:
    """Reusable solver with push/pop for efficient related queries."""
    base_constraints: tuple[z3.BoolRef, ...]
    solver: z3.Solver = field(default_factory=z3.Solver)

    def __post_init__(self) -> None:
        self.solver.add(*list(self.base_constraints))

    def entails(self, conclusion: z3.BoolRef) -> bool:
        self.solver.push()
        self.solver.add(z3.Not(conclusion))
        r = self.solver.check()
        self.solver.pop()
        return r == z3.unsat

    def sat(self, extra: Iterable[z3.BoolRef] = (), *, need_model: bool = False) -> tuple[bool, z3.ModelRef | None]:
        self.solver.push()
        self.solver.add(*list(extra))
        r = self.solver.check()
        if r == z3.sat:
            m = self.solver.model() if need_model else None
            self.solver.pop()
            return True, m
        self.solver.pop()
        return False, None
    
    def sat_with(self, extra: z3.BoolRef) -> bool:
        extra_val = concrete_bool(extra)
        if extra_val is False:
            return False
        if extra_val is True:
            return True
        self.solver.push()
        self.solver.add(extra)
        r = self.solver.check()
        self.solver.pop()
        return r == z3.sat


def clear_caches() -> None:
    """Clear all caches (useful for testing)."""
    global _SAT_BOOL_CACHE, _ENTAILS_BOOL_CACHE
    _SAT_BOOL_CACHE = {}
    _ENTAILS_BOOL_CACHE = {}
