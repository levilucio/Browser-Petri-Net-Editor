"""
Symbolic Execution Kernel Core - Shared Building Blocks

This package provides:
  - A reusable worklist exploration algorithm with graph, parent-trace,
    memoization, abstraction, and subsumption hooks
  - (U, S, Θ) symbolic state infrastructure for kernel instantiations requiring
    symbolic variables and SMT-based constraint solving
  - Reusable ordering / antichain helpers and small abstract-domain values
  - Product adapters for composing independent or synchronized instantiations
  - Partial-Order Reduction (POR) abstractions shared across instantiations
  - Finite-graph value interpretation helpers for property and quantitative layers
  - Well-structured preorder helpers for abstraction/subsumption/termination

Used by instantiations with symbolic data:
  - TIL (Tiny Imperative Language): Full symbolic execution with loop abstraction
  - Algebraic/Colored Petri nets (future): Symbolic tokens and guards

Used by all instantiations (regardless of symbolic data):
  - POR module: Common abstractions for confluence modulo constraints

The kernel design allows instantiations to specialize the state representation
when the full (U, S, Θ) generality is not needed, as long as the kernel's
semantic guarantees (subsumption soundness, WQO, etc.) are preserved.
"""

__all__ = [
    "explorer",
    "graph",
    "order",
    "state",
    "z3_backend",
    "por",
    "properties",
    "graph_interpretation",
    "well_structured",
    "abstract_domains",
    "composition",
    "adapters",
    "render",
]

