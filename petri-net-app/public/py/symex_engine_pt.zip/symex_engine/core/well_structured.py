"""Well-structured preorder helpers for adapter proofs and implementations.

The core exploration loop consumes three hooks: abstraction, subsumption, and a
termination argument. For many adapters those are all projections of one
preorder: ``precise <= abstract`` means the right-hand state denotes a superset
of the left-hand state, the preorder is a WQO on the abstract image, and
widening/acceleration is inflationary in that preorder.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Generic, TypeVar


StateT = TypeVar("StateT")


@dataclass(frozen=True)
class WellStructuredPreorder(Generic[StateT]):
    """A denotation-respecting WQO witness used by adapters.

    ``leq(precise, abstract)`` follows the precision order: if it holds, the
    denotation of ``precise`` is contained in the denotation of ``abstract``.
    The strings are proof metadata for papers/reports; the runtime can only
    centralize the recurring order plumbing, not prove the mathematical facts.
    """

    name: str
    leq: Callable[[StateT, StateT], bool]
    wqo_witness: str
    denotation_argument: str
    compatibility_argument: str | None = None

    def covers(self, existing: StateT, candidate: StateT) -> bool:
        """Return whether ``existing`` denotes a superset of ``candidate``."""

        return self.leq(candidate, existing)

    def can_accelerate_from(self, ancestor: StateT, candidate: StateT) -> bool:
        """Return whether ``candidate`` grows from ``ancestor`` in this order."""

        return self.leq(ancestor, candidate)

    @property
    def has_compatibility_argument(self) -> bool:
        """Whether this order carries a transition-compatibility proof note."""

        return self.compatibility_argument is not None


@dataclass(frozen=True)
class WideningOutcome(Generic[StateT]):
    """Result of applying an ancestor-sensitive widening policy."""

    state: StateT
    changed: bool


@dataclass(frozen=True)
class AncestorWidening(Generic[StateT]):
    """Apply a binary widening against compatible ancestors.

    This packages the Karp-Miller/octagon-style pattern: find ancestors in the
    same region, check growth in the preorder, and replace the candidate with an
    over-approximation supplied by the adapter.
    """

    preorder: WellStructuredPreorder[StateT]
    widen: Callable[[StateT, StateT], StateT]
    same_region: Callable[[StateT, StateT], bool] = lambda _ancestor, _candidate: True
    name: str = "ancestor-widening"

    def apply(
        self,
        state: StateT,
        ancestors: Sequence[tuple[int, StateT]],
    ) -> WideningOutcome[StateT]:
        """Return ``state`` widened against all growing compatible ancestors."""

        current = state
        changed = False
        for _ancestor_id, ancestor in ancestors:
            if not self.same_region(ancestor, current):
                continue
            if not self.preorder.can_accelerate_from(ancestor, current):
                continue
            widened = self.widen(ancestor, current)
            if widened != current:
                changed = True
            current = widened
        return WideningOutcome(state=current, changed=changed)


def first_covering_ancestor(
    candidate: StateT,
    ancestors: Sequence[tuple[int, StateT]],
    preorder: WellStructuredPreorder[StateT],
    *,
    same_region: Callable[[StateT, StateT], bool] = lambda _ancestor, _candidate: True,
) -> int | None:
    """Return the first ancestor that covers ``candidate`` in ``preorder``."""

    for ancestor_id, ancestor in ancestors:
        if same_region(ancestor, candidate) and preorder.covers(ancestor, candidate):
            return ancestor_id
    return None