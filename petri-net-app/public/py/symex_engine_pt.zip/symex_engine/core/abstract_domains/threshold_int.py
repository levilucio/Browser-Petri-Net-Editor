"""Thresholded integer abstraction.

The domain maps integers into a finite chain of thresholds plus bottom/top-like
outer intervals. It is a small building block; each instantiation decides where
thresholds come from and whether the abstraction is precise enough.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, order=True)
class ThresholdBucket:
    """A finite integer bucket identified by its position in the threshold chain."""

    index: int
    label: str


@dataclass(frozen=True)
class ThresholdIntDomain:
    thresholds: tuple[int, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "thresholds", tuple(sorted(set(self.thresholds))))

    def abstract(self, value: int) -> ThresholdBucket:
        """Map ``value`` to a finite bucket."""

        if not self.thresholds:
            return ThresholdBucket(0, "top")
        if value < self.thresholds[0]:
            return ThresholdBucket(0, f"<{self.thresholds[0]}")
        for index, threshold in enumerate(self.thresholds, start=1):
            if value == threshold:
                return ThresholdBucket(index, str(threshold))
            if value < threshold:
                prev = self.thresholds[index - 2]
                return ThresholdBucket(index, f"({prev},{threshold})")
        return ThresholdBucket(len(self.thresholds) + 1, f">{self.thresholds[-1]}")

    def leq(self, left: ThresholdBucket, right: ThresholdBucket) -> bool:
        """Finite-chain order over buckets."""

        return left.index <= right.index


@dataclass(frozen=True)
class ThresholdUpperBound:
    """Upper bound in a finite threshold chain plus +infinity.

    ``value=None`` denotes +infinity.  Joining two bounds moves to the less
    precise upper bound: the larger finite threshold, or +infinity if either
    side is already top.
    """

    value: int | None

    @staticmethod
    def finite(value: int) -> "ThresholdUpperBound":
        return ThresholdUpperBound(value)

    @staticmethod
    def top() -> "ThresholdUpperBound":
        return ThresholdUpperBound(None)

    @staticmethod
    def from_optional(value: int | None) -> "ThresholdUpperBound":
        return ThresholdUpperBound(value)

    def to_optional(self) -> int | None:
        return self.value

    def is_top(self) -> bool:
        return self.value is None

    def join(self, other: "ThresholdUpperBound") -> "ThresholdUpperBound":
        if self.value is None or other.value is None:
            return ThresholdUpperBound.top()
        return ThresholdUpperBound.finite(max(self.value, other.value))

    def leq(self, other: "ThresholdUpperBound") -> bool:
        """Precision order: smaller finite bounds are more precise than larger ones."""

        if other.value is None:
            return True
        if self.value is None:
            return False
        return self.value <= other.value
