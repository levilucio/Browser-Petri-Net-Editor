"""Composable product/map domains for WQO witnesses."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Callable, Generic, Hashable, Iterable, TypeVar


T = TypeVar("T")
K = TypeVar("K", bound=Hashable)


def pointwise_tuple_leq(
    left: tuple[T, ...],
    right: tuple[T, ...],
    leq: Callable[[T, T], bool],
) -> bool:
    return len(left) == len(right) and all(leq(a, b) for a, b in zip(left, right, strict=True))


def pointwise_dict_leq(
    left: dict[Hashable, T],
    right: dict[Hashable, T],
    leq: Callable[[T, T], bool],
) -> bool:
    if set(left) != set(right):
        return False
    return all(leq(left[k], right[k]) for k in left)


def pointwise_dict_join(
    left: dict[K, T],
    right: dict[K, T],
    join: Callable[[T, T], T],
    *,
    missing: T,
) -> dict[K, T]:
    """Pointwise join over possibly sparse maps with a shared default."""

    keys = set(left) | set(right)
    return {key: join(left.get(key, missing), right.get(key, missing)) for key in keys}


def promote_increasing_components_to_top(
    ancestor: tuple[T, ...],
    current: tuple[T, ...],
    *,
    gt: Callable[[T, T], bool],
    top: T,
) -> tuple[T, ...]:
    """Vector helper used by Karp-Miller-like policies.

    The soundness argument is domain-specific; the pointwise transformation is
    generic and reusable.
    """

    return tuple(top if gt(cur, old) else cur for old, cur in zip(ancestor, current, strict=True))


@dataclass(frozen=True)
class PointwiseTupleOrder(Generic[T]):
    """Pointwise order over fixed-length tuples."""

    leq_component: Callable[[T, T], bool]

    def leq(self, left: tuple[T, ...], right: tuple[T, ...]) -> bool:
        return pointwise_tuple_leq(left, right, self.leq_component)


@dataclass(frozen=True)
class PointwiseMapOrder(Generic[K, T]):
    """Pointwise order over maps with identical key sets."""

    leq_value: Callable[[T, T], bool]

    def leq(self, left: dict[K, T], right: dict[K, T]) -> bool:
        return pointwise_dict_leq(left, right, self.leq_value)


@dataclass(frozen=True)
class LexicographicOrder(Generic[T]):
    """Lexicographic lift of a component preorder.

    This is useful for bounded control metadata where the first differing
    component determines the comparison.
    """

    leq_component: Callable[[T, T], bool]

    def leq(self, left: tuple[T, ...], right: tuple[T, ...]) -> bool:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right, strict=True):
            if a == b:
                continue
            return self.leq_component(a, b)
        return True


@dataclass(frozen=True)
class BoundedMultisetOrder(Generic[T]):
    """Componentwise order over finite counters with a fixed carrier.

    This is the bounded-multiset case used by finite abstractions: counts are
    compared pointwise over a known carrier instead of using an unbounded
    multiset embedding.
    """

    carrier: frozenset[T]

    @classmethod
    def from_iterable(cls, carrier: Iterable[T]) -> "BoundedMultisetOrder[T]":
        return cls(frozenset(carrier))

    def leq(self, left: Counter[T], right: Counter[T]) -> bool:
        if not set(left).issubset(self.carrier) or not set(right).issubset(self.carrier):
            return False
        return all(left[item] <= right[item] for item in self.carrier)
