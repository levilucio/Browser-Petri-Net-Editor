"""
Reusable abstract domains and widening operators shared across kernel instantiations.

We keep these domains small and composable so that different language instances can
reuse common abstractions (e.g., ω-extensions, interval-like bounds) without
copy/pasting per-language logic.
"""

from .finite import FiniteSetDomain, TruthValue
from .omega_int import OmegaInt
from .product import (
    BoundedMultisetOrder,
    LexicographicOrder,
    PointwiseMapOrder,
    PointwiseTupleOrder,
    pointwise_dict_leq,
    pointwise_dict_join,
    pointwise_tuple_leq,
    promote_increasing_components_to_top,
)
from .threshold_int import ThresholdBucket, ThresholdIntDomain, ThresholdUpperBound

__all__ = [
    "FiniteSetDomain",
    "TruthValue",
    "OmegaInt",
    "ThresholdBucket",
    "ThresholdIntDomain",
    "ThresholdUpperBound",
    "BoundedMultisetOrder",
    "LexicographicOrder",
    "PointwiseMapOrder",
    "PointwiseTupleOrder",
    "pointwise_dict_leq",
    "pointwise_dict_join",
    "pointwise_tuple_leq",
    "promote_increasing_components_to_top",
]

