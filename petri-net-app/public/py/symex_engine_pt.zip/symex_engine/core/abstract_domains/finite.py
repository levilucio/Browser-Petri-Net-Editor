"""Small finite abstract domains used by multiple instantiations."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Generic, Iterable, TypeVar


T = TypeVar("T")


class TruthValue(Enum):
    """Three-valued predicate abstraction domain."""

    FALSE = 0
    TRUE = 1
    UNKNOWN = 2

    def leq(self, other: "TruthValue") -> bool:
        """Order by precision: concrete truth values are below UNKNOWN."""

        return self == other or other is TruthValue.UNKNOWN

    @staticmethod
    def join(left: "TruthValue", right: "TruthValue") -> "TruthValue":
        if left == right:
            return left
        return TruthValue.UNKNOWN

    @staticmethod
    def from_optional_bool(value: bool | None) -> "TruthValue":
        if value is True:
            return TruthValue.TRUE
        if value is False:
            return TruthValue.FALSE
        return TruthValue.UNKNOWN

    def to_optional_bool(self) -> bool | None:
        if self is TruthValue.TRUE:
            return True
        if self is TruthValue.FALSE:
            return False
        return None


@dataclass(frozen=True)
class FiniteSetDomain(Generic[T]):
    """A finite carrier with equality order.

    This is intentionally tiny: instantiations decide what the elements mean,
    while the core can still use the carrier to document finiteness / WQO.
    """

    elements: frozenset[T]

    @classmethod
    def from_iterable(cls, elements: Iterable[T]) -> "FiniteSetDomain[T]":
        return cls(frozenset(elements))

    def contains(self, value: T) -> bool:
        return value in self.elements

    def leq(self, left: T, right: T) -> bool:
        """Equality order over a finite carrier."""

        if left not in self.elements or right not in self.elements:
            return False
        return left == right
