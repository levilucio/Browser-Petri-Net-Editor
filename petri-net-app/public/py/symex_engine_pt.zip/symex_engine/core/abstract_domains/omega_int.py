"""
ω-extended integers (OmegaInt).

This is the smallest shared abstraction that appears across multiple kernel
instantiations:
- Petri nets: Karp-Miller acceleration promotes increasing components to ω.
- Mini-Lisp: list-length abstraction naturally uses a finite set {0..k, ω}.

We keep the API intentionally minimal so each instantiation can decide:
- its allowed range (e.g., non-negative only),
- its widening strategy (thresholds vs direct ω-promotion),
- and how it maps to subsumption.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True, order=False)
class OmegaInt:
    """
    Integer extended with a top element ω.

    Representation:
    - value=None denotes ω
    - value=int denotes a finite integer
    """

    value: Optional[int]

    @staticmethod
    def omega() -> "OmegaInt":
        return OmegaInt(None)

    @staticmethod
    def finite(n: int) -> "OmegaInt":
        return OmegaInt(n)

    def is_omega(self) -> bool:
        return self.value is None

    def unwrap_finite(self) -> int:
        if self.value is None:
            raise ValueError("Cannot unwrap ω")
        return self.value

    def __str__(self) -> str:
        # Use ASCII for portability across Windows consoles / codepages.
        return "omega" if self.value is None else str(self.value)

    def __repr__(self) -> str:
        return f"OmegaInt({self.value!r})"

    # -----------------------------
    # Order (≤) with ω as top
    # -----------------------------
    def le(self, other: "OmegaInt") -> bool:
        if other.value is None:
            return True
        if self.value is None:
            return False
        return self.value <= other.value

    def leq(self, other: "OmegaInt") -> bool:
        """Alias matching the shared preorder protocol."""

        return self.le(other)

    # Python operators for convenience
    def __le__(self, other: object) -> bool:
        if not isinstance(other, OmegaInt):
            return NotImplemented
        return self.le(other)

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, OmegaInt):
            return NotImplemented
        return self <= other and self != other

    # -----------------------------
    # Arithmetic (ω propagates)
    # -----------------------------
    def add(self, other: "OmegaInt") -> "OmegaInt":
        if self.value is None or other.value is None:
            return OmegaInt.omega()
        return OmegaInt.finite(self.value + other.value)

    def sub_finite(self, n: int) -> "OmegaInt":
        """
        Subtract a finite integer from an OmegaInt.

        Note: This does NOT clamp. Instantiations can clamp to 0 if they want.
        """
        if self.value is None:
            return OmegaInt.omega()
        return OmegaInt.finite(self.value - n)

    # -----------------------------
    # Widening helpers
    # -----------------------------
    @staticmethod
    def widen_to_omega_if_increasing(prev: "OmegaInt", new: "OmegaInt") -> "OmegaInt":
        """
        Karp-Miller-style widening for ω-promotion:
        - if new > prev, return ω
        - otherwise keep new (more precise or equal)
        """
        if prev.value is None:
            return OmegaInt.omega()
        if new.value is None:
            return OmegaInt.omega()
        if new.value > prev.value:
            return OmegaInt.omega()
        return OmegaInt.finite(new.value)

