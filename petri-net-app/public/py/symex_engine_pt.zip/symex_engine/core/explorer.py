"""Generic worklist exploration algorithm.

Concrete instantiations provide a small adapter: initial states, successor
generation, signatures, optional abstraction, optional keyed subsumption, and
optional path-local ancestor covering. The core owns the proof-critical shell:
worklist discipline, memoization, graph construction, parent traces, bounds,
and pruning.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Generic, Hashable, Iterable, Literal, Protocol, TypeVar

from symex_engine.core.graph import CoreGraph
from symex_engine.core.order import AntichainIndex


StateT = TypeVar("StateT")
LabelT = TypeVar("LabelT")

SearchOrder = Literal["bfs", "dfs"]
SubsumptionMode = Literal["none", "antichain"]


@dataclass(frozen=True)
class CoreStep(Generic[StateT, LabelT]):
    """One domain transition returned by an adapter."""

    state: StateT
    label: LabelT
    flags: frozenset[str] = frozenset()


@dataclass(frozen=True)
class ExplorationContext(Generic[StateT, LabelT]):
    """Context passed to abstraction hooks."""

    source_id: int
    source_state: StateT
    step_label: LabelT
    depth: int
    ancestor_chain: tuple[tuple[int, StateT], ...] = ()


class ExplorationAdapter(Protocol[StateT, LabelT]):
    """Domain interface consumed by :class:`CoreExplorer`."""

    def initial_states(self) -> Iterable[StateT]:
        ...

    def successors(self, state: StateT) -> Iterable[CoreStep[StateT, LabelT]]:
        ...

    def signature(self, state: StateT) -> Hashable:
        ...

    def is_terminal(self, state: StateT) -> bool:
        return False

    def abstract_successor(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> StateT:
        return state

    def subsumption_key(self, state: StateT) -> Hashable | None:
        return None

    def subsumes(self, existing: StateT, candidate: StateT) -> bool:
        return False

    def subsumed_by_ancestor(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> int | None:
        return None

    def extra_edge_flags(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> frozenset[str]:
        return frozenset()


@dataclass(frozen=True)
class ExplorerConfig:
    """Bounds and scheduling policy for core exploration.

    Set ``subsumption="antichain"`` to maintain a keyed antichain using the
    adapter's ``subsumption_key`` and ``subsumes`` hooks.
    """

    max_nodes: int = 10_000
    max_steps: int = 100_000
    search_order: SearchOrder = "bfs"
    subsumption: SubsumptionMode = "none"
    use_subsumption: bool | None = None

    def __post_init__(self) -> None:
        # Backwards-compatible shim for callers that still pass the old boolean.
        if self.use_subsumption is not None:
            object.__setattr__(
                self,
                "subsumption",
                "antichain" if self.use_subsumption else "none",
            )


@dataclass(frozen=True)
class ExplorationStats:
    steps: int = 0
    nodes: int = 0
    edges: int = 0
    exact_hits: int = 0
    subsumed: int = 0
    antichain_pruned: int = 0
    truncated: bool = False
    subsumption: SubsumptionMode = "none"


@dataclass
class CoreExplorationResult(Generic[StateT, LabelT]):
    graph: CoreGraph[StateT, LabelT]
    terminal_ids: list[int] = field(default_factory=list)
    stats: ExplorationStats = field(default_factory=ExplorationStats)


class CoreExplorer(Generic[StateT, LabelT]):
    """Reusable subsumption-aware symbolic/exploration worklist."""

    def __init__(
        self,
        adapter: ExplorationAdapter[StateT, LabelT],
        *,
        config: ExplorerConfig | None = None,
    ) -> None:
        self.adapter = adapter
        self.config = config or ExplorerConfig()

    def _is_terminal(self, state: StateT) -> bool:
        method = getattr(self.adapter, "is_terminal", None)
        return bool(method(state)) if method is not None else False

    def _abstract_successor(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> StateT:
        method = getattr(self.adapter, "abstract_successor", None)
        return method(state, context) if method is not None else state

    def _subsumption_key(self, state: StateT) -> Hashable | None:
        method = getattr(self.adapter, "subsumption_key", None)
        return method(state) if method is not None else None

    def _subsumes(self, existing: StateT, candidate: StateT) -> bool:
        method = getattr(self.adapter, "subsumes", None)
        return bool(method(existing, candidate)) if method is not None else False

    def _subsumed_by_ancestor(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> int | None:
        method = getattr(self.adapter, "subsumed_by_ancestor", None)
        return method(state, context) if method is not None else None

    def _extra_edge_flags(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> frozenset[str]:
        method = getattr(self.adapter, "extra_edge_flags", None)
        return method(state, context) if method is not None else frozenset()

    def _ancestor_chain(
        self,
        graph: CoreGraph[StateT, LabelT],
        node_id: int,
    ) -> tuple[tuple[int, StateT], ...]:
        chain_rev: list[tuple[int, StateT]] = []
        cur = node_id
        while True:
            chain_rev.append((cur, graph.nodes[cur].state))
            if cur not in graph.parent:
                break
            cur, _ = graph.parent[cur]
        chain_rev.reverse()
        return tuple(chain_rev)

    def explore(self) -> CoreExplorationResult[StateT, LabelT]:
        graph: CoreGraph[StateT, LabelT] = CoreGraph()
        seen: dict[Hashable, int] = {}
        depths: dict[int, int] = {}
        work: deque[int] = deque()
        terminal_ids: list[int] = []
        antichain: AntichainIndex[StateT] | None = (
            AntichainIndex(self._subsumes) if self.config.subsumption == "antichain" else None
        )

        steps = 0
        exact_hits = 0
        subsumed = 0
        antichain_pruned = 0
        truncated = False

        def add_state(state: StateT, *, depth: int) -> tuple[int, bool]:
            nonlocal truncated
            sig = self.adapter.signature(state)
            existing = seen.get(sig)
            if existing is not None:
                return existing, False

            if len(graph.nodes) >= self.config.max_nodes:
                truncated = True
                return -1, False

            terminal = self._is_terminal(state)
            node_id = graph.add_node(state, sig, terminal=terminal)
            seen[sig] = node_id
            depths[node_id] = depth
            if terminal:
                terminal_ids.append(node_id)
            else:
                work.append(node_id)

            if antichain is not None:
                key = self._subsumption_key(state)
                if key is not None:
                    antichain.add(key, state, node_id)
            return node_id, True

        for initial in self.adapter.initial_states():
            node_id, created = add_state(initial, depth=0)
            if node_id >= 0 and created:
                graph.initial_ids.append(node_id)

        while work:
            if steps >= self.config.max_steps:
                truncated = True
                break

            src_id = work.popleft() if self.config.search_order == "bfs" else work.pop()
            src_node = graph.nodes[src_id]
            src_state = src_node.state
            ancestor_chain = self._ancestor_chain(graph, src_id)

            for step in self.adapter.successors(src_state):
                if steps >= self.config.max_steps:
                    truncated = True
                    break
                steps += 1

                context = ExplorationContext(
                    source_id=src_id,
                    source_state=src_state,
                    step_label=step.label,
                    depth=depths[src_id] + 1,
                    ancestor_chain=ancestor_chain,
                )
                candidate = self._abstract_successor(step.state, context)

                flags = step.flags | self._extra_edge_flags(candidate, context)

                covered_by = self._subsumed_by_ancestor(candidate, context)
                if covered_by is not None:
                    subsumed += 1
                    graph.add_edge(
                        src_id,
                        covered_by,
                        step.label,
                        flags=flags | frozenset({"subsumed"}),
                        record_parent=False,
                    )
                    continue

                sig = self.adapter.signature(candidate)
                dst_id = seen.get(sig)
                if dst_id is not None:
                    exact_hits += 1
                    graph.add_edge(src_id, dst_id, step.label, flags=flags, record_parent=False)
                    continue

                if antichain is not None:
                    key = self._subsumption_key(candidate)
                    if key is not None:
                        covered_by = antichain.find_covering(key, candidate)
                        if covered_by is not None:
                            subsumed += 1
                            antichain_pruned += 1
                            graph.add_edge(
                                src_id,
                                covered_by,
                                step.label,
                                flags=flags | frozenset({"subsumed"}),
                                record_parent=False,
                            )
                            continue

                dst_id, created = add_state(candidate, depth=depths[src_id] + 1)
                if dst_id < 0:
                    continue
                graph.add_edge(src_id, dst_id, step.label, flags=flags)

            if truncated:
                break

        return CoreExplorationResult(
            graph=graph,
            terminal_ids=terminal_ids,
            stats=ExplorationStats(
                steps=steps,
                nodes=len(graph.nodes),
                edges=len(graph.edges),
                exact_hits=exact_hits,
                subsumed=subsumed,
                antichain_pruned=antichain_pruned,
                truncated=truncated,
                subsumption=self.config.subsumption,
            ),
        )
