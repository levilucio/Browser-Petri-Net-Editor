"""Finite-graph value interpretations over completed core explorations.

The exploration theorem builds a sound support graph.  This module owns a
separate, reusable layer for interpreting that graph in a value domain: Boolean
reachability, DTMC probabilities, MDP min/max probabilities, costs, rewards, and
similar finite-graph fixed points all fit this shape.
"""

from __future__ import annotations

from collections.abc import Callable, Hashable
from dataclasses import dataclass
from typing import Literal, TypeVar

from symex_engine.core.explorer import CoreExplorationResult
from symex_engine.core.graph import CoreEdge


StateT = TypeVar("StateT")
LabelT = TypeVar("LabelT")
NodePredicate = Callable[[StateT], bool]
ProbabilityProjection = Callable[[CoreEdge[LabelT]], float]
ActionProjection = Callable[[CoreEdge[LabelT]], Hashable]
Optimization = Literal["min", "max"]


@dataclass(frozen=True)
class LinearReachabilityInterpretation:
    """Least DTMC reachability solution over a finite support graph."""

    values: dict[int, float]


@dataclass(frozen=True)
class BellmanReachabilityInterpretation:
    """Least/fixed-point MDP reachability solution over a finite support graph."""

    values: dict[int, float]
    iterations: int
    converged: bool


def matching_nodes(
    exploration: CoreExplorationResult[StateT, LabelT],
    predicate: NodePredicate[StateT],
) -> tuple[int, ...]:
    """Return node ids whose states satisfy ``predicate``."""

    return tuple(
        node_id
        for node_id, node in sorted(exploration.graph.nodes.items())
        if predicate(node.state)
    )


def initial_value(
    exploration: CoreExplorationResult[StateT, LabelT],
    values: dict[int, float],
) -> float | None:
    """Return the unique initial-node value, or ``None`` for multi-initial graphs."""

    initial_values = [values[node_id] for node_id in exploration.graph.initial_ids]
    return initial_values[0] if len(initial_values) == 1 else None


def solve_linear_reachability(
    exploration: CoreExplorationResult[StateT, LabelT],
    target_nodes: frozenset[int],
    *,
    probability: ProbabilityProjection[LabelT],
    tolerance: float,
) -> LinearReachabilityInterpretation:
    """Solve ``P[F target]`` for a finite DTMC support graph.

    Target nodes have value 1.  Terminal non-target states and closed
    non-target classes receive the least solution 0.
    """

    node_ids = tuple(sorted(exploration.graph.nodes))
    unknowns = tuple(node_id for node_id in node_ids if node_id not in target_nodes)
    index = {node_id: row for row, node_id in enumerate(unknowns)}
    size = len(unknowns)
    matrix = [[0.0 for _ in range(size)] for _ in range(size)]
    rhs = [0.0 for _ in range(size)]

    outgoing: dict[int, list[tuple[int, float]]] = {node_id: [] for node_id in node_ids}
    for edge in exploration.graph.edges:
        outgoing.setdefault(edge.src, []).append((edge.dst, probability(edge)))

    for node_id in unknowns:
        row = index[node_id]
        matrix[row][row] = 1.0
        for dst, edge_probability in outgoing.get(node_id, ()):
            if dst in target_nodes:
                rhs[row] += edge_probability
            else:
                matrix[row][index[dst]] -= edge_probability

    solution = gaussian_elimination(matrix, rhs, tolerance=tolerance)
    values = {node_id: 1.0 for node_id in target_nodes}
    for node_id, value in zip(unknowns, solution, strict=True):
        values[node_id] = clamp_probability(value, tolerance)
    return LinearReachabilityInterpretation(values=values)


def value_iterate_bellman_reachability(
    exploration: CoreExplorationResult[StateT, LabelT],
    target_nodes: frozenset[int],
    *,
    probability: ProbabilityProjection[LabelT],
    action: ActionProjection[LabelT],
    optimization: Optimization,
    tolerance: float,
    max_iterations: int,
) -> BellmanReachabilityInterpretation:
    """Solve min/max ``P[F target]`` by Bellman value iteration."""

    if optimization not in {"min", "max"}:
        raise ValueError("optimization must be 'min' or 'max'")

    node_ids = tuple(sorted(exploration.graph.nodes))
    values = {node_id: (1.0 if node_id in target_nodes else 0.0) for node_id in node_ids}
    actions_by_node = grouped_distributions(
        exploration,
        action=action,
        probability=probability,
    )

    for iteration in range(1, max_iterations + 1):
        delta = 0.0
        new_values = dict(values)
        for node_id in node_ids:
            if node_id in target_nodes:
                continue
            distributions = actions_by_node.get(node_id)
            if not distributions:
                new_values[node_id] = 0.0
                continue

            action_values = [
                sum(edge_probability * values[dst] for dst, edge_probability in distribution)
                for distribution in distributions.values()
            ]
            next_value = max(action_values) if optimization == "max" else min(action_values)
            next_value = clamp_probability(next_value, tolerance)
            delta = max(delta, abs(next_value - values[node_id]))
            new_values[node_id] = next_value
        values = new_values
        if delta <= tolerance:
            return BellmanReachabilityInterpretation(
                values=values,
                iterations=iteration,
                converged=True,
            )

    return BellmanReachabilityInterpretation(
        values=values,
        iterations=max_iterations,
        converged=False,
    )


def grouped_distributions(
    exploration: CoreExplorationResult[StateT, LabelT],
    *,
    action: ActionProjection[LabelT],
    probability: ProbabilityProjection[LabelT],
) -> dict[int, dict[Hashable, list[tuple[int, float]]]]:
    """Group outgoing probabilistic edges by scheduler-visible action."""

    grouped: dict[int, dict[Hashable, list[tuple[int, float]]]] = {}
    for edge in exploration.graph.edges:
        grouped.setdefault(edge.src, {}).setdefault(action(edge), []).append(
            (edge.dst, probability(edge)),
        )
    return grouped


def gaussian_elimination(
    matrix: list[list[float]],
    rhs: list[float],
    *,
    tolerance: float,
) -> list[float]:
    """Solve a dense linear system in-place with tolerant zero pivots."""

    size = len(rhs)
    if size == 0:
        return []

    for col in range(size):
        pivot = max(range(col, size), key=lambda row: abs(matrix[row][col]))
        if abs(matrix[pivot][col]) <= tolerance:
            # A singular row corresponds to a bottom non-target class. The least
            # reachability solution assigns it probability 0, which the zero row
            # already represents after elimination.
            continue
        if pivot != col:
            matrix[col], matrix[pivot] = matrix[pivot], matrix[col]
            rhs[col], rhs[pivot] = rhs[pivot], rhs[col]

        pivot_value = matrix[col][col]
        for entry in range(col, size):
            matrix[col][entry] /= pivot_value
        rhs[col] /= pivot_value

        for row in range(size):
            if row == col:
                continue
            factor = matrix[row][col]
            if abs(factor) <= tolerance:
                continue
            for entry in range(col, size):
                matrix[row][entry] -= factor * matrix[col][entry]
            rhs[row] -= factor * rhs[col]

    return rhs


def clamp_probability(value: float, tolerance: float) -> float:
    """Normalize small floating-point probability drift at the unit interval."""

    if -tolerance <= value <= 0.0:
        return 0.0
    if 1.0 <= value <= 1.0 + tolerance:
        return 1.0
    return value

