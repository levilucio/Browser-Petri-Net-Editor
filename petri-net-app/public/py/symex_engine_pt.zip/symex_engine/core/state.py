"""
Symbolic Execution Core - Kernel State Representation

This module provides the full (U, S, Θ) symbolic state representation
for kernel instantiations that require symbolic variables and constraints.

Used by:
  - TIL (Tiny Imperative Language): Full symbolic execution with SMT solving
  - Mini-Promela (future): Symbolic extension for parameterized models

Not used by:
  - P/T nets: Uses concrete Marking tuples (U=∅, Θ=∅), see petri_net/pt_model.py

Instantiations with purely concrete state spaces (no symbolic variables or
constraints) may use domain-specific representations for performance.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping

import z3

from .z3_backend import SymbolFactory, simplify


@dataclass(frozen=True)
class SymbolicState:
    """
    Kernel view: (U, S, Θ)
      - U: SymbolFactory.universe (set of fresh symbolic variables)
      - S: env (program variables -> Z3 expressions)
      - Θ: constraints (list of Z3 Bool expressions representing path conditions)
    """

    env: Mapping[str, z3.ExprRef] = field(default_factory=dict)
    constraints: tuple[z3.BoolRef, ...] = field(default_factory=tuple)
    factory: SymbolFactory = field(default_factory=SymbolFactory)

    def with_env(self, **updates: z3.ExprRef) -> "SymbolicState":
        new_env = dict(self.env)
        new_env.update(updates)
        return SymbolicState(env=new_env, constraints=self.constraints, factory=self.factory)

    def add_constraint(self, c: z3.BoolRef) -> "SymbolicState":
        c_s = simplify(c)
        return SymbolicState(env=dict(self.env), constraints=self.constraints + (c_s,), factory=self.factory)

    def pretty_env(self) -> str:
        items = ", ".join(f"{k}={self.env[k]}" for k in sorted(self.env.keys()))
        return "{" + items + "}"

    def signature(self) -> tuple[tuple[tuple[str, str], ...], tuple[str, ...]]:
        """
        A syntactic signature used for memoization in the MVP.
        (Later we can replace with semantic subsumption.)
        """
        env_sig = tuple((k, str(self.env[k])) for k in sorted(self.env.keys()))
        th_sig = tuple(str(c) for c in self.constraints)
        return env_sig, th_sig



