"""Generic exploration graph data structures.

The domain-specific graph renderers in the instantiations remain useful, but
the core exploration algorithm needs one small common representation for node
allocation, edges, parent links, and witness reconstruction.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Generic, Hashable, TypeVar


StateT = TypeVar("StateT")
LabelT = TypeVar("LabelT")


@dataclass(frozen=True)
class CoreNode(Generic[StateT]):
    """A reached state in a core exploration graph."""

    id: int
    state: StateT
    signature: Hashable
    terminal: bool = False


@dataclass(frozen=True)
class CoreEdge(Generic[LabelT]):
    """A labeled edge between two reached states."""

    src: int
    dst: int
    label: LabelT
    flags: frozenset[str] = frozenset()


@dataclass
class CoreGraph(Generic[StateT, LabelT]):
    """A dense-id graph produced by the generic explorer."""

    nodes: dict[int, CoreNode[StateT]] = field(default_factory=dict)
    edges: list[CoreEdge[LabelT]] = field(default_factory=list)
    initial_ids: list[int] = field(default_factory=list)
    parent: dict[int, tuple[int, LabelT]] = field(default_factory=dict)

    def add_node(self, state: StateT, signature: Hashable, *, terminal: bool = False) -> int:
        node_id = len(self.nodes)
        self.nodes[node_id] = CoreNode(node_id, state, signature, terminal)
        return node_id

    def add_edge(
        self,
        src: int,
        dst: int,
        label: LabelT,
        *,
        flags: frozenset[str] = frozenset(),
        record_parent: bool = True,
    ) -> None:
        self.edges.append(CoreEdge(src=src, dst=dst, label=label, flags=flags))
        if record_parent:
            self.parent.setdefault(dst, (src, label))

    def trace_to(self, target: int) -> list[LabelT]:
        """Return the first discovered label trace from an initial node to ``target``."""

        out: list[LabelT] = []
        cur = target
        while cur in self.parent:
            prev, label = self.parent[cur]
            out.append(label)
            cur = prev
        out.reverse()
        return out
