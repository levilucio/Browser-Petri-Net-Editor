"""Reusable ordering and antichain helpers for kernel instantiations."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from itertools import permutations
from typing import Callable, Generic, Hashable, Protocol, TypeVar

import z3

from symex_engine.core.z3_backend import conjoin, entails


StateT = TypeVar("StateT")
ElemT = TypeVar("ElemT")


class Preorder(Protocol[StateT]):
    """A reflexive/transitive order used for subsumption or WQO witnesses."""

    def leq(self, left: StateT, right: StateT) -> bool:
        """Return ``True`` iff ``left <= right`` in the domain order."""


@dataclass(frozen=True)
class SubsumptionSpec(Generic[StateT]):
    """Reusable adapter for keyed subsumption hooks.

    ``key`` defines the bucket in which two states may be compared. ``covers``
    is only asked when existing and candidate states share a non-``None`` key.
    """

    key: Callable[[StateT], Hashable | None]
    covers: Callable[[StateT, StateT], bool]

    def subsumption_key(self, state: StateT) -> Hashable | None:
        return self.key(state)

    def subsumes(self, existing: StateT, candidate: StateT) -> bool:
        existing_key = self.key(existing)
        candidate_key = self.key(candidate)
        if existing_key is None or existing_key != candidate_key:
            return False
        return self.covers(existing, candidate)


def preorder_subsumption(
    key: Callable[[StateT], Hashable | None],
    preorder: Preorder[StateT] | Callable[[StateT, StateT], bool],
) -> SubsumptionSpec[StateT]:
    """Lift a preorder into the ``ExplorationAdapter`` subsumption shape."""

    if callable(preorder):
        covers = preorder
    else:
        covers = preorder.leq
    return SubsumptionSpec(key=key, covers=covers)


def smt_entailment_covers(
    constraints: Callable[[StateT], Iterable[z3.BoolRef]],
    *,
    bindings: Callable[[StateT], Mapping[Hashable, z3.ExprRef]] | None = None,
) -> Callable[[StateT, StateT], bool]:
    """Build a Z3-backed cover predicate for symbolic states.

    ``existing`` covers ``candidate`` when the candidate's path constraints
    entail the existing state's constraints.  When ``bindings`` is supplied,
    both states must expose the same binding keys and the candidate constraints
    must also entail pointwise equality of candidate and existing bindings.
    """

    def covers(existing: StateT, candidate: StateT) -> bool:
        conclusion_parts = list(constraints(existing))
        if bindings is not None:
            existing_bindings = bindings(existing)
            candidate_bindings = bindings(candidate)
            if set(existing_bindings) != set(candidate_bindings):
                return False
            for name in sorted(existing_bindings, key=str):
                conclusion_parts.append(candidate_bindings[name] == existing_bindings[name])
        return entails(tuple(constraints(candidate)), conjoin(conclusion_parts))

    return covers


def smt_entailment_subsumption(
    key: Callable[[StateT], Hashable | None],
    constraints: Callable[[StateT], Iterable[z3.BoolRef]],
    *,
    bindings: Callable[[StateT], Mapping[Hashable, z3.ExprRef]] | None = None,
) -> SubsumptionSpec[StateT]:
    """Lift SMT entailment into the ``ExplorationAdapter`` subsumption shape."""

    return SubsumptionSpec(
        key=key,
        covers=smt_entailment_covers(constraints, bindings=bindings),
    )


def product_leq(
    left: tuple[StateT, ...],
    right: tuple[StateT, ...],
    leq: Callable[[StateT, StateT], bool],
) -> bool:
    """Pointwise order on fixed-length products."""

    return len(left) == len(right) and all(leq(a, b) for a, b in zip(left, right, strict=True))


def pointwise_map_leq(
    left: dict[Hashable, StateT],
    right: dict[Hashable, StateT],
    leq: Callable[[StateT, StateT], bool],
) -> bool:
    """Pointwise order on maps with identical key sets."""

    if set(left) != set(right):
        return False
    return all(leq(left[k], right[k]) for k in left)


def subword_leq(small: Sequence[ElemT], big: Sequence[ElemT]) -> bool:
    """Higman subword (subsequence) order on finite sequences.

    Return ``True`` iff ``small`` embeds into ``big`` as a (not necessarily
    contiguous) order-preserving subsequence.  Over a finite alphabet this is a
    well-quasi-order by Higman's lemma: it admits no infinite antichain and no
    infinite strictly descending chain.  An adapter that keys by a finite control
    and orders unbounded sequence-shaped state (FIFO channels, queues, words) by
    ``subword_leq`` therefore supplies a valid WQO witness for the kernel's
    termination theorem.  It composes with :func:`product_leq` to order a fixed
    tuple of sequences and with :func:`pointwise_map_leq` to order a named family
    of them.
    """

    big_iter = iter(big)
    for element in small:
        for item in big_iter:
            if item == element:
                break
        else:
            return False
    return True


def bounded_bag_cover(
    existing: Sequence[ElemT],
    candidate: Sequence[ElemT],
    aligned_cover: Callable[[tuple[tuple[ElemT, ElemT], ...]], bool],
) -> bool:
    """Cover order on bounded (symbolic) multisets.

    ``existing`` covers ``candidate`` iff the two bags have equal cardinality and
    some bijection aligns candidate elements to existing elements such that
    ``aligned_cover`` holds on the aligned ``(existing, candidate)`` pairs.

    Because the bag size is bounded, the bijection search is finite.  The element
    type is opaque: for symbolic domains ``aligned_cover`` typically reduces the
    whole alignment to one SMT entailment between the two states' constraint
    stores (so the bag tokens are matched by value, not by identity).  This is
    the multiset analogue of :func:`smt_entailment_subsumption`'s ``bindings``.
    """

    if len(existing) != len(candidate):
        return False
    size = len(existing)
    if size == 0:
        return aligned_cover(())
    for perm in permutations(range(size)):
        pairs = tuple((existing[perm[index]], candidate[index]) for index in range(size))
        if aligned_cover(pairs):
            return True
    return False


@dataclass
class AntichainIndex(Generic[StateT]):
    """Bucketed antichain for subsumption pruning.

    ``covers(a, b)`` should mean that existing element ``a`` represents a
    superset of the behaviours represented by candidate ``b``.
    """

    covers: Callable[[StateT, StateT], bool]
    buckets: dict[Hashable, list[tuple[StateT, int]]] = field(default_factory=dict)

    def find_covering(self, key: Hashable, candidate: StateT) -> int | None:
        for old, node_id in self.buckets.get(key, []):
            if self.covers(old, candidate):
                return node_id
        return None

    def add(self, key: Hashable, state: StateT, node_id: int) -> None:
        self.buckets.setdefault(key, []).append((state, node_id))
