"""
Partial-Order Reduction (POR) - Core Module

This module provides the common abstractions for Partial-Order Reduction
that can be instantiated by different kernel implementations:
  - Mini-Promela: Variables and statements
  - P/T Nets: Places and transitions

The key abstractions are:
  - ActionFootprint: Captures what resources an action reads/writes
  - Independence relation: Two actions are independent if they don't conflict
  - Ample set computation: Select a subset of enabled actions to explore

References:
  - Peled, D. (1996). Partial-order reduction.
  - Godefroid, P. (1996). Partial-order methods for model checking.
  - main.tex Section 11: Confluence Modulo Constraints
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Generic, TypeVar, Sequence

# Type variable for resource identifiers (e.g., variable names, place indices)
ResourceId = TypeVar("ResourceId")


# =============================================================================
# Action Footprint - Abstract Base
# =============================================================================

@dataclass(frozen=True)
class ActionFootprint(Generic[ResourceId]):
    """
    Abstract footprint of an action (transition/statement).
    
    The footprint captures:
      - reads: Resources whose values affect the action's outcome
      - writes: Resources modified by the action
      - guard_reads: Resources read in the enabling condition (subset of reads)
      - action_id: Identifier for the action (e.g., branch index, transition index)
    
    Kernel mapping:
      - For Mini-Promela: ResourceId = str (variable names)
      - For P/T Nets: ResourceId = int (place indices)
    """
    reads: frozenset[ResourceId]
    writes: frozenset[ResourceId]
    guard_reads: frozenset[ResourceId]
    action_id: int | None = None
    
    @property
    def all_reads(self) -> frozenset[ResourceId]:
        """All resources read (guard + body)."""
        return self.reads | self.guard_reads
    
    def conflicts_with(self, other: ActionFootprint[ResourceId]) -> bool:
        """
        Check if two actions conflict (are NOT independent).
        
        Actions conflict if:
          - One writes a resource the other reads (data dependency)
          - One writes a resource the other writes (output dependency)
        
        Definition (from main.tex Section 11):
        Conflict(α₁, α₂) ⟺ Write(α₁) ∩ (Read(α₂) ∪ Write(α₂)) ≠ ∅ ∨
                           Write(α₂) ∩ (Read(α₁) ∪ Write(α₁)) ≠ ∅
        """
        # Write-Read conflict: self writes something other reads
        if self.writes & other.all_reads:
            return True
        # Read-Write conflict: self reads something other writes
        if self.all_reads & other.writes:
            return True
        # Write-Write conflict: both write the same resource
        if self.writes & other.writes:
            return True
        return False
    
    def is_visible(self, visible_resources: frozenset[ResourceId]) -> bool:
        """Check if this action modifies any visible resource."""
        return bool(self.writes & visible_resources)


def are_independent(
    fp1: ActionFootprint[ResourceId],
    fp2: ActionFootprint[ResourceId]
) -> bool:
    """
    Check if two actions are independent.
    
    Definition (from main.tex Section 11):
    Indep(α₁, α₂) ⟺ ¬Conflict(α₁, α₂)
    
    Independent actions commute: executing them in either order yields
    equivalent results (modulo constraint equivalence).
    """
    return not fp1.conflicts_with(fp2)


# =============================================================================
# Ample Set Computation
# =============================================================================

@dataclass
class AmpleSetResult:
    """Result of ample set computation."""
    ample_indices: frozenset[int]  # Indices of actions in the ample set
    is_full: bool  # True if ample set = all enabled (no reduction)
    reduction_reason: str  # Human-readable reason for reduction


def compute_ample_set(
    enabled_footprints: Sequence[ActionFootprint[ResourceId]],
    *,
    visible_resources: frozenset[ResourceId] = frozenset(),
) -> AmpleSetResult:
    """
    Compute an ample set for partial-order reduction.
    
    An ample set A ⊆ enabled must satisfy:
    1. A ≠ ∅ (non-empty)
    2. For all α ∈ A and β ∉ A: α and β are independent
       (C1: ample set is closed under non-independence)
    3. If A ≠ enabled, then all actions in A are invisible
       (C2: invisibility condition - actions don't modify visible_resources)
    4. (Simplified progress) If there are visible actions among enabled,
       include at least one visible action to ensure progress on properties
    
    Args:
        enabled_footprints: Footprints of enabled actions
        visible_resources: Resources mentioned in specifications
                           (actions modifying these are "visible")
    
    For simplicity, we use a greedy algorithm:
    - Start with first enabled action
    - Add all actions that conflict with current set
    - Repeat until closed
    - Respect visibility and progress conditions
    
    Returns the ample set result with indices into enabled_footprints.
    """
    if not enabled_footprints:
        return AmpleSetResult(frozenset(), True, "no enabled actions")
    
    n = len(enabled_footprints)
    
    if n == 1:
        return AmpleSetResult(frozenset({0}), True, "single action")
    
    # Check if there are any visible actions among enabled
    has_visible_action = visible_resources and any(
        fp.is_visible(visible_resources) for fp in enabled_footprints
    )
    
    # If there are visible actions and we need to preserve EF/EG witnesses,
    # we must include ALL visible actions in any reduction.
    # For simplicity and soundness, if there are visible actions, don't reduce.
    if has_visible_action:
        return AmpleSetResult(
            frozenset(range(n)), 
            True, 
            "visible actions present - no reduction for CTL soundness"
        )
    
    # No visible actions - safe to apply POR
    # Try each action as a seed for a potential ample set
    best_ample: frozenset[int] | None = None
    
    for seed in range(n):
        # Start with seed action
        ample: set[int] = {seed}
        changed = True
        
        # Grow ample set until closed under conflicts
        while changed:
            changed = False
            for i in range(n):
                if i in ample:
                    continue
                # Check if action i conflicts with any action in ample
                for j in ample:
                    if enabled_footprints[i].conflicts_with(enabled_footprints[j]):
                        ample.add(i)
                        changed = True
                        break
        
        # Check if this ample set is smaller than previous best
        if best_ample is None or len(ample) < len(best_ample):
            best_ample = frozenset(ample)
            
            # If we found a singleton, that's optimal
            if len(ample) == 1:
                break
    
    assert best_ample is not None
    
    if len(best_ample) == n:
        return AmpleSetResult(best_ample, True, "all actions conflict")
    
    reduction = n - len(best_ample)
    return AmpleSetResult(
        best_ample, 
        False, 
        f"reduced from {n} to {len(best_ample)} actions (saved {reduction})"
    )


# =============================================================================
# Visibility Analysis - Abstract Interface
# =============================================================================

class VisibilityAnalyzer(ABC, Generic[ResourceId]):
    """
    Abstract interface for extracting visible resources from specifications.
    
    Each kernel instantiation defines what "visible" means for its specification
    language (CTL formulas, marking predicates, etc.).
    """
    
    @abstractmethod
    def extract_visible_resources(self) -> frozenset[ResourceId]:
        """Extract all resources mentioned in specifications."""
        ...


# =============================================================================
# POR Statistics
# =============================================================================

@dataclass
class PORStats:
    """Statistics about POR effectiveness during exploration."""
    total_choice_points: int = 0  # Number of times POR was considered
    reduced_choice_points: int = 0  # Number of times POR actually reduced
    total_enabled: int = 0  # Total enabled actions across all choice points
    total_explored: int = 0  # Total actions actually explored (after POR)
    
    def reduction_ratio(self) -> float:
        """Ratio of explored to enabled (1.0 = no reduction, 0.0 = max reduction)."""
        if self.total_enabled == 0:
            return 1.0
        return self.total_explored / self.total_enabled
    
    def choice_point_reduction_rate(self) -> float:
        """Fraction of choice points that were reduced."""
        if self.total_choice_points == 0:
            return 0.0
        return self.reduced_choice_points / self.total_choice_points
