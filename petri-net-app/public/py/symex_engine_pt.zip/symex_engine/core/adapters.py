"""Reusable adapter wrappers for ``CoreExplorer``."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Generic, Hashable, TypeVar

from symex_engine.core.explorer import CoreStep, ExplorationAdapter, ExplorationContext


StateT = TypeVar("StateT")
LabelT = TypeVar("LabelT")


class FiniteImageAbstraction(Generic[StateT, LabelT]):
    """State-local A3 abstraction helper for finite-image normalizers.

    Contract for ``normalize``:

    * extensiveness: the denotation of ``state`` is contained in the denotation
      of ``normalize(state)``;
    * finite image: at each relevant control key, only finitely many normalized
      states are reachable up to the adapter's subsumption relation.

    The helper does not prove those facts; it centralizes the common application
    pattern used by domain abstractions such as timed-zone extrapolation and
    value-domain clamping.
    """

    def __init__(
        self,
        normalize: Callable[[StateT], StateT],
        *,
        enabled: bool = True,
        name: str = "finite-image-normalization",
    ) -> None:
        self.normalize = normalize
        self.enabled = enabled
        self.name = name

    def apply(self, state: StateT) -> StateT:
        if not self.enabled:
            return state
        return self.normalize(state)

    def abstract_successor(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> StateT:
        return self.apply(state)


class DepthBoundedAdapter(Generic[StateT, LabelT]):
    """Adapter wrapper that treats states at ``max_depth`` as terminal.

    The wrapper owns the depth bookkeeping for adapters that need bounded
    graph exploration but whose states do not carry depth explicitly.
    """

    def __init__(
        self,
        inner: ExplorationAdapter[StateT, LabelT],
        *,
        max_depth: int | None,
    ) -> None:
        self.inner = inner
        self.max_depth = max_depth
        self._depth_by_signature: dict[Hashable, int] = {}

    def __getattr__(self, name: str) -> object:
        return getattr(self.inner, name)

    def initial_states(self) -> Iterable[StateT]:
        states = tuple(self.inner.initial_states())
        for state in states:
            self._depth_by_signature.setdefault(self.inner.signature(state), 0)
        return states

    def successors(self, state: StateT) -> Iterable[CoreStep[StateT, LabelT]]:
        if self._is_at_depth_bound(state):
            return ()
        return self.inner.successors(state)

    def signature(self, state: StateT) -> Hashable:
        return self.inner.signature(state)

    def is_terminal(self, state: StateT) -> bool:
        if self._is_at_depth_bound(state):
            return True
        method = getattr(self.inner, "is_terminal", None)
        return bool(method(state)) if method is not None else False

    def abstract_successor(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> StateT:
        method = getattr(self.inner, "abstract_successor", None)
        abstracted = method(state, context) if method is not None else state
        self._depth_by_signature.setdefault(self.inner.signature(abstracted), context.depth)
        return abstracted

    def subsumption_key(self, state: StateT) -> Hashable | None:
        method = getattr(self.inner, "subsumption_key", None)
        return method(state) if method is not None else None

    def subsumes(self, existing: StateT, candidate: StateT) -> bool:
        method = getattr(self.inner, "subsumes", None)
        return bool(method(existing, candidate)) if method is not None else False

    def subsumed_by_ancestor(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> int | None:
        method = getattr(self.inner, "subsumed_by_ancestor", None)
        return method(state, context) if method is not None else None

    def extra_edge_flags(
        self,
        state: StateT,
        context: ExplorationContext[StateT, LabelT],
    ) -> frozenset[str]:
        method = getattr(self.inner, "extra_edge_flags", None)
        return method(state, context) if method is not None else frozenset()

    def _is_at_depth_bound(self, state: StateT) -> bool:
        if self.max_depth is None:
            return False
        depth = self._depth_by_signature.get(self.inner.signature(state), 0)
        return depth >= self.max_depth
