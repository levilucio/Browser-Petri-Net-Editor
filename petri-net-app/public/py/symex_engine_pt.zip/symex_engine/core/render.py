"""Generic DOT rendering helpers for exploration graphs."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from typing import Generic, TypeVar

from symex_engine.core.graph import CoreEdge, CoreGraph


StateT = TypeVar("StateT")
LabelT = TypeVar("LabelT")
EdgePayloadT = TypeVar("EdgePayloadT")


def escape_dot_label(value: object) -> str:
    """Escape a value for use as a DOT label."""

    return str(value).replace("\\", "\\\\").replace('"', '\\"')


def render_dot(
    node_ids: Iterable[int],
    edges: Iterable[tuple[int, int, EdgePayloadT]],
    node_label_fn: Callable[[int], object],
    edge_label_fn: Callable[[EdgePayloadT], object],
    *,
    graph_name: str = "G",
    rankdir: str = "LR",
    node_shape_fn: Callable[[int], str] | None = None,
    edge_attrs_fn: Callable[[EdgePayloadT], Mapping[str, object]] | None = None,
) -> str:
    """Render a node/edge view as DOT."""

    lines = [f"digraph {graph_name} {{", f"  rankdir={rankdir};"]
    for node_id in node_ids:
        shape = node_shape_fn(node_id) if node_shape_fn is not None else "ellipse"
        label = escape_dot_label(node_label_fn(node_id))
        lines.append(f'  n{node_id} [shape="{shape}",label="{label}"];')

    for src, dst, payload in edges:
        attrs: dict[str, object] = {"label": edge_label_fn(payload)}
        if edge_attrs_fn is not None:
            attrs.update(edge_attrs_fn(payload))
        attr_text = ",".join(
            f'{name}="{escape_dot_label(value)}"' for name, value in attrs.items()
        )
        lines.append(f"  n{src} -> n{dst} [{attr_text}];")

    lines.append("}")
    return "\n".join(lines)


def to_dot(
    graph: CoreGraph[StateT, LabelT],
    node_label_fn: Callable[[int, StateT], object],
    edge_label_fn: Callable[[CoreEdge[LabelT]], object],
    *,
    graph_name: str = "G",
    rankdir: str = "LR",
    node_shape_fn: Callable[[int, StateT], str] | None = None,
    edge_attrs_fn: Callable[[CoreEdge[LabelT]], Mapping[str, object]] | None = None,
) -> str:
    """Render a ``CoreGraph`` as DOT using domain-supplied formatting hooks."""

    return render_dot(
        sorted(graph.nodes),
        ((edge.src, edge.dst, edge) for edge in graph.edges),
        lambda node_id: node_label_fn(node_id, graph.nodes[node_id].state),
        edge_label_fn,
        graph_name=graph_name,
        rankdir=rankdir,
        node_shape_fn=(
            None
            if node_shape_fn is None
            else lambda node_id: node_shape_fn(node_id, graph.nodes[node_id].state)
        ),
        edge_attrs_fn=edge_attrs_fn,
    )
