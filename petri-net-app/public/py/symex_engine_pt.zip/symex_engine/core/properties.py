"""Generic property queries over a completed core exploration graph.

The explorer owns reachability, parent traces, and truncation reporting.  This
module owns the small, reusable verdict discipline for graph queries that many
adapters otherwise reimplement: existential reachability and universal
invariants over the returned ``CoreExplorationResult``.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable, Generic, Literal, Protocol, TypeAlias, TypeVar

from symex_engine.core.explorer import CoreExplorationResult
from symex_engine.core.graph import CoreEdge


StateT = TypeVar("StateT")
LabelT = TypeVar("LabelT")


class QueryKind(str, Enum):
    """Top-level query shape supported by the reusable verdict algebra."""

    EXISTS = "exists"
    INVARIANT = "invariant"
    EDGE_EXISTS = "edge_exists"
    CTL = "ctl"


class QueryVerdict(str, Enum):
    """Conservative verdicts for graph-property queries."""

    WITNESSED = "witnessed"
    MAY_WITNESSED = "may_witnessed"
    NOT_WITNESSED = "not_witnessed"
    HOLDS = "holds"
    VIOLATED = "violated"
    MAY_VIOLATED = "may_violated"
    INCONCLUSIVE = "inconclusive"


class QueryOutcome(str, Enum):
    """Domain-neutral interpretation of kernel query verdicts."""

    DISCHARGED = "discharged"
    VIOLATED = "violated"
    INCONCLUSIVE = "inconclusive"


class SoundnessClass(str, Enum):
    """How an atom or predicate behaves under abstraction.

    ``EXACT`` is appropriate for exact finite graphs. ``OVERAPPROX_UNIVERSAL_SAFE``
    means successful invariant checks are sound, but violating abstract nodes may
    be spurious. ``UPWARD_CLOSED_COVERABILITY`` is the natural existential class
    for Karp-Miller-style coverability queries. ``MAY_ONLY`` never supports a
    final positive or negative claim without a domain-specific argument.
    """

    EXACT = "exact"
    OVERAPPROX_UNIVERSAL_SAFE = "overapprox_universal_safe"
    UPWARD_CLOSED_COVERABILITY = "upward_closed_coverability"
    MAY_ONLY = "may_only"


@dataclass(frozen=True)
class PropertyQueryResult(Generic[LabelT]):
    """Result of a reusable query over a ``CoreExplorationResult``."""

    kind: QueryKind
    verdict: QueryVerdict
    witness_node: int | None = None
    witness_edge: tuple[int, int] | None = None
    witness_trace: tuple[LabelT, ...] = ()
    matched_nodes: tuple[int, ...] = ()
    matched_edges: tuple[tuple[int, int], ...] = ()
    truncated: bool = False


Predicate = Callable[[StateT], bool]
AtomEvaluator: TypeAlias = Callable[["AtomExpr[AtomT]", StateT], bool]
AtomT = TypeVar("AtomT")


class BoolExpr(Generic[AtomT]):
    """Boolean expression over domain-local atoms."""


@dataclass(frozen=True)
class BoolConst(BoolExpr[AtomT]):
    value: bool


@dataclass(frozen=True)
class AtomExpr(BoolExpr[AtomT]):
    atom: AtomT


@dataclass(frozen=True)
class NotExpr(BoolExpr[AtomT]):
    expr: BoolExpr[AtomT]


@dataclass(frozen=True)
class AndExpr(BoolExpr[AtomT]):
    left: BoolExpr[AtomT]
    right: BoolExpr[AtomT]


@dataclass(frozen=True)
class OrExpr(BoolExpr[AtomT]):
    left: BoolExpr[AtomT]
    right: BoolExpr[AtomT]


@dataclass(frozen=True)
class ImpliesExpr(BoolExpr[AtomT]):
    left: BoolExpr[AtomT]
    right: BoolExpr[AtomT]


def eval_bool_expr(
    expr: BoolExpr[AtomT],
    state: StateT,
    eval_atom: Callable[[AtomT, StateT], bool],
) -> bool:
    """Evaluate a generic Boolean formula using a domain atom evaluator."""

    if isinstance(expr, BoolConst):
        return expr.value
    if isinstance(expr, AtomExpr):
        return eval_atom(expr.atom, state)
    if isinstance(expr, NotExpr):
        return not eval_bool_expr(expr.expr, state, eval_atom)
    if isinstance(expr, AndExpr):
        return eval_bool_expr(expr.left, state, eval_atom) and eval_bool_expr(
            expr.right,
            state,
            eval_atom,
        )
    if isinstance(expr, OrExpr):
        return eval_bool_expr(expr.left, state, eval_atom) or eval_bool_expr(
            expr.right,
            state,
            eval_atom,
        )
    if isinstance(expr, ImpliesExpr):
        return (not eval_bool_expr(expr.left, state, eval_atom)) or eval_bool_expr(
            expr.right,
            state,
            eval_atom,
        )
    raise TypeError(f"unsupported Boolean expression: {type(expr)!r}")


def predicate_from_expr(
    expr: BoolExpr[AtomT],
    eval_atom: Callable[[AtomT, StateT], bool],
) -> Predicate[StateT]:
    """Turn a Boolean formula into the predicate shape used by node queries."""

    return lambda state: eval_bool_expr(expr, state, eval_atom)


def combine_soundness(classes: tuple[SoundnessClass, ...]) -> SoundnessClass:
    """Conservatively combine atom soundness classes for Boolean formulas."""

    if not classes:
        return SoundnessClass.EXACT
    if SoundnessClass.MAY_ONLY in classes:
        return SoundnessClass.MAY_ONLY
    unique = set(classes)
    if len(unique) == 1:
        return classes[0]
    if unique <= {SoundnessClass.EXACT, SoundnessClass.OVERAPPROX_UNIVERSAL_SAFE}:
        return SoundnessClass.OVERAPPROX_UNIVERSAL_SAFE
    return SoundnessClass.MAY_ONLY


def query_exists(
    exploration: CoreExplorationResult[StateT, LabelT],
    predicate: Predicate[StateT],
    *,
    soundness: SoundnessClass = SoundnessClass.EXACT,
) -> PropertyQueryResult[LabelT]:
    """Check whether any explored node satisfies ``predicate``.

    A witnessed existential remains useful under truncation when the predicate's
    soundness class supports positive witnesses. Absence of a witness is final
    only for complete, non-truncated runs.
    """

    matches = tuple(
        node_id
        for node_id, node in sorted(exploration.graph.nodes.items())
        if predicate(node.state)
    )
    if matches:
        witness = matches[0]
        verdict = (
            QueryVerdict.WITNESSED
            if soundness
            in {SoundnessClass.EXACT, SoundnessClass.UPWARD_CLOSED_COVERABILITY}
            else QueryVerdict.MAY_WITNESSED
        )
        return PropertyQueryResult(
            kind=QueryKind.EXISTS,
            verdict=verdict,
            witness_node=witness,
            witness_trace=tuple(exploration.graph.trace_to(witness)),
            matched_nodes=matches,
            truncated=exploration.stats.truncated,
        )

    return PropertyQueryResult(
        kind=QueryKind.EXISTS,
        verdict=(
            QueryVerdict.INCONCLUSIVE
            if exploration.stats.truncated
            or soundness
            not in {SoundnessClass.EXACT, SoundnessClass.UPWARD_CLOSED_COVERABILITY}
            else QueryVerdict.NOT_WITNESSED
        ),
        truncated=exploration.stats.truncated,
    )


def interpret_exists(result: PropertyQueryResult[LabelT]) -> QueryOutcome:
    """Interpret an existential query as a proof obligation outcome."""

    if result.verdict is QueryVerdict.WITNESSED:
        return QueryOutcome.DISCHARGED
    if result.verdict is QueryVerdict.NOT_WITNESSED:
        return QueryOutcome.VIOLATED
    return QueryOutcome.INCONCLUSIVE


def query_invariant(
    exploration: CoreExplorationResult[StateT, LabelT],
    predicate: Predicate[StateT],
    *,
    soundness: SoundnessClass = SoundnessClass.EXACT,
) -> PropertyQueryResult[LabelT]:
    """Check whether every explored node satisfies ``predicate``.

    Violations on over-approximated graphs are reported as possible violations;
    successful universal checks are final only on complete runs and when the
    predicate soundness class supports universal reasoning.
    """

    violations = tuple(
        node_id
        for node_id, node in sorted(exploration.graph.nodes.items())
        if not predicate(node.state)
    )
    if violations:
        witness = violations[0]
        verdict = (
            QueryVerdict.MAY_VIOLATED
            if soundness
            in {SoundnessClass.OVERAPPROX_UNIVERSAL_SAFE, SoundnessClass.MAY_ONLY}
            else QueryVerdict.VIOLATED
        )
        return PropertyQueryResult(
            kind=QueryKind.INVARIANT,
            verdict=verdict,
            witness_node=witness,
            witness_trace=tuple(exploration.graph.trace_to(witness)),
            matched_nodes=violations,
            truncated=exploration.stats.truncated,
        )

    if exploration.stats.truncated or soundness in {
        SoundnessClass.UPWARD_CLOSED_COVERABILITY,
        SoundnessClass.MAY_ONLY,
    }:
        verdict = QueryVerdict.INCONCLUSIVE
    else:
        verdict = QueryVerdict.HOLDS

    return PropertyQueryResult(
        kind=QueryKind.INVARIANT,
        verdict=verdict,
        truncated=exploration.stats.truncated,
    )


def interpret_invariant(result: PropertyQueryResult[LabelT]) -> QueryOutcome:
    """Interpret an invariant query as a proof obligation outcome."""

    if result.verdict is QueryVerdict.HOLDS:
        return QueryOutcome.DISCHARGED
    if result.verdict is QueryVerdict.VIOLATED:
        return QueryOutcome.VIOLATED
    return QueryOutcome.INCONCLUSIVE


EdgePredicate = Callable[[StateT, CoreEdge[LabelT], StateT], bool]


def query_edge_exists(
    exploration: CoreExplorationResult[StateT, LabelT],
    predicate: EdgePredicate[StateT, LabelT],
    *,
    soundness: SoundnessClass = SoundnessClass.EXACT,
) -> PropertyQueryResult[LabelT]:
    """Check whether any explored edge satisfies ``predicate``.

    The predicate receives the source state, edge object, and destination state.
    This covers event/broadcast/trace-style property front-ends without forcing
    labels into a single kernel syntax.
    """

    matches: list[tuple[int, int]] = []
    for edge in exploration.graph.edges:
        src_state = exploration.graph.nodes[edge.src].state
        dst_state = exploration.graph.nodes[edge.dst].state
        if predicate(src_state, edge, dst_state):
            matches.append((edge.src, edge.dst))

    if matches:
        src, dst = matches[0]
        verdict = (
            QueryVerdict.WITNESSED
            if soundness is SoundnessClass.EXACT
            else QueryVerdict.MAY_WITNESSED
        )
        return PropertyQueryResult(
            kind=QueryKind.EDGE_EXISTS,
            verdict=verdict,
            witness_node=dst,
            witness_edge=(src, dst),
            witness_trace=tuple(exploration.graph.trace_to(dst)),
            matched_edges=tuple(matches),
            truncated=exploration.stats.truncated,
        )

    return PropertyQueryResult(
        kind=QueryKind.EDGE_EXISTS,
        verdict=(
            QueryVerdict.INCONCLUSIVE
            if exploration.stats.truncated or soundness is not SoundnessClass.EXACT
            else QueryVerdict.NOT_WITNESSED
        ),
        truncated=exploration.stats.truncated,
    )


def interpret_edge_exists(result: PropertyQueryResult[LabelT]) -> QueryOutcome:
    """Interpret an edge-existence query as a proof obligation outcome."""

    if result.verdict is QueryVerdict.WITNESSED:
        return QueryOutcome.DISCHARGED
    if result.verdict is QueryVerdict.NOT_WITNESSED:
        return QueryOutcome.VIOLATED
    return QueryOutcome.INCONCLUSIVE


class CTLFormula(Generic[AtomT]):
    """Computation Tree Logic formula over domain-local atoms."""


@dataclass(frozen=True)
class CTLAtom(CTLFormula[AtomT]):
    atom: AtomT


@dataclass(frozen=True)
class CTLNot(CTLFormula[AtomT]):
    sub: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLAnd(CTLFormula[AtomT]):
    left: CTLFormula[AtomT]
    right: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLOr(CTLFormula[AtomT]):
    left: CTLFormula[AtomT]
    right: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLEX(CTLFormula[AtomT]):
    sub: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLAX(CTLFormula[AtomT]):
    sub: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLEF(CTLFormula[AtomT]):
    sub: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLAF(CTLFormula[AtomT]):
    sub: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLEG(CTLFormula[AtomT]):
    sub: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLAG(CTLFormula[AtomT]):
    sub: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLEU(CTLFormula[AtomT]):
    left: CTLFormula[AtomT]
    right: CTLFormula[AtomT]


@dataclass(frozen=True)
class CTLAU(CTLFormula[AtomT]):
    left: CTLFormula[AtomT]
    right: CTLFormula[AtomT]


def ctl_label_states(
    exploration: CoreExplorationResult[StateT, LabelT],
    formula: CTLFormula[AtomT],
    eval_atom: Callable[[AtomT, StateT], bool],
    *,
    totalize_terminals: bool = True,
) -> set[int]:
    """Return graph node ids satisfying a CTL formula."""

    graph = exploration.graph
    nodes = set(graph.nodes)
    successors = _successor_map(exploration, totalize_terminals=totalize_terminals)
    predecessors = _predecessor_map(successors, nodes)

    def label(inner: CTLFormula[AtomT]) -> set[int]:
        if isinstance(inner, CTLAtom):
            return {
                node_id
                for node_id, node in graph.nodes.items()
                if eval_atom(inner.atom, node.state)
            }
        if isinstance(inner, CTLNot):
            return nodes - label(inner.sub)
        if isinstance(inner, CTLAnd):
            return label(inner.left) & label(inner.right)
        if isinstance(inner, CTLOr):
            return label(inner.left) | label(inner.right)
        if isinstance(inner, CTLEX):
            sub = label(inner.sub)
            return {node_id for node_id in nodes if successors[node_id] & sub}
        if isinstance(inner, CTLAX):
            sub = label(inner.sub)
            return {node_id for node_id in nodes if successors[node_id] <= sub}
        if isinstance(inner, CTLEF):
            return _least_pre_exists(label(inner.sub), predecessors)
        if isinstance(inner, CTLAF):
            return _least_pre_all(label(inner.sub), successors, predecessors, nodes)
        if isinstance(inner, CTLEG):
            return _greatest_pre_exists(label(inner.sub), successors)
        if isinstance(inner, CTLAG):
            return _greatest_pre_all(label(inner.sub), successors)
        if isinstance(inner, CTLEU):
            return _exists_until(label(inner.left), label(inner.right), predecessors)
        if isinstance(inner, CTLAU):
            return _all_until(label(inner.left), label(inner.right), successors, predecessors, nodes)
        raise TypeError(f"unsupported CTL formula: {type(inner)!r}")

    return label(formula)


def query_ctl(
    exploration: CoreExplorationResult[StateT, LabelT],
    formula: CTLFormula[AtomT],
    eval_atom: Callable[[AtomT, StateT], bool],
    *,
    soundness: SoundnessClass = SoundnessClass.EXACT,
    totalize_terminals: bool = True,
) -> PropertyQueryResult[LabelT]:
    """Check a CTL formula at every initial node of the graph."""

    satisfying = ctl_label_states(
        exploration,
        formula,
        eval_atom,
        totalize_terminals=totalize_terminals,
    )
    initial_ids = tuple(exploration.graph.initial_ids)
    violations = tuple(node_id for node_id in initial_ids if node_id not in satisfying)

    if violations:
        witness = violations[0]
        verdict = (
            QueryVerdict.MAY_VIOLATED
            if soundness is not SoundnessClass.EXACT
            else QueryVerdict.VIOLATED
        )
        return PropertyQueryResult(
            kind=QueryKind.CTL,
            verdict=verdict,
            witness_node=witness,
            witness_trace=tuple(exploration.graph.trace_to(witness)),
            matched_nodes=violations,
            truncated=exploration.stats.truncated,
        )

    verdict = (
        QueryVerdict.HOLDS
        if not exploration.stats.truncated and soundness is SoundnessClass.EXACT
        else QueryVerdict.INCONCLUSIVE
    )
    return PropertyQueryResult(
        kind=QueryKind.CTL,
        verdict=verdict,
        matched_nodes=initial_ids,
        truncated=exploration.stats.truncated,
    )


def _successor_map(
    exploration: CoreExplorationResult[StateT, LabelT],
    *,
    totalize_terminals: bool,
) -> dict[int, set[int]]:
    successors = {node_id: set() for node_id in exploration.graph.nodes}
    for edge in exploration.graph.edges:
        successors[edge.src].add(edge.dst)
    if totalize_terminals:
        for node_id, node_successors in successors.items():
            if not node_successors:
                node_successors.add(node_id)
    return successors


def _predecessor_map(
    successors: dict[int, set[int]],
    nodes: set[int],
) -> dict[int, set[int]]:
    predecessors = {node_id: set() for node_id in nodes}
    for src, dsts in successors.items():
        for dst in dsts:
            predecessors[dst].add(src)
    return predecessors


def _least_pre_exists(target: set[int], predecessors: dict[int, set[int]]) -> set[int]:
    result = set(target)
    work = list(target)
    while work:
        node_id = work.pop()
        for predecessor in predecessors[node_id]:
            if predecessor not in result:
                result.add(predecessor)
                work.append(predecessor)
    return result


def _least_pre_all(
    target: set[int],
    successors: dict[int, set[int]],
    predecessors: dict[int, set[int]],
    nodes: set[int],
) -> set[int]:
    result = set(target)
    remaining = {node_id: len(successors[node_id]) for node_id in nodes}
    work = list(target)
    while work:
        node_id = work.pop()
        for predecessor in predecessors[node_id]:
            if predecessor in result:
                continue
            remaining[predecessor] -= 1
            if remaining[predecessor] <= 0:
                result.add(predecessor)
                work.append(predecessor)
    return result


def _greatest_pre_exists(target: set[int], successors: dict[int, set[int]]) -> set[int]:
    result = set(target)
    changed = True
    while changed:
        changed = False
        to_remove = {
            node_id
            for node_id in result
            if not (successors[node_id] & result)
        }
        if to_remove:
            result -= to_remove
            changed = True
    return result


def _greatest_pre_all(target: set[int], successors: dict[int, set[int]]) -> set[int]:
    result = set(target)
    changed = True
    while changed:
        changed = False
        to_remove = {
            node_id
            for node_id in result
            if not successors[node_id] <= result
        }
        if to_remove:
            result -= to_remove
            changed = True
    return result


def _exists_until(
    left: set[int],
    right: set[int],
    predecessors: dict[int, set[int]],
) -> set[int]:
    result = set(right)
    work = list(right)
    while work:
        node_id = work.pop()
        for predecessor in predecessors[node_id]:
            if predecessor in left and predecessor not in result:
                result.add(predecessor)
                work.append(predecessor)
    return result


def _all_until(
    left: set[int],
    right: set[int],
    successors: dict[int, set[int]],
    predecessors: dict[int, set[int]],
    nodes: set[int],
) -> set[int]:
    result = set(right)
    remaining = {node_id: len(successors[node_id]) for node_id in nodes}
    work = list(right)
    while work:
        node_id = work.pop()
        for predecessor in predecessors[node_id]:
            if predecessor in result or predecessor not in left:
                continue
            remaining[predecessor] -= 1
            if remaining[predecessor] <= 0:
                result.add(predecessor)
                work.append(predecessor)
    return result
