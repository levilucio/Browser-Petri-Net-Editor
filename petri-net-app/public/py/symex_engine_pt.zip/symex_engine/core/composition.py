"""Product adapters for composing kernel instantiations.

The product adapter turns two existing ``ExplorationAdapter`` instances into a
single adapter over paired states.  It is deliberately small: the core explorer
still owns scheduling, graph construction, memoization, abstraction, and
subsumption bookkeeping.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from itertools import product
from typing import Generic, Hashable, TypeVar

from symex_engine.core.explorer import (
    CoreStep,
    ExplorationAdapter,
    ExplorationContext,
)


LeftStateT = TypeVar("LeftStateT")
RightStateT = TypeVar("RightStateT")
LeftLabelT = TypeVar("LeftLabelT")
RightLabelT = TypeVar("RightLabelT")


@dataclass(frozen=True)
class ProductState(Generic[LeftStateT, RightStateT]):
    """State pair explored by ``ProductAdapter``."""

    left: LeftStateT
    right: RightStateT


@dataclass(frozen=True)
class ProductLabel(Generic[LeftLabelT, RightLabelT]):
    """Edge label for left-only, right-only, or synchronized product steps."""

    left: LeftLabelT | None = None
    right: RightLabelT | None = None


Synchronize = Callable[[object | None, object | None], bool]


class ProductAdapter(
    Generic[LeftStateT, RightStateT, LeftLabelT, RightLabelT],
):
    """Componentwise product of two exploration adapters.

    With no ``synchronize`` predicate, the product is the standard independent
    interleaving product.  When ``synchronize`` is provided, matching labels can
    fire jointly; unary calls ``synchronize(label, None)`` and
    ``synchronize(None, label)`` mark labels that must not interleave alone.
    """

    def __init__(
        self,
        left: ExplorationAdapter[LeftStateT, LeftLabelT],
        right: ExplorationAdapter[RightStateT, RightLabelT],
        *,
        synchronize: Synchronize | None = None,
    ) -> None:
        self.left = left
        self.right = right
        self.synchronize = synchronize

    def initial_states(self) -> tuple[ProductState[LeftStateT, RightStateT], ...]:
        return tuple(
            ProductState(left_state, right_state)
            for left_state in self.left.initial_states()
            for right_state in self.right.initial_states()
        )

    def successors(
        self,
        state: ProductState[LeftStateT, RightStateT],
    ) -> list[CoreStep[ProductState[LeftStateT, RightStateT], ProductLabel[LeftLabelT, RightLabelT]]]:
        left_steps = tuple(self.left.successors(state.left))
        right_steps = tuple(self.right.successors(state.right))
        out: list[
            CoreStep[
                ProductState[LeftStateT, RightStateT],
                ProductLabel[LeftLabelT, RightLabelT],
            ]
        ] = []

        if self.synchronize is not None:
            for left_step in left_steps:
                for right_step in right_steps:
                    if self.synchronize(left_step.label, right_step.label):
                        out.append(
                            CoreStep(
                                ProductState(left_step.state, right_step.state),
                                ProductLabel(left_step.label, right_step.label),
                                flags=left_step.flags | right_step.flags | frozenset({"sync"}),
                            )
                        )

        for left_step in left_steps:
            if not self._must_synchronize_left(left_step.label):
                out.append(
                    CoreStep(
                        ProductState(left_step.state, state.right),
                        ProductLabel(left=left_step.label),
                        flags=left_step.flags,
                    )
                )

        for right_step in right_steps:
            if not self._must_synchronize_right(right_step.label):
                out.append(
                    CoreStep(
                        ProductState(state.left, right_step.state),
                        ProductLabel(right=right_step.label),
                        flags=right_step.flags,
                    )
                )

        return out

    def signature(self, state: ProductState[LeftStateT, RightStateT]) -> Hashable:
        return self.left.signature(state.left), self.right.signature(state.right)

    def is_terminal(self, state: ProductState[LeftStateT, RightStateT]) -> bool:
        return self._is_terminal(self.left, state.left) and self._is_terminal(self.right, state.right)

    def abstract_successor(
        self,
        state: ProductState[LeftStateT, RightStateT],
        context: ExplorationContext[
            ProductState[LeftStateT, RightStateT],
            ProductLabel[LeftLabelT, RightLabelT],
        ],
    ) -> ProductState[LeftStateT, RightStateT]:
        left_context = self._left_context(context)
        right_context = self._right_context(context)
        return ProductState(
            self._abstract(self.left, state.left, left_context),
            self._abstract(self.right, state.right, right_context),
        )

    def subsumption_key(self, state: ProductState[LeftStateT, RightStateT]) -> Hashable | None:
        left_key = self._subsumption_key(self.left, state.left)
        right_key = self._subsumption_key(self.right, state.right)
        if left_key is None or right_key is None:
            return None
        return left_key, right_key

    def subsumes(
        self,
        existing: ProductState[LeftStateT, RightStateT],
        candidate: ProductState[LeftStateT, RightStateT],
    ) -> bool:
        return self._covers_component(self.left, existing.left, candidate.left) and self._covers_component(
            self.right,
            existing.right,
            candidate.right,
        )

    def subsumed_by_ancestor(
        self,
        candidate: ProductState[LeftStateT, RightStateT],
        context: ExplorationContext[
            ProductState[LeftStateT, RightStateT],
            ProductLabel[LeftLabelT, RightLabelT],
        ],
    ) -> int | None:
        for ancestor_id, ancestor in context.ancestor_chain:
            if self._ancestor_covers_component(
                self.left,
                candidate.left,
                ancestor.left,
                ancestor_id,
            ) and self._ancestor_covers_component(
                self.right,
                candidate.right,
                ancestor.right,
                ancestor_id,
            ):
                return ancestor_id
        return None

    def extra_edge_flags(
        self,
        _candidate: ProductState[LeftStateT, RightStateT],
        context: ExplorationContext[
            ProductState[LeftStateT, RightStateT],
            ProductLabel[LeftLabelT, RightLabelT],
        ],
    ) -> frozenset[str]:
        flags = frozenset()
        if context.step_label.left is not None:
            flags |= self._extra_flags(self.left, context.source_state.left, self._left_context(context))
        if context.step_label.right is not None:
            flags |= self._extra_flags(self.right, context.source_state.right, self._right_context(context))
        return flags

    def _must_synchronize_left(self, label: LeftLabelT) -> bool:
        return bool(self.synchronize is not None and self.synchronize(label, None))

    def _must_synchronize_right(self, label: RightLabelT) -> bool:
        return bool(self.synchronize is not None and self.synchronize(None, label))

    @staticmethod
    def _is_terminal(adapter: object, state: object) -> bool:
        method = getattr(adapter, "is_terminal", None)
        return bool(method(state)) if method is not None else False

    @staticmethod
    def _subsumption_key(adapter: object, state: object) -> Hashable | None:
        method = getattr(adapter, "subsumption_key", None)
        return method(state) if method is not None else None

    @staticmethod
    def _covers_component(adapter: object, existing: object, candidate: object) -> bool:
        if existing == candidate:
            return True
        method = getattr(adapter, "subsumes", None)
        return bool(method(existing, candidate)) if method is not None else False

    @staticmethod
    def _abstract(
        adapter: object,
        state: object,
        context: ExplorationContext[object, object],
    ) -> object:
        method = getattr(adapter, "abstract_successor", None)
        return method(state, context) if method is not None else state

    @staticmethod
    def _extra_flags(
        adapter: object,
        candidate: object,
        context: ExplorationContext[object, object],
    ) -> frozenset[str]:
        method = getattr(adapter, "extra_edge_flags", None)
        return method(candidate, context) if method is not None else frozenset()

    def _ancestor_covers_component(
        self,
        adapter: object,
        candidate: object,
        ancestor: object,
        ancestor_id: int,
    ) -> bool:
        if ancestor == candidate:
            return True

        method = getattr(adapter, "subsumed_by_ancestor", None)
        if method is None:
            return False

        context = ExplorationContext(
            source_id=ancestor_id,
            source_state=ancestor,
            step_label=None,
            depth=0,
            ancestor_chain=((ancestor_id, ancestor),),
        )
        return method(candidate, context) == ancestor_id

    def _left_context(
        self,
        context: ExplorationContext[
            ProductState[LeftStateT, RightStateT],
            ProductLabel[LeftLabelT, RightLabelT],
        ],
    ) -> ExplorationContext[LeftStateT, LeftLabelT | None]:
        return ExplorationContext(
            source_id=context.source_id,
            source_state=context.source_state.left,
            step_label=context.step_label.left,
            depth=context.depth,
            ancestor_chain=tuple((node_id, state.left) for node_id, state in context.ancestor_chain),
        )

    def _right_context(
        self,
        context: ExplorationContext[
            ProductState[LeftStateT, RightStateT],
            ProductLabel[LeftLabelT, RightLabelT],
        ],
    ) -> ExplorationContext[RightStateT, RightLabelT | None]:
        return ExplorationContext(
            source_id=context.source_id,
            source_state=context.source_state.right,
            step_label=context.step_label.right,
            depth=context.depth,
            ancestor_chain=tuple((node_id, state.right) for node_id, state in context.ancestor_chain),
        )


def product_states(
    left_states: Iterable[LeftStateT],
    right_states: Iterable[RightStateT],
) -> tuple[ProductState[LeftStateT, RightStateT], ...]:
    """Convenience helper used by tests and examples."""

    return tuple(ProductState(left, right) for left in left_states for right in right_states)


@dataclass(frozen=True)
class NaryProductState:
    """Tuple state explored by ``NaryProductAdapter``."""

    components: tuple[object, ...]


@dataclass(frozen=True)
class NaryProductLabel:
    """Label for one interleaved component step in an N-ary product."""

    index: int
    label: object


class NaryProductAdapter:
    """Independent interleaving product of a fixed tuple of adapters.

    This is the direct N-ary generalization of ``ProductAdapter`` for systems
    whose component set is fixed. Domains with dynamic arity (for example,
    Promela ``run`` spawning) can still reuse the same product discipline, but
    need a domain adapter to decide when the component tuple changes.
    """

    def __init__(self, adapters: Sequence[ExplorationAdapter[object, object]]) -> None:
        if not adapters:
            raise ValueError("NaryProductAdapter requires at least one component adapter")
        self.adapters = tuple(adapters)

    def initial_states(self) -> tuple[NaryProductState, ...]:
        return tuple(
            NaryProductState(tuple(states))
            for states in product(*(tuple(adapter.initial_states()) for adapter in self.adapters))
        )

    def successors(self, state: NaryProductState) -> list[CoreStep[NaryProductState, NaryProductLabel]]:
        out: list[CoreStep[NaryProductState, NaryProductLabel]] = []
        for idx, (adapter, component_state) in enumerate(zip(self.adapters, state.components, strict=True)):
            for step in adapter.successors(component_state):
                components = list(state.components)
                components[idx] = step.state
                out.append(
                    CoreStep(
                        NaryProductState(tuple(components)),
                        NaryProductLabel(idx, step.label),
                        flags=step.flags,
                    )
                )
        return out

    def signature(self, state: NaryProductState) -> Hashable:
        return tuple(adapter.signature(component) for adapter, component in zip(self.adapters, state.components, strict=True))

    def is_terminal(self, state: NaryProductState) -> bool:
        return all(
            ProductAdapter._is_terminal(adapter, component)
            for adapter, component in zip(self.adapters, state.components, strict=True)
        )

    def abstract_successor(
        self,
        state: NaryProductState,
        context: ExplorationContext[NaryProductState, NaryProductLabel],
    ) -> NaryProductState:
        components = list(state.components)
        idx = context.step_label.index
        components[idx] = ProductAdapter._abstract(
            self.adapters[idx],
            components[idx],
            self._component_context(context, idx),
        )
        return NaryProductState(tuple(components))

    def subsumption_key(self, state: NaryProductState) -> Hashable | None:
        keys = tuple(
            ProductAdapter._subsumption_key(adapter, component)
            for adapter, component in zip(self.adapters, state.components, strict=True)
        )
        if any(key is None for key in keys):
            return None
        return keys

    def subsumes(self, existing: NaryProductState, candidate: NaryProductState) -> bool:
        return all(
            ProductAdapter._covers_component(adapter, old, new)
            for adapter, old, new in zip(self.adapters, existing.components, candidate.components, strict=True)
        )

    def extra_edge_flags(
        self,
        _candidate: NaryProductState,
        context: ExplorationContext[NaryProductState, NaryProductLabel],
    ) -> frozenset[str]:
        idx = context.step_label.index
        return ProductAdapter._extra_flags(
            self.adapters[idx],
            context.source_state.components[idx],
            self._component_context(context, idx),
        )

    @staticmethod
    def _component_context(
        context: ExplorationContext[NaryProductState, NaryProductLabel],
        idx: int,
    ) -> ExplorationContext[object, object]:
        return ExplorationContext(
            source_id=context.source_id,
            source_state=context.source_state.components[idx],
            step_label=context.step_label.label,
            depth=context.depth,
            ancestor_chain=tuple((node_id, state.components[idx]) for node_id, state in context.ancestor_chain),
        )
